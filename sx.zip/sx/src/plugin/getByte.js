const  bytesToSize = (bytes) =>  {        
	if (bytes  ===  0)  return  '0 B';            
	var  k  =  1024; 
	let   sizes  =   ['B', 'KB',  'MB',  'GB',  'TB',  'PB',  'EB',  'ZB',  'YB'];    
	let i  =  Math.floor(Math.log(bytes)  /  Math.log(k));        
	return (bytes  /  Math.pow(k,  i)).toFixed(2)  +  ' '  +  sizes[i];          
	//toPrecision(3) 后面保留一位小数，如1.0GB                                                                                                                  //return (bytes / Math.pow(k, i)).toPrecision(3) + ' ' + sizes[i];  
} 
export default  bytesToSize;