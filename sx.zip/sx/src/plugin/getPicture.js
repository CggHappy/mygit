import html2canvas from 'html2canvas';
const getPicture = (dom,callback) => {	
	html2canvas(dom,{ useCORS: true }).then((canvas) => {
		let url = canvas.toDataURL("image/png",'1.0');
		(typeof callback === "function") && (callback(url));
	});
}
export default getPicture;