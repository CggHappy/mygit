// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.
import Vue from 'vue'
import App from './App'
import router from './router'
import ElementUI from 'element-ui'
import 'element-ui/lib/theme-chalk/index.css'
import '@/assets/icon-font/iconfont.css'
import '@/assets/css/reset.css'
import '@/assets/css/base-pc.css'
import '@/assets/css/common.css'
import '@/assets/css/element.css'
import less from 'less'
Vue.prototype.less = less;
import echarts from 'echarts'
// 导入插件
import colorPicker from './plugin/vue-color-picker'
//配置文件上传axios
import axios from 'axios'
import qs from 'qs'
var $axios = axios.create({
	//测试地址
	//正式地址
	baseURL: 'http://api.launcher.pactera-sln.club:8185',
	//测试地址
	//	  baseURL: 'http://192.168.9.50:8888',
	// timeout: 5000,
	headers: {
		'Content-type': 'multipart/form-data',
	}
});
axios.defaults.withCredentials = true;
//POST传参序列化
$axios.interceptors.request.use((config) => {
	if(config.method === 'post') {
		config.data = qs.stringify(config.data);
	}
	return config;
}, (error) => {
	_.toast("错误的传参", 'fail');
	return Promise.reject(error);
});
// 添加一个响应拦截器
$axios.interceptors.response.use(function(res) {
	//处理登录超时
	//	if(res.data.code === 2) {}
	return res;
}, function(err) {
	return Promise.reject(error);
});
Vue.prototype.axios = $axios;

router.beforeEach((to, from, next) => { //路由控制
	if(sessionStorage.getItem('Token')) {
		if(to.path == '/') {
			router.push({
				path: '/index/situation'
			})
		}
	} else {
		if(from.path == '/'&&to.path!='/') {
			router.push({
				path: '/'
			})
		}
	}
	next()
});
router.afterEach(transition => {
	//console.log(transition)
});
// 注册插件
Vue.use(colorPicker)
Vue.prototype.$echarts = echarts;
import getPicture from './plugin/getPicture.js'; //将canvans转正图片  组件调用 this.getPicture(dom) 一个参数 就是dom
Vue.prototype.getPicture = getPicture;
import getTimer from './plugin/getTimer.js';
Vue.prototype.get_Timer = getTimer;

import getByte from './plugin/getByte.js';
Vue.prototype.get_Byte = getByte;
Vue.prototype.imgbaseUrl = 'http://img.launcher.pactera-sln.club:8185/';
Vue.config.productionTip = false //开发不显示提示
Vue.use(ElementUI)
/* eslint-disable no-new */
new Vue({
	el: '#app',
	router,
	render: h => h(App)
})