import axios from "@/axios.js";
export default {
	data() {
		return {
			qudao: [{
				id: '1',
				name: '渠道一'
			}, {
				id: '2',
				name: '渠道二'
			}],
			tabPosition: '新增车辆',
			TopthemeTab:'使用次数',
			TopthemeRightTab:'新增车辆',
			TopthemeLeftTab:'新增车辆',
			qudaostr: '',
			channel:false,
		}
	},
	mounted() { //实例挂载之后
		//this.drawTopLine();
		this.getPosterDate();
		
		
	},
	methods: { //方法	
		getPosterDate(){
			let userMsg = JSON.parse(sessionStorage.getItem('userMsg'));
			if(userMsg.userType == 0 ||userMsg.userType == 2){
				this.channel = true;
				this.AnalysisDrawTopLine();
				this.ThemeDrawTopLine();
				this.ApplicationDrawTopLine();
				this.EditionDrawTopLine();
				this.ChannelDrawTopLine();
			}else{
				this.channel = false;
				this.AnalysisDrawTopLine();
				this.ThemeDrawTopLine();
				this.ApplicationDrawTopLine();
				this.EditionDrawTopLine();
				this.$refs.box.style.display = 'none'
			}
		},

		//趋势分析
		AnalysisDrawTopLine() {
			let topLine = this.$echarts.init(document.getElementById('applyData'));
			var option = {
				xAxis: [
					{
						type: "category",
						splitLine: { show: false },
						data: ["12-10", "12-11", "12-12", "12-13", "12-14", "12-15", "12-16", "12-17", "12-18	"],
						axisTick: {
							show: false
						}
					}
				],
				yAxis: [
					{
						type: "value",
						// data: ['0', '1K', '2K', '3K', '4K', '5K'],
						axisTick: {
							show: false
						}
					}
				],
				tooltip: {
					trigger: 'axis',
					formatter: function (params) {
						let res = '时间：' + params[0].data.day
							+
							'<br/>' + '新增车辆：' + params[0].data.value;
						return res;
					},
					backgroundColor: '#FFFFFF',
					borderRadius: 4,
					borderWidth: 1,
					borderColor: '#e5e7f4',
					textStyle: {
						width: 169,
						height: 100,
						fontSize: 14,
						color: ' #96969E',
						fontFamily: 'PingFangSC-Medium',
						lineHeight: 22,
					}
				},
				series: [
					{
						// name: "3的指数",
						type: "line",
						data: [
							{ day: '2017-12-10', value: '1300' },
							{ day: '2017-12-11', value: '3230' },
							{ day: '2017-12-12', value: '9540' },
							{ day: '2017-12-13', value: '3240' },
							{ day: '2017-12-14', value: '5130' },
							{ day: '2017-12-15', value: '2403' },
							{ day: '2017-12-16', value: '7013' },
							{ day: '2017-12-17', value: '2223' },
							{ day: '2017-12-18', value: '6669' }
						],
						itemStyle: {
							normal: {
								color: "#FF607C",
								lineStyle: {
									color: "#E68191"
								}
							}
						},
						 areaStyle: {normal: {
				            color: {
				                type: 'linear',
				                x: 0,
				                y: 0,
				                x2: 0,
				                y2: 1,
				                colorStops: [{
				                    offset: 0, color: 'rgb(248,218,223)' // 0% 处的颜色
				                }, {
				                    offset: 1, color: '#fff' // 100% 处的颜色
				                }],
				                globalCoord: false // 缺省为 false
				            }
				        }},
					},
				]
			};
			topLine.setOption(option);
		},

		//TOP主题
		ThemeDrawTopLine(){
			let conLine = this.$echarts.init(document.getElementById('applyData2'));
			var option = {
				tooltip: {
					trigger: 'axis'
				},
				legend: {
					// data: ['昨日', '前日'],
					x: 'center',
					y: 'bottom',
					itemWidth: 10,
					itemHeight: 10,
				},
				calculable: true,
				grid: {
					x: 210,
					y: 20,
					x2: 50,
					y2: 50
				},
				xAxis: [
					{
						type: 'value',
						boundaryGap: [0, 0.01],
						axisTick: {
							show: false
						}
					}
				],
				yAxis: [
					{
						type: 'category',
						data: ['飘雪燕落0021', '千山暮雪0020', '泡沫之夏0019', '快乐时光0018', '时尚达人0017', '午后时光0016', '呆萌企鹅0015', '午夜精灵0014', '可爱猫咪0013', '最经典的十二生肖主题001234599'],
						axisTick: {
							show: false
						}
					}
				],
				tooltip: {
					trigger: 'axis',
					formatter: function (params) {
						let res = '主题：' + params[0].name
							+
							'<br/>' + '昨日使用次数：' + params[0].data.value
							+
							'<br/>' + '昨日使用次数占比：' + params[0].data.parent + '%'
							+
							'<br/>' + '前日使用次数：' + params[1].data.value
							+
							'<br/>' + '前日使用次数占比：' + params[1].data.parent + '%';
						return res;
					},
					backgroundColor: '#FFFFFF',
					borderRadius: 4,
					borderWidth: 1,
					borderColor: '#e5e7f4',
					textStyle: {
						width: 169,
						height: 100,
						fontSize: 14,
						color: ' #96969E',
						fontFamily: 'PingFangSC-Medium',
						lineHeight: 22,
					}
				},
				series: [
					{
						name: '昨日',
						type: 'bar',
						data: [
							{ value: '100', parent: '10' },
							{ value: '150', parent: '15' },
							{ value: '200', parent: '20' },
							{ value: '150', parent: '25' },
							{ value: '300', parent: '30' },
							{ value: '350', parent: '35' },
							{ value: '400', parent: '40' },
							{ value: '450', parent: '45' },
							{ value: '500', parent: '50' },
							{ value: '550', parent: '55' }
						],
						itemStyle: {
							normal: {
								color: '#e68191',
							},
							emphasis: {
								color: '#ff5570',
							}
						},
						barWidth: 17,
						barGap:0
					},
					{
						name: '前日',
						type: 'bar',
						data: [
							{ value: '50', parent: '5' },
							{ value: '80', parent: '10' },
							{ value: '100', parent: '15' },
							{ value: '120', parent: '20' },
							{ value: '200', parent: '25' },
							{ value: '220', parent: '30' },
							{ value: '200', parent: '35' },
							{ value: '250', parent: '40' },
							{ value: '300', parent: '45' },
							{ value: '350', parent: '50' }
						],
						itemStyle: {
							normal: {
								color: '#84a1e5',
							},
							emphasis: {
								color: '#477eff',
							}
						},
						barWidth: 10,
						bbarGap:0
					},

				]
			};
			conLine.setOption(option);
		},

		//TOP应用
		ApplicationDrawTopLine(){
			let con2Line = this.$echarts.init(document.getElementById('applyData3'));
			var option = {
				tooltip: {
					trigger: 'axis'
				},
				legend: {
					x: 'center',
					y: 'bottom',
					itemWidth: 10,
					itemHeight: 10,
				},
				calculable: true,
				grid: {
					x: 70,
					y: 20,
					x2: 40,
					y2: 50
				},
				xAxis: [
					{
						type: 'value',
						boundaryGap: [0, 0.01],
						axisTick: {
							show: false
						}
					}
				],
				yAxis: [
					{
						type: 'category',
						data: ['今日头条', 'QQ', '导航犬', '高德地图', '优酷', '网易云音乐', '微信', 'QQ音乐', '腾讯地图', '图吧导航'],
						axisTick: {
							show: false
						}
					}
				],
				tooltip: {
					trigger: 'axis',
					formatter: function (params) {
						let res = '主题：' + params[0].name
							+
							'<br/>' + '昨日启动次数：' + params[0].data.value
							+
							'<br/>' + '昨日启动次数占比：' + params[0].data.parent + '%'
							+
							'<br/>' + '前日启动次数：' + params[1].data.value
							+
							'<br/>' + '前日启动次数占比：' + params[1].data.parent + '%';
						return res;
					},
					backgroundColor: '#FFFFFF',
					borderRadius: 4,
					borderWidth: 1,
					borderColor: '#e5e7f4',
					textStyle: {
						width: 169,
						height: 100,
						fontSize: 14,
						color: ' #96969E',
						fontFamily: 'PingFangSC-Medium',
						lineHeight: 22,
					}
				},
				series: [
					{
						name: '昨日',
						type: 'bar',
						data: [
							{ value: '100', parent: '10' },
							{ value: '150', parent: '15' },
							{ value: '200', parent: '20' },
							{ value: '150', parent: '25' },
							{ value: '300', parent: '30' },
							{ value: '350', parent: '35' },
							{ value: '400', parent: '40' },
							{ value: '450', parent: '45' },
							{ value: '500', parent: '50' },
							{ value: '580', parent: '55' }
						],
						itemStyle: {
							normal: {
								color: '#e68191',
							},
							emphasis: {
								color: '#ff5570',
							}
						},
						barWidth: 17,
						barGap:0
					},
					{
						name: '前日',
						type: 'bar',
						data: [
							{ value: '50', parent: '5' },
							{ value: '80', parent: '10' },
							{ value: '100', parent: '15' },
							{ value: '120', parent: '20' },
							{ value: '200', parent: '25' },
							{ value: '220', parent: '30' },
							{ value: '200', parent: '35' },
							{ value: '250', parent: '40' },
							{ value: '300', parent: '45' },
							{ value: '500', parent: '50' }
						],
						itemStyle: {
							normal: {
								color: '#84a1e5',
							},
							emphasis: {
								color: '#477eff',
							}
						},
						barWidth: 10,
						barGap:0
					},

				]
			};
			con2Line.setOption(option);
		},

		//TOP版本
		EditionDrawTopLine(){
			let con3Line = this.$echarts.init(document.getElementById('applyData4'));

			var option = {
				tooltip: { //提示框组件
					trigger: 'item',
					formatter: function (params) {
						let res = '版本：' + params.data.edition
							+
							'<br/>' + '新增车辆：' + params.data.value
							+
							'<br/>' + '新增车辆占比：' + params.data.Proportion + '%';
						return res;
					},
					backgroundColor: '#FFFFFF',
					borderRadius: 4,
					borderWidth: 1,
					borderColor: '#e5e7f4',
					textStyle: {
						width: 160,
						height: 130,
						fontSize: 14,
						color: '#96969E',
						fontFamily: 'PingFangSC-Regular',
						lineHeight: 20,
					}
				},
				color: ['#808080', '#aecd8b', '#a98bcd', '#85b4ca', '#e6b981', '#24b7be', '#e78080', '#8b9ecd', '#8bcda1', '#dd9d85', '#808080'],  //手动设置每个图例的颜色
				legend: {  //图例组件
					orient: 'vertical',
					//width: 550,
					height: 120,
					//x: 'center',
					//y: 'bottom',
					bottom:30,
					left:0,
					itemGap: 40,
					itemWidth: 10,
					itemHeight: 10,
					borderColor: "#e2e1e6",
					borderWidth: 1,
					padding: [10, 30],
					textStyle: {
						color: '#333',
						fontSize: 12,
					}
				},
				series: [ //系列列表
					{
						name: 'v9.4.2',
						type: 'pie',
						center: ['50%', '33%'],
						radius: ['33%', '50%'],
						itemStyle: {  //图形样式
							normal: {
								label: {
									show: false
								},
								labelLine: {
									show: false
								}
							},
							emphasis: {
								label: {  //饼图图形上的文本标签
									show: false,
									position: 'center',
									textStyle: {
										fontSize: '10',
										fontWeight: 'bold'
									}
								}
							}
						},
						data: [
							{ value: 23, name: 'v9.4.2：23', edition: 'v9.4.2', Proportion: 3 },
							{ value: 228, name: 'v9.4.2：228', edition: 'v9.4.2', Proportion: 4 },
							{ value: 326, name: 'v9.4.2：326', edition: 'v9.4.2', Proportion: 5 },
							{ value: 623, name: 'v9.4.2：623', edition: 'v9.4.2', Proportion: 6 },
							{ value: 702, name: 'v9.4.2：702', edition: 'v9.4.2', Proportion: 7 },
							{ value: 790, name: 'v9.4.2：790', edition: 'v9.4.2', Proportion: 8 },
							{ value: 801, name: 'v9.4.2：801', edition: 'v9.4.2', Proportion: 9 },
							{ value: 812, name: 'v9.4.2：812', edition: 'v9.4.2', Proportion: 12 },
							{ value: 923, name: 'v9.4.2：923', edition: 'v9.4.2', Proportion: 13 },
							{ value: 1123, name: 'v9.4.2：1123', edition: 'v9.4.2', Proportion: 16 },
							{ value: 1923, name: 'v9.4.2：1923', edition: 'v9.4.2', Proportion: 17 }
						]
					}
				]
			}
			con3Line.setOption(option);
		},

		//TOP渠道
		ChannelDrawTopLine(){
			let con4Line = this.$echarts.init(document.getElementById('applyData5'));
			var option = {
				tooltip: {
					trigger: 'axis'
				},
				legend: {
					x: 'center',
					y: 'bottom',
					itemWidth: 10,
					itemHeight: 10,
				},
				calculable: true,
				grid: {
					x: 70,
					y: 20,
					x2: 40,
					y2: 50
				},
				xAxis: [
					{
						type: 'value',
						boundaryGap: [0, 0.01],
						axisTick: {
							show: false
						}
					}
				],
				yAxis: [
					{
						type: 'category',
						data: ['得赛西威', '天缘', '凯越', '好帮手', '智成', '影士', '卓乐', '杰成', '飞歌', '易鑫'],
						axisTick: {
							show: false
						}
					}
				],
				tooltip: {
					trigger: 'axis',
					formatter: function (params) {
						let res = '渠道：' + params[0].name
							+
							'<br/>' + '昨日新增车辆：' + params[0].data.value
							+
							'<br/>' + '昨日新增车辆占比：' + params[0].data.parent + '%'
							+
							'<br/>' + '前日新增车辆：' + params[1].data.value
							+
							'<br/>' + '前日新增车辆占比：' + params[1].data.parent + '%';
						return res;
					},
					backgroundColor: '#FFFFFF',
					borderRadius: 4,
					borderWidth: 1,
					borderColor: '#e5e7f4',
					textStyle: {
						width: 169,
						height: 100,
						fontSize: 14,
						color: ' #96969E',
						fontFamily: 'PingFangSC-Medium',
						lineHeight: 22,
					}
				},
				series: [
					{
						name: '昨日',
						type: 'bar',
						data: [
							{ value: '100', parent: '10' },
							{ value: '150', parent: '15' },
							{ value: '200', parent: '20' },
							{ value: '150', parent: '25' },
							{ value: '300', parent: '30' },
							{ value: '350', parent: '35' },
							{ value: '400', parent: '40' },
							{ value: '450', parent: '45' },
							{ value: '500', parent: '50' },
							{ value: '580', parent: '55' }
						],
						itemStyle: {
							normal: {
								color: '#e68191',
							},
							emphasis: {
								color: '#ff5570',
							}
						},
						barWidth: 17,
						barGap:0
					},
					{
						name: '前日',
						type: 'bar',
						data: [
							{ value: '50', parent: '5' },
							{ value: '80', parent: '10' },
							{ value: '100', parent: '15' },
							{ value: '120', parent: '20' },
							{ value: '200', parent: '25' },
							{ value: '220', parent: '30' },
							{ value: '200', parent: '35' },
							{ value: '250', parent: '40' },
							{ value: '300', parent: '45' },
							{ value: '500', parent: '50' }
						],
						itemStyle: {
							normal: {
								color: '#84a1e5',
							},
							emphasis: {
								color: '#477eff',
							}
						},
						barWidth: 10,
						barGap:0
					},

				]
			};
			con4Line.setOption(option);
		}

	},
	created() { //实例创建之后
		


	}
}