<template>
	<div class="adminsituation">
		<div class="overallSurvey">
			整体概况
		</div>
		<div class="overallChannel" v-if="channel">
			<label class="channel">渠道:</label>
			<el-select placeholder="全部" v-model="qudaostr">
				<el-option v-for="item in qudao" :key="item.id" :label="item.name" :value="item.id">
				</el-option>
			</el-select>
		</div>
		<div class="overallThedaySurvey">
			<h3 class="h3">今日概况
				<p>?</p>
			</h3>
			<div class="overallThedaysurveyC">
				<div class="CnumOne">
					<h5 class="h5">新增车辆</h5>
					<h2 class="h2">298</h2>
				</div>
				<div class="CnumTwo">
					<h5 class="h5">活跃车辆</h5>
					<h2 class="h2">1,205</h2>
				</div>
				<div class="CnumThree">
					<h5 class="h5">启动次数</h5>
					<h2 class="h2">5,498</h2>
				</div>
				<div class="CnumFour">
					<h5 class="h5">累计车辆</h5>
					<h2 class="h2">20,486</h2>
				</div>
			</div>
		</div>
		<div class="trendanalysis">
			<div class="tit">近30日趋势分析
				<p>?</p>
				<div class="themeUseTitleTab">
					<el-radio-group v-model="tabPosition">
						<el-radio-button label="新增车辆">新增车辆</el-radio-button>
						<el-radio-button label="活跃车辆">活跃车辆</el-radio-button>
						<el-radio-button label="启动次数">启动次数</el-radio-button>
						<el-radio-button label="平均单次使用时长">平均单次使用时长</el-radio-button>
						<el-radio-button label="主题使用次数">主题使用次数</el-radio-button>
						<el-radio-button label="有效主题">有效主题</el-radio-button>
						<el-radio-button label="广告点击次数">广告点击次数</el-radio-button>
						<el-radio-button label="广告展示次数">广告展示次数</el-radio-button>
					</el-radio-group>
				</div>
				<div class="trend">
					<div id="applyData" :style="{width: '100%', height: '100%'}"></div>
				</div>
			</div>
		</div>
		<div class="Toptheme">
			<div class="tit">TOP主题
				<p>?</p>
				<div class="themeUseTitleTab">
					<el-radio-group v-model="TopthemeTab">
						<el-radio-button label="使用次数">使用次数</el-radio-button>
						<el-radio-button label="使用车辆">使用车辆</el-radio-button>
						<el-radio-button label="平均单次使用时长">平均单次使用时长</el-radio-button>
					</el-radio-group>
				</div>
			</div>
			<div class="TopthemeData">
				<div id="applyData2" :style="{width: '100%', height: '100%'}"></div>
			</div>
		</div>
		<div class="TopthemeLeft">
			<div class="tit">TOP应用
				<p>?</p>
				<div class="TopthemeLeftData">
					<div id="applyData3" :style="{width: '100%', height: '100%'}"></div>
				</div>
			</div>
		</div>
		<div class="TopthemeRight">
			<div class="tit">TOP版本
				<p>?</p>
				<div class="themeUseTitleTab">
					<el-radio-group v-model="TopthemeRightTab">
						<el-radio-button label="新增车辆">新增车辆</el-radio-button>
						<el-radio-button label="活跃车辆">活跃车辆</el-radio-button>
						<el-radio-button label="启动次数">启动次数</el-radio-button>
						<el-radio-button label="累计车辆">累计车辆</el-radio-button>
					</el-radio-group>
				</div>
				<div class="TopthemeRightData">
					<div id="applyData4" :style="{width: '100%', height: '100%'}"></div>
				</div>
			</div>
		</div>
		<div class="TopthemeLeft" ref="box">
			<div class="tit">TOP渠道
				<p>?</p>
				<div class="themeUseTitleTab">
					<el-radio-group v-model="TopthemeLeftTab">
						<el-radio-button label="新增车辆">新增车辆</el-radio-button>
						<el-radio-button label="活跃车辆">活跃车辆</el-radio-button>
						<el-radio-button label="启动次数">启动次数</el-radio-button>
						<el-radio-button label="累计车辆">累计车辆</el-radio-button>
					</el-radio-group>
				</div>
				<div class="TopthemeLeftData">
					<div id="applyData5" :style="{width: '100%', height: '100%'}"></div>
				</div>
			</div>
		</div>
	</div>
</template>
<script src="./index.js">
</script>
<style scoped="scoped" src="./index.less" lang="less">

</style>