<template>
	<div class="Theme">
		<div class="themeContainer">
			<div class="themeManage" :class="{'nothemeManage':isqudao}">
				<div class="themeManageTop">
					<p class="themeManageTitle">主题管理</p>
				</div>
				<div class="themeManageMain" v-if='!isqudao'>
					<div class="selectModel channelModel">
						<label class="channel">渠道:</label>
						<el-select v-model="qudaostr" placeholder="请选择" @focus='getqudao' @change='savequdao' clearable>
							<el-option v-for="item in qudao" :key="item.id" :label="item.name" :value="item.id">
							</el-option>
						</el-select>
					</div>
				</div>
			</div>
			<div class="themeUse">
				<div class="themeUseTop">
					<p class="themeUseTitle">主题使用TOP5</p>
					<div class="themeUseTitleTab">
						<el-radio-group v-model="tabPosition">
							<el-radio-button label="昨天">昨天</el-radio-button>
							<el-radio-button label="近一周">近一周</el-radio-button>
							<el-radio-button label="近30天">近30天</el-radio-button>
						</el-radio-group>
					</div>
				</div>
				<div class="themeUseMain">
					<div id="pie" :style="{width:'100%',height:'100%'}"> </div>
				</div>
			</div>
			<div class="themeTrend">
				<div class="themeTrendTop">
					<p class="themeTrendTitle">有效主题趋势</p>
					<div class="themeTrendTitleTab">
						<el-date-picker v-model="value6" type="daterange" range-separator="至" start-placeholder="开始日期" end-placeholder="结束日期">
						</el-date-picker>
					</div>
				</div>
				<div class="themeTrendMain">
					<div id="line" :style="{width: '100%', height: '100%'}"></div>
					<div class="choseUse">
						<div class="choseUseTop">
							<p class="choseUseTitle">选择渠道</p>
							<div class="choseUseTitle choseUseTitleLimit">
								(最多选择<span class="choseNum">10</span>个渠道)
							</div>
						</div>
						<div class="choseUseMain">
							<div>
								<el-input placeholder="搜索渠道..." prefix-icon="el-icon-search" v-model="input21">
								</el-input>
							</div>
							<ul class="choseSelect">
								<li class="choseOption">百度</li>
								<li class="choseOption">360渠道</li>
								<li class="choseOption">腾讯手机</li>
								<li class="choseOption">易鑫</li>
								<li class="choseOption">滴滴</li>
							</ul>
						</div>
					</div>
					<div class="channelChange">切换渠道</div>
				</div>
			</div>
			<div class="themeTable">
				<div class="themeTableTop">
					<div class="selectModel">
						<label class="channel">主题分类:</label>
						<el-select clearable v-model="category" placeholder="请选择" @focus='getthemeOptions'>
							<el-option v-for="item in themeOptions" :key="item.id" :label="item.classificationName" :value="item.id">
							</el-option>
						</el-select>
					</div>
					<div class="selectModel" v-if='isqudao'>
						<label class="channel">launcher版本:</label>
						<el-select clearable v-model="version" placeholder="请选择" @focus='getversionArr'>
							<el-option v-for="item in versionArr" :key="item.attributeKeyIndex" :label="item.attributeValue" :value="item.attributeKeyIndex">
							</el-option>
						</el-select>
					</div>
					<div class="selectModel">
						<label class="channel">上架状态:</label>
						<el-select clearable v-model="state" placeholder="请选择">
							<el-option v-for="item in isOn" :key="item.value" :label="item.label" :value="item.value">
							</el-option>
						</el-select>
					</div>
					<div class="selectModel">
						<label class="channel">主题名称:</label>
						<el-input placeholder="请输入内容" v-model="themeName" clearable>
						</el-input>
					</div>
					<button type="button" class="el-button el-button--primary btnSearch btncolor_a" @click="saveQuery">搜索</button>
				</div>
				<div class="searchBox">
					<div class="buttonBox">
						<button type="button" class="el-button el-button--primary  btnBox" @click="showcheck">{{operatemsg}}</button>
						<button type="button" class="el-button el-button--primary  btnBox" @click="newtheme" v-if="newFlag">新建主题</button>
					</div>
				</div>
				<div class="themeTableMain">
					<div class="themeTableModel">
						<el-table element-loading-text="数据加载中..." v-loading="loading" ref="multipleTable" :data="tableData3" tooltip-effect="dark" style="width: 100%" @selection-change="handleSelectionChange">
							<el-table-column type="selection" width="55" v-if='isshowcheck'>
							</el-table-column>
							<el-table-column label="主题ID" type="index" :index="indexMethod" width="80">
							</el-table-column>
							<el-table-column prop="channelName" label="渠道" width="70" v-if='!isqudao'>
							</el-table-column>
							<el-table-column label="版本" width="70" v-if='isqudao'>
								<template slot-scope="scope">
									{{scope.row.versionName}}
								</template>
							</el-table-column>
							<el-table-column prop="typeName" label="主题分类" show-overflow-tooltip width="80">>
							</el-table-column>
							<el-table-column label="主题名称" show-overflow-tooltip>
								<template slot-scope="scope">
									<span :title="scope.row.title">{{scope.row.title}}</span>
								</template>
							</el-table-column>
							<el-table-column label="主题起止时间" show-overflow-tooltip width="120">
								<template slot-scope="scope">
									<div v-if='scope.row.startTime&&scope.row.endTime'>
										<p>从{{get_Timer(new Date(scope.row.startTime))}}</p>
										<p>至{{get_Timer(new Date(scope.row.endTime))}}</p>
									</div>
									<div v-else>
										--
									</div>
								</template>
							</el-table-column>
							<el-table-column prop="status" label="上架状态" show-overflow-tooltip width="80">
							</el-table-column>
							<el-table-column label="操作" width="400">
								<template slot-scope="scope">
									<el-button size="mini" @click="preView(scope.$index, scope.row)" v-if="previewFlag && !(scope.row.status=='暂存')">预览</el-button>
									<el-button size="mini" @click="shangjiaxia(scope.$index, scope.row)" v-if="groundFlag && !(scope.row.status=='暂存')">{{scope.row.msg}}</el-button>
									<el-button size="mini" @click="handleEdit(scope.$index, scope.row)" v-if="editFlag && scope.row.isShow">编辑</el-button>
									<el-button size="mini" @click="creatCopy(scope.$index, scope.row)" v-if="createFlag && !(scope.row.status=='暂存')">创建副本</el-button>
									<el-button size="mini" type="danger" @click="handleDelete(scope.$index, scope.row)" v-if="deleteFlag && scope.row.isShow">删除</el-button>
								</template>
							</el-table-column>
						</el-table>
						</el-table>

					</div>
					<div class="selectAllBox" v-if="isshowcheck">
						<div class="selectAll">
						</div>
						<div class="selectAllBtn">
							<button type="button" class="el-button el-button--primary " style="width:60px;height:24px;background: #84A1E5;border-color:#84A1E5" @click="pshang">上架</button>
							<button type="button" class="el-button el-button--primary" style="background:#85CAC2;border-color:rgb(133, 202, 194)" @click="pxia">下架</button>
						</div>
					</div>
					<div class="tableFooter" v-if="isshowfoot">
						<span class="footTitle">共<span class="spantotal">{{totalNum}}</span>条记录，每页<span class="spansize">10</span>条</span>
						<button type="button" class="el-button el-button--primary btnSearch btn" style="border-color:#85CAC2;margin:3px;line-height:3px;float: right;">确定</button>
						<el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange" :current-page="currentpage" :page-size="pazeSize" layout=" prev, pager, next, jumper" :total="totalNum">
						</el-pagination>
					</div>
				</div>
			</div>
			<!--弹窗-->
			<el-dialog :title="preTitle" :visible.sync="dialogpreview">
				<div class="top">
					<div class="left">
						<div class="img_box">
							<img :src="imgbaseUrl+themeimg" alt="" />
						</div>
					</div>
					<div class="righta">
						<div class="banben">
							<div class="topban">
								<span class="spanname">渠道：</span> <span>{{theme.channelName}}</span>
							</div>
							<div class="topban">
								<span class="spanname">版本：</span> <span>{{theme.versionName}}</span>
							</div>
							<div class="botban">
								<span class="spanname">文件大小：</span> <span>{{get_Byte(theme.fileSize)}}</span>
							</div>
							<div class="botban">
								<span class="spanname">主题起止时间：</span>
								<p style="margin-top: 5px;">{{itemstarttime}}</p>
								<p style="margin-top: 3px;">{{itemendtime}}</p>
							</div>
						</div>

					</div>
				</div>
				<div class="xuxian">

				</div>
				<div class="bot">
					<div class="imgitem" v-for="(item,index) in file">
						<img :src="imgbaseUrl+item.filePath" alt="" />
					</div>
				</div>
			</el-dialog>

		</div>
	</div>
</template>
<script src="./index.js">
</script>
<style scoped="scoped" src="./index.less" lang="less"></style>