import axios from "@/axios.js"
import './gridstack.css' //底屏css
import './gridstack1.css' //滚动屏css
import bus from "@/bus.js";
import storeData from '@/vuex/store.js';
export default {
	data() {
		return {
			scrollStyle: 0, //滚动方式 0左右 1上下
			showGrid: false, //是否显示grid
			setscreen: false, //控制底屏样式与widget样式切换flag
			imageUrl: '', //预览图
			isnine: false, //是否.9图
			scrollType: [{ //滚动方式数组
				"label": "左右滚动",
				"value": 0,
			}, {
				"label": "上下滚动",
				"value": 1,
			}, ],
			setscrStyle: { //底屏样式相关初始化
				background: '#ffffff',
				width: 580,
				height: 320,
				row: 20,
				col: 20,
				selscaleType: '1',
				alignType: 'LT',
				backGrounditem: {
					"color": '#ffffff',
					"image": '',
					"scaleType": '1',
					"alignType": 'LT'
				}
			},
			scrolSetscrStyle: { //滚屏样式初始化
				width: 580,
				height: 350,
				row: 20,
				col: 20,
				x: 0,
				y: 0
			},
			defaultStyle: { //底屏style 初始化
				width: '580px',
				height: '350px !important',
				'margin-left': '-290px'
			},
			scrollStyel: { //滚动屏style 初始化
				width: '0px',
				height: '0px !important',
				top: '0px',
				left: '0px'
			},
			scrollAert: false, //控制弹窗grid
			addFlag: false, //添加widget到哪个屏的控制
			scrollbackflag: false, // 退出滚动屏
			scrollArr: [], //判断是否是滚动屏还是底屏
			ScrollWidgets: { //滚屏widget
				isScroll: 1, //是否是滚屏
				x: 0,
				y: 0,
				height: '5',
				width: '3',
				file: {
					"2a26f1e625d801d5.png": "group1/M00/00/0F/wKgJElr-o-2AAx4DAADfqQeCRbo391.png",
				},
				name: '滚动屏',
				backgroud: "2a26f1e625d801d5.png",
				setting: {
					col: 10,
					row: 10,
					direct: 0
				}
			},
			activeName: '1', //左侧手风琴菜单默认激活项
			scrollFlag: false, //是否显示滚动屏
			scrollMsg: '', //进入或退出编辑的msg
			options: { //底屏的grid初始化
				cell_height: 100, //单元格的高度。默认值为60。
				animate: true, //转换为动画。默认为false。
				vertical_margin: 0,
				acceptWidgets: false,
				//				ddPlugin:true,
				auto: false, //如果设置为false将不会初始化已经存在的项。默认为true。
				// draggable：允许覆盖 jQuery UI draggable 选项。默认值：{handle: '.grid-stack-item-content', scroll: true, appendTo: 'body'}。
				always_show_resize_handle: false, //如果设置为true，缩放手柄将会一直显示。默认为false。
				handle: '.grid-stack-item-content', //拖放手柄选择器。默认值为：'.grid-stack-item-content'。
				height: 10, //最大行数。默认为0，意思是没有最大行数。
				width: 10, //网格的列数。默认值为12。
				float: true, //允许元素浮动。默认值：false。
				item_class: 'grid-stack-item', //元素组件的class。默认值'grid-stack-item'。
				min_width: 768, //最小宽度。如果窗口的宽度小于网格的宽度，将会以单列显示。默认值为768。
				placeholder_class: 'grid-stack-placeholder', //placeholder的class。默认值为'grid-stack-placeholder'。
				resizable: {
					autoHide: true,
					handles: 'se'
				}, //允许覆盖jQuery UI resizable选项。默认值为：{autoHide: true, handles: 'se'}。
				//网格属性
				//            data-gs-animate:true,
			},
			scrollOptions: { //滚动屏的grid初始化
				cell_height: 20, //单元格的高度。默认值为60。
				animate: true, //转换为动画。默认为false。
				vertical_margin: 0,
				acceptWidgets: false,
				//				ddPlugin:true,
				auto: false, //如果设置为false将不会初始化已经存在的项。默认为true。
				// draggable：允许覆盖 jQuery UI draggable 选项。默认值：{handle: '.grid-stack-item-content', scroll: true, appendTo: 'body'}。
				always_show_resize_handle: false, //如果设置为true，缩放手柄将会一直显示。默认为false。
				handle: '.grid-stack-item-content', //拖放手柄选择器。默认值为：'.grid-stack-item-content'。
				height: 5, //最大行数。默认为0，意思是没有最大行数。
				width: 10, //网格的列数。默认值为12。
				float: true, //允许元素浮动。默认值：false。
				item_class: 'grid-stack-item', //元素组件的class。默认值'grid-stack-item'。
				min_width: 768, //最小宽度。如果窗口的宽度小于网格的宽度，将会以单列显示。默认值为768。
				placeholder_class: 'grid-stack-placeholder', //placeholder的class。默认值为'grid-stack-placeholder'。
				resizable: {
					autoHide: true,
					handles: 'se'
				}, //允许覆盖jQuery UI resizable选项。默认值为：{autoHide: true, handles: 'se'}。
				//网格属性
				//            data-gs-animate:true,
			},
			meundata: [], //widget菜单数据
			meunposter: [], //poster 菜单数据
			pushdata: [], //底屏数据保存
			scrollPushdata: [{ //滚动屏数据保存
				data: []
			}],
			scrollCurindex: 0, //当前滚动屏
			setattribute: {}, //右侧属性			
			//从widget拿过来
			fengmian: '', //封面
			fontStyle: ["italic", "bold", "underline", "deleteline"], //字体
			alignType: [{ //对其方式
					"label": "左上",
					"value": "LT"
				},
				{
					"label": "左下",
					"value": "LB"
				},
				{
					"label": "右上",
					"value": "RT"
				},
				{
					"label": "右下",
					"value": "RB"
				},
				{
					"label": "顶部居中",
					"value": "THC"
				},
				{
					"label": "底部居中",
					"value": "BHC"
				},
				{
					"label": "左侧居中",
					"value": "LVC"
				},
				{
					"label": "右侧居中",
					"value": "RVC"
				},
				{
					"label": "居中",
					"value": "CENTER"
				}
			],

			scaleType: [{ //伸缩
					"label": "拉伸填充",
					"value": "FIT_XY",
					"ident": "1"
				},
				{
					"label": "原图居中",
					"value": "CENTER",
					"ident": "5"
				},
				{
					"label": "剪切居中",
					"value": "CENTER_CROP",
					"ident": "6"
				},
				{
					"label": "缩小居中",
					"value": "CENTER_INSIDE",
					"ident": "7"
				},
				{
					"label": "左上",
					"value": "FIT_START",
					"ident": "2"
				},
				{
					"label": "居中",
					"value": "FIT_CENTER",
					"ident": "3"
				},
				{
					"label": "右下",
					"value": "FIT_END",
					"ident": "4"
				}
			],
			img: "", //5个图片
			currentindex: -1, //当前页初始化
			formdatasend: { //向后台传值的themeJson初始化
				id: ''
			},
			widgetCategory: '', //当前选择类型
			widgetCategoryList: [], //widgets列表
			uploadToken: {}, //上传的token
			copypushdata: [], //回显pushdata用
			copyscrollpushdata: [{
				data: []
			}], //回显滚屏数据
			preImgurl: '', //预览图
			countZindex: 0, //滚屏计数
			currentDom: {}, //当前dom对象
			whichdelScr: 0, //0代表删除的是从底屏，1代表是从滚屏删除
		}
	},
	created() { //实例挂载之前		
		this.setStyle(); //底屏样式初始化
		this.getWidgetsmeun();
		this.getMeunposter();
		this.getUsermsg();
		bus.$on('getNewdata', (e) => { //获取组件外实时传值
			this.formdatasend = Object.assign(this.formdatasend, e);
		})
		bus.$on('EditorCopy', (e) => { //编辑或者创建副本获取组件外实时传值
			this.copypushdata = e.widgetJson;
			this.setscrStyle = e.screeStyle;
			if(this.setscrStyle.hasOwnProperty('file')) { //判断是否有file属性
				this.imageUrl = this.imgbaseUrl + this.setscrStyle.file[this.setscrStyle.backGrounditem.image];
			}
			if(e.widgetJson.length) { //判断是否有传过来的widgetJson数组
				for(let i in e.widgetJson) {
					if(e.widgetJson[i].isScroll) { //判断是否有滚屏
						this.scrollStyle = e.widgetJson[i].setting.direct;
						if(e.widgetJson[i].widgets.length) { //判断是否滚屏内数据有
							this.copyscrollpushdata = [];
							for(let j in e.widgetJson[i].widgets) {
								this.copyscrollpushdata.push(e.widgetJson[i].widgets[j])
							}
							this.scrollArr.length = 1;
						} else {
							this.copyscrollpushdata = [{ //滚动屏数据保存
								data: []
							}];
						}
					}
				}
			} else {
				this.copyscrollpushdata = [{ //滚动屏数据保存
					data: []
				}];
			}
			this.setInitscreen(e.wideResolution, e.longResolution, e.longPalace, e.widePalace);

		})
		bus.$on('Changescreen', (e) => { //获取组件外实时传值 设置底屏大小		
			this.setInitscreen(e.wideResolution, e.longResolution, this.setscrStyle.row, this.setscrStyle.col)
		})

		bus.$on('setScreenstyle', (e) => { //设置底屏行列数
			$('.grid-stack').data('gridstack').remove_all();
			this.pushdata = [];
			this.scrollPushdata = [{ //滚动屏数据保存
				data: []
			}];
			this.scrollAert = false;
			this.scrollFlag = false;
			this.scrollbackflag = false;
			this.scrollArr = [];
			this.scrollCurindex = 0;
			this.preImgurl = ''; //清空背景图
			this.copyscrollpushdata = [{ //滚动屏数据保存
				data: []
			}];
			this.copypushdata = [];
			this.setscrStyle.row = e.widthinputgg;
			this.setscrStyle.col = e.heightinputgg;
			this.getDefaultstyle(this.setscrStyle.width, this.setscrStyle.height, this.setscrStyle.row, this.setscrStyle.col)
		})

		bus.$on('setScrolltyle', (e) => { //设置底屏行列数
			if(this.scrollPushdata.length == 1 && this.scrollPushdata[0].data.length == 0) {
				for(let i = 0; i < this.pushdata.length; i++) {
					if(this.pushdata[i].isScroll) {
						this.pushdata[i].setting.row = Number(e.widthscroll);
						this.pushdata[i].setting.col = Number(e.heighscroll);
					}
				}
			} else {
				this.$message({
					message: '滚动屏内有数据，不允许调整行列数',
					type: 'warning'
				});
			}
		})

	},
	mounted() { //实例挂载之后
		let viewPortWidth = $('.viewPort').outerWidth();
		this.setscrStyle.width = viewPortWidth;
		this.setscrStyle.height = this.setscrStyle.width * 0.6;
		this.getDefaultstyle(this.setscrStyle.width, this.setscrStyle.height, this.setscrStyle.row, this.setscrStyle.col) //调取初始底屏方法
		//echarts画出宫格
		var that = this;
		//获取widgets
		this.getwidgets();
		var serializeWidgetMap = function(item) {
			$.each(that.pushdata, function(value, key) {
				if(item.length) {
					if($(item[0].el[0]).attr('data-uid') == key.Uid) {
						key.x = item[0].x;
						key.y = item[0].y;
						key.height = item[0].height.toString();
						key.width = item[0].width.toString();
						key.Uid = $(item[0].el).attr('data-uid');
						key.isScroll = parseInt($(item[0].el).attr('data-gs-isScroll'));
						if(!(key.isScroll || key.isPoster)) {

						}
						that.setattribute = key;
					}
				} else {
					return;
				}
			});
		};
		$('.grid-stack').on('change', (event, item) => {
			$('.grid-stack-item').css({
				"border": "none",
			});
			if(item.length) {
				let el = $(item[0].el[0]);
				el.css({
					"border": "1px solid #BFBFBF",
					"z-index": JSON.parse(el.attr('data-all')).Zindex
				});
			} else { //逻辑
				that.currentDom.css({
					"border": "1px solid #BFBFBF",
					"z-index": JSON.parse(that.currentDom.attr('data-all')).Zindex
				});
			}
			serializeWidgetMap(item);
			this.setscreen = false;
		});
		//滚动屏存储数据
		var scrollserializeWidgetMap = function(item) {
			$.each(that.scrollPushdata[that.scrollCurindex].data, function(value, key) {
				if(item.length) {
					if($(item[0].el[0]).attr('data-uid') == key.Uid) {
						key.x = item[0].x;
						key.y = item[0].y;
						key.height = item[0].height.toString();
						key.width = item[0].width.toString();
						key.Uid = $(item[0].el).attr('data-uid');
						that.setattribute = key;
					}
				} else {
					return;
				}
			});
		};
		$('.grid-stack1-box').on('change', '.grid-stack1', (event, item) => { //v-if 事件委托		
			$('.grid-stack-item').css({
				"border": "none",
			});
			if(item.length) {
				let el = $(item[0].el[0]);
				el.css({
					"border": "1px solid #BFBFBF",
					"z-index": JSON.parse(el.attr('data-all')).Zindex
				});
			} else { //逻辑
				that.currentDom.css({
					"border": "1px solid #BFBFBF",
					"z-index": JSON.parse(that.currentDom.attr('data-all')).Zindex
				});
			}
			scrollserializeWidgetMap(item);
			this.setscreen = false;
		});

		//事件委托点击底屏单个widget
		$('.grid-stack').on('click', '.grid-stack-item', function() {
			storeData.state.showScroll = false;
			that.setscreen = false;
			that.currentDom = $(this);
			that.whichdelScr = 0;
			let currentdom = $(this);
			$('.grid-stack-item').css({
				"border": "none",
			});
			currentdom.css({
				"border": "1px solid #BFBFBF",
			});
			//点击事件触发右边属性
			$.each(that.pushdata, function(value, key) {
				if(currentdom.attr('data-uid') == key.Uid) {
					key.x = parseInt(currentdom.attr('data-gs-x'));
					key.y = parseInt(currentdom.attr('data-gs-y'));
					key.height = currentdom.attr('data-gs-height');
					key.width = currentdom.attr('data-gs-width');
					key.Uid = currentdom.attr('data-uid');
					key.isScroll = parseInt(currentdom.attr('data-gs-isScroll'));
					if(!(key.isScroll || key.isPoster)) {

					}
					that.setattribute = key;
				}
			});
			if($(this).attr('data-gs-isscroll') == 1) {
				storeData.state.showScroll = true;
			}
		})
		//mouseup记录当前操作dom--底屏
		$('.grid-stack').on('mouseup', '.grid-stack-item', function() {
			that.currentDom = {};
			storeData.state.showScroll = false;
			that.setscreen = false;
			that.currentDom = $(this);
		})

		//mouseup记录当前操作dom--滚屏
		$('.grid-stack1-box').on('mouseup', '.grid-stack1 .grid-stack-item', function() {
			that.currentDom = {};
			storeData.state.showScroll = false;
			that.setscreen = false;
			that.currentDom = $(this);
		})

		//事件委托点击滚动屏单个widget
		$('.grid-stack1-box').on('click', '.grid-stack1 .grid-stack-item', function() {
			storeData.state.showScroll = false;
			that.setscreen = false;
			let currentdom = $(this);
			that.currentDom = $(this);
			that.whichdelScr = 1;
			$('.grid-stack-item').css({
				"border": "none",
			});
			currentdom.css({
				"border": "1px solid #BFBFBF",
			});
			//点击事件触发右边属性
			$.each(that.scrollPushdata[that.scrollCurindex].data, function(value, key) {
				if(currentdom.attr('data-uid') == key.Uid) {
					key.x = parseInt(currentdom.attr('data-gs-x'));
					key.y = parseInt(currentdom.attr('data-gs-y'));
					key.height = currentdom.attr('data-gs-height');
					key.width = currentdom.attr('data-gs-width');
					key.Uid = currentdom.attr('data-uid');
					key.isScroll = parseInt(currentdom.attr('data-gs-isScroll'));
					that.setattribute = key;
				}
			});
		})
		this.scrollAert = false; //弹窗grid不显示
	},
	methods: { //方法
		setInitscreen(w, h, row, col) { //设置底屏初始化，编辑与创建副本时用
			this.pushdata = [];
			$('.grid-stack').data('gridstack').remove_all();
			if(this.$route.path == '/theme/addtheme') {
				this.scrollPushdata = [{ //滚动屏数据保存
					data: []
				}];
			} else {
				this.scrollPushdata = this.copyscrollpushdata;
			};
			this.scrollAert = false;
			this.scrollFlag = false;
			this.scrollbackflag = false;
			this.setscrStyle.width = w;
			this.setscrStyle.height = h;
			let viewPortWidth = $('.viewPort').outerWidth();
			let percent = Math.min(this.setscrStyle.width, this.setscrStyle.height) / Math.max(this.setscrStyle.width, this.setscrStyle.height)
			let minnum = percent * viewPortWidth;
			let maxnum = Math.max(this.setscrStyle.width, this.setscrStyle.height);
			this.setscrStyle.width = (maxnum == this.setscrStyle.width) ? viewPortWidth : minnum;
			this.setscrStyle.height = (maxnum == this.setscrStyle.height) ? viewPortWidth : minnum;
			this.getDefaultstyle(this.setscrStyle.width, this.setscrStyle.height, row, col);
		},
		changeAlign(value) { //改变对齐
			this.alignTypeCheckId = value
		},
		changeScale(value) { //改变缩放
			this.scaleTypeCheckId = value
		},
		getUsermsg() { //获取当前登录人用户信息
			let token = sessionStorage.getItem('Token');
			this.uploadToken = {
				Authorization: token
			};
		},
		clearWidget() { //删除当前widget
			//			console.log(this.currentDom)
			let dom = this.currentDom;
			if(dom[0] != undefined) {
				if(!this.whichdelScr) { //从底屏删除
					this.setscreen = true;
					if($(dom).attr('data-gs-isscroll')) {
						this.scrollArr = [];
						this.scrollFlag = false;
						this.scrollPushdata = [{ //滚动屏数据删除
							data: []
						}];
						this.copyscrollpushdata = [{ //滚动屏数据删除
							data: []
						}];
						this.scrollCurindex = 0;
						this.preImgurl = ''; //清空背景图
					}
					$('.grid-stack').data('gridstack').remove_widget(dom);
					this.currentDom = {};
					this.setattribute = {};
					this.getupdatedata();
				} else { //从滚屏删除
					$('.grid-stack1').data('gridstack').remove_widget(dom);
					this.currentDom = {};
					this.setattribute = {};
					this.scrollgetupdatedata();
				}
			} else {
				this.$message({
					message: '请先选中要删除的widget！',
					type: 'warning'
				});
			}

		},
		quit() { //退出
			this.$router.push({
				path: '/theme/index'
			})
		},
		changback() { //背景色选择并存值
			this.setscrStyle.backGrounditem.color = this.setscrStyle.background;
		},
		changesetscrStyle() { //选中值
			this.setscrStyle.backGrounditem.scaleType = this.setscrStyle.selscaleType;
			this.setscrStyle.backGrounditem.alignType = this.setscrStyle.alignType;
		},
		changeScroll() { //改变滚屏滚动方式
			for(let i in this.pushdata) {
				if(this.pushdata[i].isScroll) {
					this.pushdata[i].setting.direct = this.scrollStyle;
				}
			}
		},
		handleAvatarSuccess1(res, file) { //主题上传成功并做.9图校验
			this.isnine = false;
			this.imageUrl = URL.createObjectURL(file.raw);
			let picname = new Date().getTime() + file.name.slice(file.name.lastIndexOf('.') - 2, file.name.length);
			this.isnine = file.name.slice(file.name.lastIndexOf('.') - 2, file.name.lastIndexOf('.')) == '.9';
			this.setscrStyle.isnine = this.isnine;
			let filecreat = {

			}
			filecreat[picname] = res;
			this.setscrStyle.file = filecreat;
			if(this.isnine) {
				this.setscrStyle.backGrounditem = {
					"color": this.setscrStyle.background,
					"image": picname,
				}
			} else {
				this.setscrStyle.backGrounditem = {
					"color": this.setscrStyle.background,
					"image": picname,
					"scaleType": this.setscrStyle.selscaleType,
					"alignType": this.setscrStyle.alignType
				}
			}
		},
		beforeAvatarUpload1(file) { //上传前校验
			const isJPG = file.type === 'image/jpeg';
			const isPNG = file.type === 'image/png';
			if(!isJPG && !isPNG) {
				this.$message.error('上传封面图片只能是 JPG、PNG 格式!');
			}
			return isJPG || isPNG;
		},
		getWidgetsmeun() { //获取widgets菜单数据
			let uType = JSON.parse(sessionStorage.getItem('userMsg')).userType
			if(uType == 0 || uType == 2) {
				uType = 0;
			} else {
				uType = 1;
			}
			let data = {
				params: {
					type: uType,
					pageSize: 9999999
				}
			}
			axios.get('/system/findWidgetsList', data)
				.then((res) => {
					this.meundata = res.data.data.list;
					for(let i in this.meundata) {
						this.meundata[i].titleMsg = this.meundata[i].name + '(' + this.meundata[i].defaultSize + ')';
					}
				})
				.catch(err => {
					console.log(err);
				});
		},
		getMeunposter() { //获取poster菜单数据
			let data = {
				params: {
					type: 0
				}
			}
			axios.get('/system/application/select', data)
				.then((res) => {
					this.meunposter = res.data.data
					for(let i in this.meunposter) {
						this.meunposter[i].titleMsg = this.meunposter[i].name + '(' + this.meunposter[i].width + 'x' + this.meunposter[i].height + ')'
					}
				})
				.catch(err => {
					console.log(err);
				});
		},
		screenSet() { //是否设置底屏样式
			this.setscreen = true;
			storeData.state.showScroll = false;

		},
		getDefaultstyle(w, h, wp, hp) { //绘制底屏宫格 初始化dom屏宽高-->参数依次为 宽 高 、行列比	
			w = Number(w);
			h = Number(h);
			wp = Number(wp);
			hp = Number(hp);
			w = w - wp - 1;
			h = h - hp - 1;
			this.defaultStyle = {
				width: w + 'px',
				height: h + 'px !important',
				//				'margin-left': -w / 2 + 'px'
			}
			//初始化底屏options的格子高以及分的行列
			this.options.cell_height = h / hp;
			this.options.height = hp;
			this.options.width = wp;
			this.setStyle();
			$('.grid-stack').gridstack(this.options);
			this.showGrid = false;
			setTimeout(() => {
				this.showGrid = true;
				this.$nextTick(() => {
					this.getgrids(this.$refs.screenon, w, w / wp, h, h / hp);
					this.getupdatedata();
					if(this.$route.path != '/theme/addtheme') {
						this.pushdata = this.copypushdata; //回显数据可能要加路由判断
						if(this.copyscrollpushdata.length) {
							this.scrollFlag = true;
						}
					}
					this.getwidgets();
				})
			}, 500)
		},
		scrollgetDefaultstyle(w, h, t, l, ) { //初始化滚屏样式封装
			this.scrollStyel = {
				width: w + 'px',
				height: h + 'px !important',
				top: t + 'px',
				left: l + 'px'
			}
			if(this.$route.path != '/theme/addtheme') {
				this.scrollPushdata = this.copyscrollpushdata;
			}

		},
		setStyle() { //获取底屏样式
			this.less.render(`@flag:${this.options.width};
					.loop( @count,@i:@flag )when( @count >0) {
					    .grid-stack-item[data-gs-width= "@{count}"] {
					         width: (@count * 100% / @i); 
					    }
					    .grid-stack-item[data-gs-x= "@{count}"] {
					         left: (@count * 100% / @i); 
					    }
					    .grid-stack-item[data-gs-min-width= "@{count}"] {
					         width: (@count * 100% / @i); 
					    }
					    .grid-stack-item[data-gs-max-width= "@{count}"] {
					         width: (@count * 100% / @i); 
					    }    
					    .loop((@count - 1));
					}
					
					.grid-stack {
					    .loop(@flag);
					}`, function(e, output) {
				var doc = document;
				var style = doc.createElement("style");
				style.setAttribute("type", "text/css");
				if(style.styleSheet) { // IE  
					style.styleSheet.cssText = output.css;
				} else { // w3c  
					var cssText = doc.createTextNode(output.css);
					style.appendChild(cssText);
				}

				var heads = doc.getElementsByTagName("head");
				if(heads.length)
					heads[0].appendChild(style);
				else
					doc.documentElement.appendChild(style);
			});
		},
		scrollsetStyle() { //获取底屏样式
			this.less.render(`@flag:${this.scrollOptions.width};
					.loop( @count,@i:@flag )when( @count >0) {
					    .grid-stack-item[data-gs-width= "@{count}"] {
					         width: (@count * 100% / @i); 
					    }
					    .grid-stack-item[data-gs-x= "@{count}"] {
					         left: (@count * 100% / @i); 
					    }
					    .grid-stack-item[data-gs-min-width= "@{count}"] {
					         width: (@count * 100% / @i); 
					    }
					    .grid-stack-item[data-gs-max-width= "@{count}"] {
					         width: (@count * 100% / @i); 
					    }    
					    .loop((@count - 1));
					}
					
					.grid-stack1 {
					    .loop(@flag);
					}`, function(e, output) {
				var doc = document;
				var style = doc.createElement("style");
				style.setAttribute("type", "text/css");
				if(style.styleSheet) { // IE  
					style.styleSheet.cssText = output.css;
				} else { // w3c  
					var cssText = doc.createTextNode(output.css);
					style.appendChild(cssText);
				}

				var heads = doc.getElementsByTagName("head");
				if(heads.length)
					heads[0].appendChild(style);
				else
					doc.documentElement.appendChild(style);
			});
		},
		addScrollWidget(item) { //添加滚屏
			this.setattribute = item;
			this.setscreen = false;
			this.countZindex++;
			item.appId = '';
			if(this.scrollArr.length > 0) {
				return false;
			} else {
				this.getupdatedata();
				this.getmaxnum(this.pushdata);
				let newselmax = [];
				//寻找最大值
				for(let i in this.pushdata) {
					newselmax.push(this.pushdata[i].Zindex)
				}
				if(newselmax.length > 0) {
					this.countZindex = Math.max.apply(null, newselmax) + 1;
				}
				this.scrollArr.push(Object.assign({}, item, {
					'Uid': new Date().getTime().toString(),
					'codeId': item.codeId,
					'id': item.id,
					'Zindex': this.countZindex

				}));
				this.pushdata.push(Object.assign({}, item, {
					'Uid': new Date().getTime().toString(),
					'codeId': item.codeId,
					'id': item.id,
					'Zindex': this.countZindex
				}));
				this.getwidgets();
			}
			this.scrollFlag = true;
		},
		scrollEdit() { //进入滚动屏编辑
			this.scrollAert = true;
			this.scrollbackflag = true;
			this.addFlag = true;
			this.scrollFlag = false;
			storeData.state.showScroll = false;
			//获取滚动面板的位置和比例
			if(this.scrollAert) {
				this.$nextTick(() => { //等dom更新绘画格子							
					$.each(this.pushdata, (index, value) => {
						if(value.isScroll) {
							let w = parseFloat(this.defaultStyle.width) * value.width / this.options.width;
							let h = value.height * this.options.cell_height;
							let t = value.y * this.options.cell_height;
							let l = value.x * parseFloat(this.defaultStyle.width) / this.options.width;
							this.scrollgetDefaultstyle(w, h, t, l)
							this.scrollOptions.cell_height = h / value.setting.col;
							this.scrollOptions.height = value.setting.col;
							this.scrollOptions.width = value.setting.row;
							this.scrolSetscrStyle = {
								width: value.width,
								height: value.height,
								row: value.setting.row,
								col: value.setting.col,
								x: value.x,
								y: value.y
							};
							this.$nextTick(() => {
								this.scrollsetStyle(); //调取滚动屏css
								$('.grid-stack1').gridstack(this.scrollOptions); //初始化grid滚动屏								
								this.getgrids(this.$refs.screenon1, value.setting.row, 1, value.setting.col, 1); //初始化宫格								
								this.scrollgetwidgets(); //回显数据
							})
						}
					});
				})
			}
		},
		scrollBack() { //退出滚动屏
			$('.grid-stack-item').css({
				"border": "none",
			});
			if(!this.scrollPushdata[this.scrollCurindex].data.length) {
				$('.scrollflag').attr('style', '');
			} else {
				$('.scrollflag').attr('style', '')
				this.getPicture($('.grid-stack1')[0], (url) => {
					this.preImgurl = url;
					$('.scrollflag').attr('style', 'background:url(' + url + ') no-repeat center;background-size: 100% 100%;')

				}); //转图片
			}
			this.scrollAert = false;
			this.scrollFlag = true;
			this.addFlag = false;
			this.scrollbackflag = false;

		},
		preScroll() { //滚动屏上一屏
			if(this.scrollCurindex > 0) { //有空屏点回退清空
				if(!this.scrollPushdata[this.scrollCurindex].data.length) {
					this.scrollPushdata.splice(this.scrollCurindex, 1)
				}
				this.scrollCurindex--;
			}
			//调用生成原图
			this.scrollgetwidgets();
		},
		nexScroll() { //滚动屏下一屏
			//递增到第几屏，更新数据结构
			this.scrollCurindex++;
			if(this.scrollCurindex > this.scrollPushdata.length - 1) { //如果长度大于存储数据长度-1，则新增加一个滚动屏
				this.scrollPushdata.push({
					data: []
				});
			}
			this.scrollgetwidgets();
		},
		saveDate(type) { //触发store保存验证flag
			storeData.state.themeClick++;
			storeData.state.themeType = type;
		},
		savetrueDate(type) { //保存数据 0暂存  1保存
			storeData.state.saveflag = true;
			for(let i = 0; i < this.pushdata.length; i++) {
				if(this.pushdata[i].isScroll) {
					this.pushdata[i].widgets = this.scrollPushdata
				}
			}
			let api = '/system/theme/saveTheme';
			if(this.$route.path == '/theme/edittheme') { //创建副本留id为空
				this.formdatasend.id = sessionStorage.getItem('currentTheme_ID');
				api = '/system/theme/updateThem';
			}
			if(this.$route.path == '/theme/creattheme' && type != 0) { //创建副本留id为空
				this.formdatasend.id = '';
				this.formdatasend.status = 1;
			}
			let data = {
				themeJson: JSON.stringify(this.formdatasend),
				baseJson: JSON.stringify(this.setscrStyle),
				widgetJson: JSON.stringify(this.pushdata),
				saveType: type
			}
			axios.post(api, data)
				.then((res) => {
					storeData.state.saveflag = false;
					this.formdatasend.id = res.data.data;
					this.$message({
						message: '保存成功！',
						type: 'success'
					});
					if(type == 1) {
						sessionStorage.removeItem("currentTheme_ID");
						this.$router.push({
							path: '/theme/index'
						})
					}
				})
				.catch(err => {
					console.log(err);
				});
		},
		getmaxnum(arr) {
			let newselmax = [];
			//寻找最大值
			for(let i in arr) {
				newselmax.push(arr[i].Zindex)
			}
			if(newselmax.length > 0) {
				this.countZindex = Math.max.apply(null, newselmax) + 1;
			}
		},
		addWidget(item, index) { //添加widget			
			this.countZindex++;
			let that = this;
			//拼接后台给的二次数据
			/*二次请求*/
			let data = {
				params: {
					widgetId: item.id
				}
			}
			axios.get('/system/getGoupWidgetById', data)
				.then((res) => {
					let setting = JSON.parse(res.data.data);
					setting.appId = '';
					setting.isPoster = 0;
					setting.isScroll = 0;
					this.setattribute = setting;
					//拿到二次数据进行拼接到setting里	
					if(!this.scrollAert) {
						//添加到底屏
						this.getupdatedata();
						this.getmaxnum(this.pushdata);
						this.pushdata.push(Object.assign({}, setting, {
							'Uid': new Date().getTime().toString(),
							'codeId': setting.codeId,
							'id': item.id,
							'type': item.type,
							'Zindex': this.countZindex
						}));
						this.getwidgets();
						//如何解决底屏初始添加未记录位置的bug  important	
					} else { //添加到滚动屏							
						this.scrollgetupdatedata();
						this.getmaxnum(this.scrollPushdata[this.scrollCurindex].data);
						this.scrollPushdata[this.scrollCurindex].data.push(
							Object.assign({}, setting, {
								'Uid': new Date().getTime().toString(),
								'codeId': setting.codeId,
								'id': item.id,
								'type': item.type,
								'Zindex': this.countZindex
							}));
						this.scrollgetwidgets();
					}
				})
				.catch(err => {
					console.log(err);
				});

		},
		addPoster(item, index) { //添加海报
			this.countZindex++;
			item.x = 0;
			item.y = 0;
			item.appId = item.packageName;
			item.isScroll = 0; //非滚动屏标识
			item.isPoster = 1; //加标识
			let filenamea = '';
			if(!this.scrollAert) {
				//添加到底屏
				this.getupdatedata();
				this.getmaxnum(this.pushdata);
				let timenum = new Date().getTime().toString();
				let createfile = {};
				item.category = item.name;
				filenamea = item.posterPath.substring(item.posterPath.lastIndexOf('/') + 1); //对名字进行处理
				item.backgroud = filenamea;
				createfile[filenamea] = item.posterPath;
				this.pushdata.push(Object.assign({}, item, {
					'Uid': timenum,
					'codeId': 'PosterView',
					'id': item.id,
					'setting': item,
					'type': 0,
					'file': createfile,
					'Zindex': this.countZindex
				}));
				this.getwidgets();
				//如何解决底屏初始添加未记录位置的bug  important	
			} else { //添加到滚动屏							
				this.scrollgetupdatedata();
				this.getmaxnum(this.scrollPushdata[this.scrollCurindex].data);
				let timenum = new Date().getTime().toString();
				let createfile = {};
				filenamea = item.posterPath.substring(item.posterPath.lastIndexOf('/') + 1); //对名字进行处理
				item.backgroud = filenamea;
				createfile[filenamea] = item.posterPath;
				this.scrollPushdata[this.scrollCurindex].data.push(
					Object.assign({}, item, {
						'Uid': timenum,
						'codeId': 'PosterView',
						'id': item.id,
						'isPoster': 1,
						'type': 0,
						'setting': item,
						'file': createfile,
						'Zindex': this.countZindex
					}));
				this.scrollgetwidgets();
			}
		},
		getupdatedata() { //获取底屏更新数据
			this.pushdata = _.map($('.grid-stack > .grid-stack-item:visible'), function(el) {
				var node = $(el).data('_gridstack_node');
				var Uid = $(el).attr('data-uid');
				var strIss = $(el).attr('data-gs-isScroll');
				return {
					Uid: Uid,
					x: parseInt(node.x),
					y: parseInt(node.y),
					width: node.width.toString(),
					height: node.height.toString(),
					name: $(el).attr('data-name'),
					isScroll: strIss ? 1 : 0,
					setting: JSON.parse($(el).attr('data-all')).setting,
					backgroud: JSON.parse($(el).attr('data-all')).backgroud,
					category: JSON.parse($(el).attr('data-all')).category,
					description: JSON.parse($(el).attr('data-all')).description,
					file: JSON.parse($(el).attr('data-all')).file,
					codeId: JSON.parse($(el).attr('data-all')).codeId,
					appId: JSON.parse($(el).attr('data-all')).appId ? JSON.parse($(el).attr('data-all')).appId : '',
					id: JSON.parse($(el).attr('data-all')).id,
					isPoster: JSON.parse($(el).attr('data-all')).isPoster ? 1 : 0,
					type: parseInt(JSON.parse($(el).attr('data-all')).type) == 'NaN' ? '' : parseInt(JSON.parse($(el).attr('data-all')).type),
					Zindex: JSON.parse($(el).attr('data-all')).Zindex
				};
			});
		},
		scrollgetupdatedata() { //获取滚屏更新数据
			this.scrollPushdata[this.scrollCurindex].data = _.map($('.grid-stack1 > .grid-stack-item:visible'), function(el) {
				var node = $(el).data('_gridstack_node');
				var Uid = $(el).attr('data-uid');
				return {
					Uid: Uid,
					x: parseInt(node.x),
					y: parseInt(node.y),
					width: node.width.toString(),
					height: node.height.toString(),
					name: $(el).attr('data-name'),
					setting: JSON.parse($(el).attr('data-all')).setting,
					backgroud: JSON.parse($(el).attr('data-all')).backgroud,
					category: JSON.parse($(el).attr('data-all')).category,
					description: JSON.parse($(el).attr('data-all')).description,
					file: JSON.parse($(el).attr('data-all')).file,
					codeId: JSON.parse($(el).attr('data-all')).codeId,
					appId: JSON.parse($(el).attr('data-all')).appId ? JSON.parse($(el).attr('data-all')).appId : '',
					id: JSON.parse($(el).attr('data-all')).id,
					isPoster: JSON.parse($(el).attr('data-all')).isPoster,
					type: parseInt(JSON.parse($(el).attr('data-all')).type),
					Zindex: JSON.parse($(el).attr('data-all')).Zindex
				};
			});
		},
		getwidgets() { //获取Widget
			//初始化宫格
			var that = this;
			var t = {};
			t.serialized_data = this.pushdata;
			t.grid = $('.grid-stack').data('gridstack');
			t.load_grid = function() {
				t.grid.remove_all();
				var items = GridStackUI.Utils.sort(t.serialized_data);
				_.each(items, function(node) {
					let domstr = ''
					domstr = '<div style="z-index :' + node.Zindex + '"><div class="grid-stack-item-content grid-stack-item-content-back" style="background:url(' + that.imgbaseUrl + node.file[node.backgroud] + ') no-repeat center;background-size: 100% 100%;"></div><div/>';
					if(node.isScroll) {
						let bac = node.backgroud;
						if(that.preImgurl.length) {
							domstr = '<div  style="z-index :' + node.Zindex + '"><div class="grid-stack-item-content grid-stack-item-content-back scrollflag" style="background:url(' + that.preImgurl + ') no-repeat center;background-size: 100% 100%;"></div><div/>';
						} else {
							domstr = '<div  style="z-index :' + node.Zindex + '"><div class="grid-stack-item-content grid-stack-item-content-back scrollflag"></div><div/>';
						}
					}
					t.grid.add_widget($(domstr),
						node.x, node.y, node.width, node.height, undefined, node);
				}, t);

			}.bind(t);
			t.load_grid();
			//保存发送值
		},
		scrollgetwidgets() { //获取Widget
			//初始化宫格
			let that = this;
			$('.grid-stack1').data('gridstack').remove_all();
			$('.grid-stack1').gridstack(this.scrollOptions);
			//			}
			let t = {};
			t.serialized_data = this.scrollPushdata[this.scrollCurindex].data;
			t.grid = $('.grid-stack1').data('gridstack');
			t.load_grid = function() {
				t.grid.remove_all();
				let items = GridStackUI.Utils.sort(t.serialized_data);
				_.each(items, function(node) {
					let domstr = '<div  style="z-index :' + node.Zindex + '"><div class="grid-stack-item-content grid-stack-item-content-back" style="background:url(' + that.imgbaseUrl + node.file[node.backgroud] + ') no-repeat center;background-size: 100% 100%;"></div><div/>';
					t.grid.add_widget($(domstr),
						node.x, node.y, node.width, node.height, undefined, node);
				}, t);
			}.bind(t);
			t.load_grid();
			//保存发送值
		},
		delete_widget(el) { //删除widgets  
			let deleteDom = $(el)[0].currentTarget;
			let that = this;
			let currentUid = $(deleteDom).attr('data-uid');
		},
		changes() { //根据分类 去模糊搜索
			let uType = JSON.parse(sessionStorage.getItem('userMsg')).userType;
			if(uType == 0 || uType == 2) {
				uType = 0;
			} else {
				uType = 1;
			}
			let data = {
				params: {
					category: this.widgetCategory,
					type: uType, //管理员
					pageSize: 9999999
				}
			};
			axios.get('/system/findWidgetsList', data)
				.then((res) => {
					this.meundata = res.data.data.list;
					for(let i in this.meundata) {
						this.meundata[i].titleMsg = this.meundata[i].name + '(' + this.meundata[i].defaultSize + ')';
					}
				})
				.catch(err => {
					console.log(err);
				});

		},
		widgetCategory1() { //获取widget分类
			axios.get('/system/findWidgetCategory')
				.then(res => {
					this.widgetCategoryList = res.data.data.list
				})
				.catch(err => {
					console.log(err)
				})
		},
		getgrids(dom, xmax, xscale, ymax, yscale) { //绘制底屏宫格
			let myChart = this.$echarts.init(dom);
			var options = {
				title: {
					//text: 'Click to Add Points'
				},
				tooltip: {},
				grid: {
					left: '1',
					right: '1',
					bottom: '1',
					top: '1',
					containLabel: false
				},
				xAxis: {
					min: 0,
					max: xmax,
					type: 'value',
					interval: xscale,
					axisTick: {
						show: false
					},
					axisLabel: {
						show: false
					},
					axisLine: {
						onZero: false,
						show: false,
					},
					splitLine: { //格子样式
						lineStyle: {
							color: '#808080',
							opacity: '0.15'
						}
					}
				},
				yAxis: {
					min: 0,
					max: ymax,
					type: 'value',
					interval: yscale,
					axisTick: {
						show: false
					},
					axisLabel: {
						show: false
					},
					axisLine: {
						onZero: false,
						show: false,
					},
					splitLine: { //格子样式
						lineStyle: {
							color: '#808080',
							opacity: '0.15'
						}
					}
				}
			};
			myChart.setOption(options)
		},
		//widget拿过来
		handleAvatarSuccess(res, file) {
			//this.getimgurl(res, URL.createObjectURL(file.raw), file);
			let that = this;
			this.getimgurl(res, URL.createObjectURL(file.raw));
			let picnameDot = new Date().getTime() + file.name.slice(file.name.lastIndexOf('.') - 2, file.name.length);
			let picnameImg = new Date().getTime() + file.name.slice(file.name.lastIndexOf('.'), file.name.length);

			if(that.setattribute.setting[this.currentindex].default['nine-path']) {
				delete that.setattribute.file[that.setattribute.setting[this.currentindex].default['nine-path']]
				this.isNineImg("nine-path", file, res)
			} else {
				delete that.setattribute.file[that.setattribute.setting[this.currentindex].default['image']]
				this.isNineImg("image", file, res)
			}
		},
		handleAvatarSuccessText(res, file) { //上传编辑器中文字类型中的图片
			let that = this;
			this.getimgurl(res, URL.createObjectURL(file.raw));
			let picnameDot = new Date().getTime() + file.name.slice(file.name.lastIndexOf('.') - 2, file.name.length);
			let picnameImg = new Date().getTime() + file.name.slice(file.name.lastIndexOf('.'), file.name.length);

			if(that.widegetData.setting[this.currentindex].default.background) {
				if(that.widegetData.setting[this.currentindex].default.background['nine-path']) {
					delete that.setattribute.file[that.setattribute.setting[this.currentindex].default.background['nine-path']]
					this.isNineImg("nine-pathText", file, res)
				} else {
					delete that.setattribute.file[that.setattribute.setting[this.currentindex].default.background['image']]
					this.isNineImg("imageText", file, res)
				}
			}
		},
		isNineImg(value, file, res) { //给widgetData修改图片
			let picnameDot = new Date().getTime() + file.name.slice(file.name.lastIndexOf('.') - 2, file.name.length);
			let picnameImg = new Date().getTime() + file.name.slice(file.name.lastIndexOf('.'), file.name.length);
			if(value == "nine-path") { //点九图
				if(picnameDot.indexOf(".9") > 0) {
					this.setattribute.setting[this.currentindex].default['nine-path'] = picnameDot;
					this.setattribute.file[picnameDot] = res;
				} else {
					this.setattribute.setting[this.currentindex].default['nine-path'] = picnameImg;
					this.setattribute.file[picnameImg] = res;
				}
			} else if(value == "image") { //image类型
				if(picnameDot.indexOf(".9") > 0) {
					this.setattribute.setting[this.currentindex].default['image'] = picnameDot;
					this.setattribute.file[picnameDot] = res;
				} else {
					this.setattribute.setting[this.currentindex].default['image'] = picnameImg;
					this.setattribute.file[picnameImg] = res;
				}
			}
			if(value == "backgroud") { //封面图
				if(picnameDot.indexOf(".9") > 0) {
					this.setattribute.backgroud = picnameDot;
					this.setattribute.file[this.setattribute.backgroud] = res;
				} else {
					this.setattribute.backgroud = picnameImg;
					this.setattribute.file[this.setattribute.backgroud] = res;
				}
			}
			if(value == "nine-pathText") {
				if(picnameDot.indexOf(".9") > 0) {
					this.setattribute.setting[this.currentindex].default.background['nine-path'] = picnameDot;
					this.setattribute.file[picnameDot] = res;
				} else {
					this.setattribute.setting[this.currentindex].default.background['nine-path'] = picnameImg;
					this.setattribute.file[picnameImg] = res;
				}
			}
			if(value == "imageText") {
				if(picnameDot.indexOf(".9") > 0) {
					this.setattribute.setting[this.currentindex].default.background['image'] = picnameDot;
					this.setattribute.file[picnameDot] = res;
				} else {
					this.setattribute.setting[this.currentindex].default.background['image'] = picnameImg;
					this.setattribute.file[picnameImg] = res;
				}
			}

		},
		beforeAvatarUpload(file, value) { //上传签的校验
			const isJPG = file.type === 'image/jpeg';
			const isPNG = file.type === 'image/png';
			if(!isJPG && !isPNG) {
				this.$message.error('上传封面图片只能是 JPG、PNG 格式!');
			}
			return isJPG || isPNG;
		},
		handleRemove(file, fileList) {},
		deleteFile() { //删除file
			this.deleteBtn = true;
		},
		getimgurl(res, url, file) { //给数据里暂存字段，方便取
			this.setattribute.setting[this.currentindex].editorImg = res;
			var that = this;
			for(let i = 0; i < this.pushdata.length; i++) { //找到底屏的数据置换
				if(this.setattribute.x == this.pushdata[i].x && this.setattribute.y == this.pushdata[i].y) {
					if(this.pushdata[i].file[this.setattribute.setting[this.currentindex].default['nine-path']]) {
						this.pushdata[i].file[this.setattribute.setting[this.currentindex].default['nine-path']] = res;
					}
					if(this.pushdata[i].file[this.setattribute.setting[this.currentindex].default['image']]) {
						this.pushdata[i].file[this.setattribute.setting[this.currentindex].default['image']] = res;
					}
					_.map($('.grid-stack > .grid-stack-item:visible'), function(el) { //更新dom属性  可能还需要添加
						if(that.pushdata[i].Uid == $(el).attr('data-uid')) {
							$(el).attr('data-all', JSON.stringify(that.pushdata[i]))
						}
					});

				}
			}
			//找到滚动屏的数据置换
			this.setattribute.setting[this.currentindex].backupSrc = url;
		},
		uploadClick(item, index) { //上传记住当前index
			this.currentindex = index;
		},

	},
	watch: { //监听
		'$route' (to, from) { // 对路由变化作出响应...
			this.scrollAert = false; //弹窗grid不显示
		},
		'issave' () { //是否保存
			if(storeData.state.themeType == 1) {
				if(storeData.state.themeValid) {
					this.savetrueDate(storeData.state.themeType)
				} else {
					this.$message.error('请填写完整的信息！');
				}
			} else {
				this.savetrueDate(storeData.state.themeType)
			}
		}
	},
	computed: { //计算属性
		issave() {
			return storeData.state.themeClick;
		}
	}
}