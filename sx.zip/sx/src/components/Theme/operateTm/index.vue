<template>
	<div class="operateTm">
		<div class="all_contain">
			<header>
				<el-breadcrumb separator-class="el-icon-arrow-right">
					<el-breadcrumb-item :to="{ path: '/theme/index' }">主题管理</el-breadcrumb-item>
					<el-breadcrumb-item :to="{ path: '/theme/addtheme' }">{{titMsg}}</el-breadcrumb-item>
				</el-breadcrumb>
			</header>
			<div class="themeDetail">
				<el-form label-position="top" :model="ruleForm" :rules="rules" ref="ruleForm" label-width="100px" class="demo-ruleForm">
					<el-form-item class='half50' label="主题名称" prop="name">
						<el-input clearable v-model="ruleForm.name" @change='emitChange'></el-input>
					</el-form-item>
					<el-form-item class='half50' label="会员等级" prop="userLever">
						<el-select clearable v-model="ruleForm.userLever" placeholder="请选择" @change='emitChange'>
							<el-option v-for="(item,index) in userLeverL" :key="index" :label="item.label" :value="item.level">
							</el-option>
						</el-select>
					</el-form-item>
					<el-form-item class='half50' label="主题分类" prop="themStyle">
						<el-select @change='emitChange' clearable v-model="ruleForm.themStyle" placeholder="请选择">
							<el-option v-for="(item,index) in themStyleL" :key="index" :label="item.classificationName" :value="item.id">
							</el-option>
						</el-select>
						<el-button type="primary" @click='addThemestyle' class='btn_blue'>添加分类</el-button>
					</el-form-item>
					<el-form-item class='all20' label="开始时间" prop="startdate">
						<div class="block">
							<el-date-picker :picker-options="pickerOptionsstart" @change='timechange' value-format="timestamp" v-model="ruleForm.startdate" type="datetime" placeholder="选择日期">
							</el-date-picker>
						</div>
					</el-form-item>
					<el-form-item class='all20' label="结束时间" prop="enddate">
						<div class="block">
							<el-date-picker :picker-options="pickerOptionsend" @change='timechange' value-format="timestamp" v-model="ruleForm.enddate" type="datetime" placeholder="选择日期">
							</el-date-picker>
						</div>
					</el-form-item>
					<el-form-item class='half50' label="主要渠道" prop="mainchanel" v-if='iseditorcopy'>
						<el-checkbox-group v-model="ruleForm.mainchanel" @change="handleCheckedCitiesChange">
							<el-checkbox v-for='(item,index) in mainchanellist' :label="item.id" name="mainchanel" :key='index'>{{item.name}}</el-checkbox>
						</el-checkbox-group>
					</el-form-item>
					<el-form-item class='all100' label="适用" prop="version" required>
						<el-select @change='emitChange' clearable v-model="ruleForm.version" placeholder="请选择">
							<el-option v-for="(item,index) in versionList" :key="index" :label="item.attributeValue" :value="item.attributeKeyIndex">
							</el-option>
						</el-select> <span>以上版本</span>
					</el-form-item>
					<el-form-item class='all100' label="分辨率" prop="resolution" required>
						<el-radio-group @change='emitChangescreen' v-model="ruleForm.resolution">
							<el-radio :label="0">720 * 400</el-radio>
							<el-radio :label="1">1080 * 720</el-radio>
							<el-radio :label="2">1080 * 560</el-radio>
							<el-radio :label="4" v-if='false'>
								<el-input type="number" @change='emitChange' clearable class='resolution' v-model="widthinput" placeholder="请输入宽（px）"></el-input>
								<span>*</span>
								<el-input type="number" @change='emitChange' clearable class='resolution' v-model="heightinput" placeholder="请输入高（px）"></el-input>
								<el-button clearable type="primary" class='btn_blue'>确定</el-button>
							</el-radio>
							<el-radio :label="5">
								<el-button type="primary" @click='diywh' class='btn_blue'>自定义尺寸</el-button>
							</el-radio>
						</el-radio-group>
					</el-form-item>

					<div class="selectstyle">
						<el-radio-group v-model="ruleForm.gridOrRelative">
							<el-radio v-show='!isShowscroll' :label="6">使用宫格布局
								<el-form-item class='' prop="widthinputgg">
									<el-input class='resolution1' v-model="ruleForm.widthinputgg"></el-input>
								</el-form-item>
								<span>X</span>
								<el-form-item class='' prop="heightinputgg">
									<el-input class='resolution1' v-model="ruleForm.heightinputgg"></el-input>
								</el-form-item>
								<el-button type="primary" class='btn_blue' @click='setScree'>确定</el-button>
							</el-radio>
							<el-radio :label="8" v-show='isShowscroll' style='margin-left: 0;'>滚动屏宫格设置
								<el-form-item class='' prop="widthscroll">
									<el-input @change='emitChange' class='resolution1' v-model="ruleForm.widthscroll"></el-input>
								</el-form-item>
								<span>X</span>
								<el-form-item class='' prop="heighscroll">
									<el-input @change='emitChange' class='resolution1' v-model="ruleForm.heighscroll"></el-input>
								</el-form-item>

								<el-button type="primary" class='btn_blue' @click='setScroll'>确定</el-button>
							</el-radio>
							<el-radio :label="7" disabled>使用相对布局</el-radio>
						</el-radio-group>
					</div>

					<el-form-item class='all100' label="主题预览图" prop="prethemmimg">
						<el-upload :file-list="themefileList" :headers='uploadToken' action="http://api.launcher.pactera-sln.club:8185/system/fileUpload" list-type="picture-card" :on-preview="handlePictureCardPreview" :on-error='handleAvatarerr' :on-success="handleAvatarSuccesscard" :before-upload="beforeAvatarUploadcard" :on-remove="handleRemove" :auto-upload='true'>
							<i class="el-icon-plus"></i>
						</el-upload>
						<el-dialog :visible.sync="dialogVisible">
							<img width="100%" :src="dialogImageUrl" alt="">
						</el-dialog>
					</el-form-item>
					<el-form-item class='all100' label="主题应用背景（使用于app背景图）" prop="apppicture">
						<div class="uploadbox" v-for='(item,index) in themeimg'>
							<el-upload :headers='uploadToken' class="avatar-uploader" action="http://api.launcher.pactera-sln.club:8185/system/fileUpload" :show-file-list="false" :on-error='handleAvatarerr' :on-success="handleAvatarSuccess" :before-upload="beforeAvatarUpload">
								<img v-if="item.imageUrl&&item.isshow" :src="item.imageUrl" class="avatar" @click="getIndeximg(item,index)">
								<i v-else class="el-icon-plus avatar-uploader-icon" @click="getIndeximg(item,index)"></i>
							</el-upload>
							<p>{{item.desc}}</p>
						</div>
						<el-dialog :visible.sync="dialogVisibless">
							<img width="100%" :src="dialogImageUrl" alt="">
						</el-dialog>
					</el-form-item>
				</el-form>
			</div>
			<div class="diyWidget">
				<editvue></editvue>
			</div>

			<el-dialog class='diyStylebox' :visible.sync="dialogStyle">
				<div class="diySizeP">
					<div class="head">
						<span>添加主题分类</span>
					</div>
					<div class="attributes_theme">
						<el-button type="primary" class='btn_blue topbtn' @click='addCategory'>增加</el-button>
						<div class="addCategory">
							<div class="categoryModel" v-for="(item,index) in themStyleL" :key='item.id'>
								<input clearable :disabled="item.num" class="customCategory" v-model='item.classificationName' maxlength=4 /><span v-if="!item.num" class="remove" @click="removeHave(item,index)">-</span>
							</div>
							<div class="categoryModel" v-for="(item,index) in category">
								<input @blur="testDouble(item,index)" clearable class="customCategory" v-model.trim='item.msg' maxlength=4 /><span class="remove" @click="removeCategory(item,index)">-</span>
							</div>
						</div>
					</div>
					<div class="foter">
						<el-button @click='dialogStyle=false'>取消</el-button>
						<el-button type="primary" class='btn_blue' @click='submitStyle'>提交</el-button>
					</div>
				</div>
			</el-dialog>

			<el-dialog class='diySizebox' :visible.sync="diySize">

				<el-form :rules="diySizerules" :model="diySizeValidateForm" ref="diySizeValidateForm" label-width="100px" class="demo-ruleForm">
					<div class="diySizeP">
						<div class="head">
							<span>自定义尺寸</span>
						</div>
						<div class="attributes_theme">

							<el-form-item class='' prop="screeStyle">
								<p class="pscrss">
									<el-radio v-model="diySizeValidateForm.screeStyle" label="1">按分辨率 </el-radio>
								</p>
							</el-form-item>
							<el-form-item class='' prop="Swidth">
								<el-input clearable v-model="diySizeValidateForm.Swidth" class='screeinput'></el-input><span class="screeninput">px</span> *
							</el-form-item>
							<el-form-item class='' prop="Slength">
								<el-input clearable v-model="diySizeValidateForm.Slength" class='screeinput'></el-input><span class="screeninput">px</span>
							</el-form-item>

						</div>
						<div class="attributes_theme">
							<el-form-item class='' prop="screeStyle">
								<p class="pscrss">
									<el-radio v-model="diySizeValidateForm.screeStyle" label="2">按长宽比 </el-radio>
								</p>
							</el-form-item>
							<el-form-item class='' prop="lenperwid">
								<el-input clearable v-model="diySizeValidateForm.lenperwid" class='screeninput1'></el-input>
							</el-form-item>

							<span>上下可浮动</span>
							<el-form-item class='' prop="percent">
								<el-select clearable v-model="diySizeValidateForm.percent" placeholder="请选择">
									<el-option v-for="(item,index) in optionspercent" :key="index" :label="item.label" :value="item.value">
									</el-option>
								</el-select>
							</el-form-item>

						</div>
						<div class="foter">
							<el-button @click='diySize=false'>取消</el-button>
							<el-button type="primary" class='btn_blue' @click='submitSize'>提交</el-button>
						</div>
					</div>
				</el-form>
			</el-dialog>
		</div>
	</div>
</template>
<script src="./index.js">
</script>
<style scoped="scoped" src="./index.less" lang="less"></style>