import axios from "@/axios.js";
import editvue from '../editWidget/index.vue'
import './elementO.css';
import bus from '@/bus.js';
import storeData from '@/vuex/store.js';
const cityOptions = ['上海', '北京', '广州', '深圳'];
//import bus from "@/bus.js";
export default {
	data() {
		var validateNumber = (rule, value, callback) => {
			let reg = /^([1-9])([0-9]*)$/;
			if(!reg.test(value)) {
				callback(new Error('请输入一个正整数'));
			}
			callback();
		};
		var validateNumberdian = (rule, value, callback) => {
			if(this.diySizeValidateForm.screeStyle == 1) {
				//				let reg = /^[0-9]+([.]{1}[0-9]+){0,1}$/;
				let reg = /^([1-9])([0-9]*)$/;
				if(!reg.test(value)) {
					callback(new Error('请输入一个正整数'));
				}
			}
			callback();
		};
		var validatewhper = (rule, value, callback) => {
			if(this.diySizeValidateForm.screeStyle == 2) {
				let newArr = [];
				newArr = value.split(':');
				if(value.indexOf('：') == 1) {
					newArr = value.split('：');
				}
				let reg = /^([1-9])([0-9]*)$/;
				if(newArr.length == 2) {
					if(!reg.test(newArr[0]) || !reg.test(newArr[1])) {
						callback(new Error('请输入有效比例'));
					}
				} else {
					callback(new Error('请输入有效比例'));
				}
			}
			callback();
		};
		var validatefloat = (rule, value, callback) => {
			if(this.diySizeValidateForm.screeStyle == 2) {
				if(!value) {
					callback(new Error('请选择浮动比例'));
				}
			}
			callback();
		};
		return {
			titMsg: '创建新主题',
			dialogStyle: false,
			screeStyle: '', //选择哪种布局
			Swidth: '', //宽度 
			Slength: '', //长度
			selectdelids: [],
			iseditorcopy: false,
			pickerOptionsstart: {
				disabledDate: (time) => {
					return time.getTime() < Date.now() - 8.64e7;
				}
			},
			pickerOptionsend: {
				disabledDate: (time) => {
					return time.getTime() < this.ruleForm.startdate;
				}
			},
			optionspercent: [{
					value: '5%',
					label: '5%'
				}, {
					value: '8%',
					label: '8%'
				}, {
					value: '10%',
					label: '10%'
				}, {
					value: '13%',
					label: '13%'
				}, {
					value: '15%',
					label: '15%'
				},
				{
					value: '20%',
					label: '20%'
				}, {
					value: '25%',
					label: '25%'
				}, {
					value: '30%',
					label: '30%'
				}, {
					value: '40%',
					label: '40%'
				}, {
					value: '50%',
					label: '50%'
				},
				{
					value: '100%',
					label: '无限缩放'
				}
			],
			themefileList: [],
			diySize: false,
			checkAll: false,
			checkedCities: ['上海', '北京'],
			cities: cityOptions,
			isIndeterminate: true,
			widthinputgg: '', //宫格-宽自定义
			heightinputgg: '', //宫格-高自定义
			widthscroll: '', //滚屏-宽自定义
			heighscroll: '', //滚屏-高自定义
			percent: '', //百分比
			widthinput: '', //宽自定义
			heightinput: '', //高自定义
			lenperwid: '', //按长宽比
			dialogImageUrl: '',
			dialogVisible: false,
			//			imageUrl:'',//图片url
			themeimg: [{
					imageUrl: '',
					desc: '电话',
					name: '',
					path: '',
					isshow: false,
				},
				{
					imageUrl: '',
					desc: '导航',
					name: '',
					path: '',
					isshow: false,
				},
				{
					imageUrl: '',
					desc: '音乐',
					name: '',
					path: '',
					isshow: false,
				},
				{
					imageUrl: '',
					desc: '广播',
					name: '',
					path: '',
					isshow: false,
				}
			],
			currentIMGindex: -1,
			dialogVisibless: false,
			uploadToken: {},
			themStyleL: [],
			userLeverL: [{
				level: '1',
				label: '普通用户'
			}],
			mainchanellist: [],
			versionList: [],
			category: [], //分类
			diySizeValidateForm: { //弹出窗
				Swidth: '',
				Slength: '',
				screeStyle: '',
				lenperwid: '',
				percent: '' //浮动比例
			},

			diySizerules: {
				screeStyle: [{ //结束时间
					//type: 'date',
					required: true,
					message: '请选择分辨率',
					trigger: 'change'
				}],
				Swidth: [{ //宽
					validator: validateNumberdian,
					trigger: 'blur'
				}],
				Slength: [{ //高
					validator: validateNumberdian,
					trigger: 'blur'
				}],
				lenperwid: [{ //宽高比
					validator: validatewhper,
					trigger: 'blur'
				}],
				percent: [{ //浮动比例
					validator: validatefloat,
					trigger: 'blur'
				}],
			},

			ruleForm: {
				name: '', //主题名称
				themStyle: '', //主题分类
				userLever: '', //会员等级
				startdate: '', //开始时间
				enddate: '', //结束时间
				mainchanel: [], //主要渠道
				version: '', //版本
				resolution: '', //分辨率
				gridOrRelative: 6,
				type: [],
				resource: '',
				prethemmimg: '',
				longResolution: -1,
				wideResolution: -1,
				longPalace: -1,
				widePalace: -1,
				apppicture: '',
				widthinputgg: '', //宫格-宽自定义
				heightinputgg: '', //宫格-高自定义
				widthscroll: 10, //滚屏-宽自定义
				heighscroll: 10, //滚屏-高自定义
			},
			themefile: {},
			themepush: {
				path: '',
				name: ''
			},
			Resolution: [{
					longResolution: 400,
					wideResolution: 720
				},
				{
					longResolution: 720,
					wideResolution: 1080
				},
				{
					longResolution: 560,
					wideResolution: 1080
				}
			],
			rules: {
				name: [{ //名字
						required: true,
						message: '请输入主题名称',
						trigger: 'blur'
					},
					{
						min: 1,
						max: 20,
						message: '长度不超过 20 个字符',
						trigger: 'blur'
					}
				],
				widthinputgg: [{ //宫格宽
						required: true,
						message: '请输入宫格宽',
						trigger: 'blur'
					},
					{
						validator: validateNumber,
						trigger: 'blur'
					}
				],
				heightinputgg: [{ //宫格高
						required: true,
						message: '请输入宫格高',
						trigger: 'blur'
					},
					{
						validator: validateNumber,
						trigger: 'blur'
					}
				],
				widthscroll: [{ //滚屏宽
						required: true,
						message: '请输入滚屏宽',
						trigger: 'blur'
					},
					{
						validator: validateNumber,
						trigger: 'blur'
					}
				],
				heighscroll: [{ //滚屏高
						required: true,
						message: '请输入滚屏高',
						trigger: 'blur'
					},
					{
						validator: validateNumber,
						trigger: 'blur'
					}
				],
				themStyle: [{ //主题分类
					required: true,
					message: '请选择主题区域',
					trigger: 'change'
				}],
				userLever: [{ //会员等级
					required: true,
					message: '请选择会员等级',
					trigger: 'change'
				}],
				version: [{ //会员等级
					required: true,
					message: '请选择通用版本',
					trigger: 'change'
				}],
				startdate: [{ //开始时间
					//type: 'date',
					required: true,
					message: '请选择开始时间',
					trigger: 'change'
				}],
				enddate: [{ //结束时间
					//type: 'date',
					required: true,
					message: '请选择结束时间',
					trigger: 'change'
				}],
				resolution: [{ //结束时间
					//type: 'date',
					required: true,
					message: '请选择分辨率',
					trigger: 'change'
				}],
				resource: [{ //主题资源
					required: true,
					message: '请选择主题资源',
					trigger: 'change'
				}],
				prethemmimg: [{ //预览图
					required: true,
					message: '请上传主题预览图',
					trigger: 'blur'
				}],
				apppicture: [{ //app图
					required: true,
					message: '请上传所有类别的主题应用背景',
					trigger: 'blur'
				}],
			}
		};
	},
	mounted() { //实例挂载之后
		this.emitChange();
	},
	computed: { //计算属性
		isShowscroll() { //是否显示滚屏
			return storeData.state.showScroll;
		},
		istoSave() { //是否保存
			return storeData.state.themeClick;
		}
	},
	methods: { //方法	
		submitForm() {
			storeData.state.themeValid = false;
			if(storeData.state.themeType == 1) {
				this.$refs['ruleForm'].validate((valid) => {
					if(valid) {
						storeData.state.themeValid = valid;
					} else {
						console.log('error submit!!');
						return false;
					}
				});
			}

		},
		setScree() { //设置底屏
			if(this.ruleForm.gridOrRelative == 6) {
				let wflag = false;
				let hflag = false;
				this.$refs['ruleForm'].validateField('widthinputgg', (validMessage) => {
					if(validMessage == '') {
						wflag = true;
					}
				});
				this.$refs['ruleForm'].validateField('heightinputgg', (validMessage) => {
					if(validMessage == '') {
						hflag = true;
					}
				});
				if(wflag && hflag) {
					let sendfrom = {
						widthinputgg: this.ruleForm.widthinputgg,
						heightinputgg: this.ruleForm.heightinputgg
					}
					bus.$emit('setScreenstyle', sendfrom);
				} else {
					this.$message({
						message: '请输入正确的底屏宫格比例！',
						type: 'warning'
					});
				}
			}

		},
		setScroll() { //设置滚动屏
			if(this.ruleForm.gridOrRelative == 8) {
				let wflag = false;
				let hflag = false;
				this.$refs['ruleForm'].validateField('widthscroll', (validMessage) => {
					if(validMessage == '') {
						wflag = true;
					}
				});
				this.$refs['ruleForm'].validateField('heighscroll', (validMessage) => {
					if(validMessage == '') {
						hflag = true;
					}
				});
				if(this.ruleForm.widthscroll && this.ruleForm.heighscroll) {
					let sendfrom = {
						widthscroll: this.ruleForm.widthscroll,
						heighscroll: this.ruleForm.heighscroll
					}
					bus.$emit('setScrolltyle', sendfrom);
				} else {
					this.$message({
						message: '请输入正确的滚动屏宫格比例！',
						type: 'warning'
					});
				}
			}

		},
		getUsermsg() {
			let token = sessionStorage.getItem('Token');
			this.uploadToken = {
				Authorization: token
			};
		},
		getIndeximg(item, index) {
			this.currentIMGindex = index
		},
		handleAvatarSuccess(res, file) {
			this.themeimg[this.currentIMGindex].imageUrl = URL.createObjectURL(file.raw);
			this.themeimg[this.currentIMGindex].path = res;
			this.themeimg[this.currentIMGindex].isshow = true;
			if(this.themeimg[0].path && this.themeimg[1].path && this.themeimg[2].path && this.themeimg[3].path) {
				this.ruleForm.apppicture = '1';
				this.$refs['ruleForm'].validateField('apppicture', (validMessage) => {});
			}
			this.emitChange();
		},
		beforeAvatarUpload(file) {
			const isJPG = file.type === 'image/jpeg';
			const isPNG = file.type === 'image/png';
			this.themeimg[this.currentIMGindex].name = file.name;
			if(!isJPG && !isPNG) {
				this.$message.error('上传封面图片只能是 JPG、PNG 格式!');
			}
			return isJPG || isPNG;
		},
		beforeAvatarUploadcard(file) {
			const isJPG = file.type === 'image/jpeg';
			const isPNG = file.type === 'image/png';
			let newname = '';
			//主题图片名称不重复
			newname = new Date().getTime() + file.name.slice(file.name.lastIndexOf('.') - 2, file.name.length);
			this.themepush.name = newname;
			if(!isJPG && !isPNG) {
				this.$message.error('上传封面图片只能是 JPG、PNG 格式!');
			}
			return isJPG || isPNG;
		},
		handlePictureCardPreview(file) {
			this.dialogImageUrl = file.url;
			this.dialogVisible = true;
		},
		handleAvatarerr(err, file, fileList) { //上传失败的钩子
			storeData.state.isexpried += 1;
			sessionStorage.clear(); //清空session
			this.$router.push({
				path: '/'
			})
		},
		handleAvatarSuccesscard(res, file) {
			this.themepush.path = res;
			this.themefileList.push({
				name: this.themepush.name,
				url: this.imgbaseUrl + this.themepush.path
			})
			this.ruleForm.prethemmimg = '';
			if(this.themefileList.length) {
				this.ruleForm.prethemmimg = '1';
			}
			this.$refs['ruleForm'].validateField('prethemmimg', (validMessage) => {});
			this.themefile[this.themepush.name] = this.themepush.path;
			this.themepush = { //重置
				path: '',
				name: ''
			}
			this.emitChange();
		},
		timechange() { //处理时间
			if(this.ruleForm.enddate < this.ruleForm.startdate) {
				this.ruleForm.enddate = '';
			}
			this.emitChange();
		},
		emitChange() {
			var sendfrom = {};
			let rseol = {};
			if(this.ruleForm.resolution) {
				rseol = this.Resolution[this.ruleForm.resolution];
				if(this.ruleForm.resolution < 4) { //处理分辨率					
					sendfrom.longResolution = rseol.longResolution;
					sendfrom.wideResolution = rseol.wideResolution;
				} else {
					if(this.diySizeValidateForm.screeStyle == 1) { //自定义尺寸长宽
						sendfrom.longResolution = this.diySizeValidateForm.Slength;
						sendfrom.wideResolution = this.diySizeValidateForm.Swidth;
					} else { //处理长 宽比 浮动
						sendfrom.widthOrHigthRatio = this.diySizeValidateForm.lenperwid;
						sendfrom.folatPoint = this.diySizeValidateForm.percent;
					}
				}
			}
			if(this.ruleForm.gridOrRelative == 6) { //处理宫格
				sendfrom.longPalace = this.ruleForm.widthinputgg;
				sendfrom.widePalace = this.ruleForm.heightinputgg;
			}
			sendfrom.creator = this.ruleForm.mainchanel.join(','); //渠道字符串
			//应用图
			sendfrom.phoneAppImgUrl = this.themeimg[0].path;
			sendfrom.weatherAppImgUrl = this.themeimg[1].path;
			sendfrom.musicAppImgUrl = this.themeimg[2].path;
			sendfrom.fmAppImgUrl = this.themeimg[3].path;
			sendfrom.level = this.ruleForm.userLever //会员等级
			sendfrom.version = this.ruleForm.version //版本
			sendfrom.typeId = this.ruleForm.themStyle; //主题分类
			sendfrom.title = this.ruleForm.name; //主题名称
			sendfrom.sTime = this.ruleForm.startdate; //开始时间
			sendfrom.eTime = this.ruleForm.enddate; //结束时间
			//滚屏相关		
			sendfrom.widthscroll = this.ruleForm.widthscroll; //滚屏row
			sendfrom.heighscroll = this.ruleForm.heighscroll; //滚屏col
			//额外无用参数
			sendfrom.resolution = this.ruleForm.resolution; //选中分辨率的哪一个
			sendfrom.gridOrRelative = this.ruleForm.gridOrRelative; //选中布局方式		
			sendfrom.screeStyle = this.diySizeValidateForm.screeStyle; //选中哪种自定义布局
			sendfrom.filesJson = this.themefile;
			sendfrom.status = this.ruleForm.status; //状态
			bus.$emit('getNewdata', sendfrom);
		},
		emitChangescreen() {
			let rseol = this.Resolution[this.ruleForm.resolution];
			var sendfrom1 = {};
			if(this.ruleForm.resolution < 4) { //处理分辨率
				sendfrom1.longResolution = rseol.longResolution;
				sendfrom1.wideResolution = rseol.wideResolution;
			} else {
				if(this.diySizeValidateForm.screeStyle == 1) { //自定义尺寸长宽
					sendfrom1.longResolution = this.diySizeValidateForm.Slength;
					sendfrom1.wideResolution = this.diySizeValidateForm.Swidth;
				} else { //处理长 宽比 浮动
					let arr = this.diySizeValidateForm.lenperwid.split(':');
					if(this.diySizeValidateForm.lenperwid.indexOf('：') == 1) {
						arr = this.diySizeValidateForm.lenperwid.split('：');
					}
					sendfrom1.longResolution = arr[1];
					sendfrom1.wideResolution = arr[0];
					sendfrom1.widthOrHigthRatio = this.diySizeValidateForm.lenperwid;
					sendfrom1.folatPoint = this.diySizeValidateForm.percent;
				}
			}
			this.emitChange();
			bus.$emit('Changescreen', sendfrom1);
		},
		submitSize() {
			this.$refs['diySizeValidateForm'].validate((valid) => {
				if(valid) {
					this.emitChangescreen();
					this.diySize = false;
				} else {
					console.log('error submit!!');
					return false;
				}
			});
		},
		getqudao() { //获取渠道
			axios.get('/system/channel/findAll')
				.then((res) => {
					this.mainchanellist = res.data.data
				})
				.catch(err => {
					console.log(err);
				});
		},
		addCategory() { //添加分类		
			var testflag = false; //与已上传的判断		
			if(this.category.length > 0) {
				for(let i = 0; i < this.themStyleL.length; i++) {
					if(this.category[this.category.length - 1].msg == this.themStyleL[i].classificationName) {
						testflag = true;
					}
				}
				if(!testflag && this.category[this.category.length - 1].msg) {
					this.category.push({
						msg: ''
					});
				}
			} else {
				this.category.push({
					msg: ''
				});
			}

		},
		testDouble(item, index) {
			for(let i in this.themStyleL) {
				if(this.themStyleL[i].classificationName == item.msg) {
					item.msg = ''
				}
			}
			for(let i in this.category) {
				if(this.category[i].msg == item.msg) {
					if(index != i) {
						item.msg = '';
					}
				}
			}
		},
		removeCategory(item, index) { //添加分类弹出框删除数据
			this.category.splice(index, 1)
		},
		removeHave(item, index) { //添加分类弹出框删除数据
			if(!item.num) {
				this.selectdelids.push(item.id);
				this.themStyleL.splice(index, 1);
			}
		},
		submitStyle() {
			let arrN = []
			for(let i = 0; i < this.category.length; i++) {
				if(this.category[i].msg) { //数组去空
					arrN.push(this.category[i].msg)
				}
			}
			var res = [];
			arrN.forEach(function(item) { //数组去重
				res.includes(item) ? '' : res.push(item);
			});
			let data = {
				classification: res.join(','),
				ids: this.selectdelids.join(',')
			};
			axios.post('/system/theme/addType', data)
				.then((res) => {
					this.$message({
						type: 'success',
						message: '操作成功!'
					});
					this.category = [];
					this.dialogStyle = false;
					this.getthemeOptions();
				})
				.catch(err => {
					console.log(err);
				});

		},
		diywh() {
			this.diySize = true;
			this.ruleForm.resolution = 5;
		},
		addThemestyle() {
			this.dialogStyle = true;
			this.category = [];
			this.selectdelids = [];
			this.getthemeOptions();
		},
		handleCheckAllChange(val) {
			this.checkedCities = val ? cityOptions : [];
			this.isIndeterminate = false;
		},
		handleCheckedCitiesChange(value) { //checkbox选中的框子
			let checkedCount = value.length;
			this.checkAll = checkedCount === this.cities.length;
			this.isIndeterminate = checkedCount > 0 && checkedCount < this.cities.length;
			this.emitChange();
		},
		handleRemove(file, fileList) {
			for(let i in this.themefileList) {
				if(this.themefileList[i].name == file.name) {
					this.themefileList.splice(i, 1)
				}
			}
			this.ruleForm.prethemmimg = '';
			delete this.themefile[file.name];
			if(this.themefileList.length) {
				this.ruleForm.prethemmimg = '1';
			}
			this.$refs['ruleForm'].validateField('prethemmimg', (validMessage) => {});
			this.emitChange();
		},
		getthemeOptions() {
			axios.get('/system/theme/selectByType')
				.then((res) => {
					this.themStyleL = res.data.data

				})
				.catch(err => {
					console.log(err);
				});
		},
		getversionArr() { //获取版本数组
			axios.get('/system/theme/selectVersion')
				.then((res) => {
					this.versionList = res.data.data
				})
				.catch(err => {
					console.log(err);
				});
		},
		changeTile() {
			this.iseditorcopy = true;
			if(this.$route.path == '/theme/edittheme' || this.$route.path == '/theme/creattheme') {
				this.iseditorcopy = false;
				if(this.$route.path == '/theme/edittheme') {
					this.titMsg = '编辑主题';
					if(sessionStorage.getItem('currentTheme_createId') == 0) {
						this.iseditorcopy = true;
					}
				} else {
					this.titMsg = '创建副本';
					this.iseditorcopy = true;
				}
				let data = {
					params: {
						id: sessionStorage.getItem('currentTheme_ID')
					}
				};
				axios.get('/system/theme/selectById', data)
					.then((res) => {
						let themepreview = res.data.data.file;
						let geteidtform = JSON.parse(res.data.data.theme.themeJson)
						let getbaseJson = JSON.parse(res.data.data.theme.basicJson);
						let widgetjson = JSON.parse(res.data.data.theme.widgetJson);
						this.ruleForm.name = geteidtform.title;
						this.ruleForm.userLever = geteidtform.level;
						this.ruleForm.themStyle = geteidtform.typeId;
						this.ruleForm.startdate = geteidtform.sTime;
						this.ruleForm.enddate = geteidtform.eTime;
						this.ruleForm.status = res.data.data.theme.status; //状态
						if(this.$route.path == '/theme/creattheme') {
							this.ruleForm.name = geteidtform.title + '副本';
							this.ruleForm.status = 0;
							let utype = JSON.parse(sessionStorage.getItem('userMsg')).userType;
							this.iseditorcopy = false;
							this.titMsg = '创建副本';
							if(utype == 0 || utype == 2) {
								this.iseditorcopy = true;
							}
						};
						let chanes = [];
						if(geteidtform.creator.length > 0) { //对传回来的chanel进行处理
							chanes = geteidtform.creator.split(',');
							for(let i in chanes) {
								chanes[i] = Number(chanes[i])
							}
						}
						this.ruleForm.mainchanel = chanes;
						this.ruleForm.version = geteidtform.version;
						this.ruleForm.resolution = geteidtform.resolution; //拿到当前选中
						this.diySizeValidateForm.screeStyle = geteidtform.screeStyle;
						if(this.ruleForm.resolution == 5) {
							if(this.diySizeValidateForm.screeStyle == '1') {
								this.diySizeValidateForm.Slength = geteidtform.longResolution;
								this.diySizeValidateForm.Swidth = geteidtform.wideResolution;
							} else { //比例逻辑
								this.diySizeValidateForm.lenperwid = geteidtform.widthOrHigthRatio;
								this.diySizeValidateForm.percent = geteidtform.folatPoint;
							}
						}

						//						this.ruleForm.gridOrRelative = geteidtform.gridOrRelative; //默认选中
						this.ruleForm.gridOrRelative = 6;
						this.ruleForm.widthinputgg = getbaseJson.row;
						this.ruleForm.heightinputgg = getbaseJson.col;
						this.themeimg = [{ //初始化
								imageUrl: this.imgbaseUrl + geteidtform.phoneAppImgUrl,
								desc: '电话',
								name: '',
								path: geteidtform.phoneAppImgUrl,
								isshow: geteidtform.phoneAppImgUrl ? true : false,
							},
							{
								imageUrl: this.imgbaseUrl + geteidtform.weatherAppImgUrl,
								desc: '导航',
								name: '',
								path: geteidtform.weatherAppImgUrl,
								isshow: geteidtform.weatherAppImgUrl ? true : false,
							},
							{
								imageUrl: this.imgbaseUrl + geteidtform.musicAppImgUrl,
								desc: '音乐',
								name: '',
								path: geteidtform.musicAppImgUrl,
								isshow: geteidtform.musicAppImgUrl ? true : false,
							},
							{
								imageUrl: this.imgbaseUrl + geteidtform.fmAppImgUrl,
								desc: '广播',
								name: '',
								path: geteidtform.fmAppImgUrl,
								isshow: geteidtform.fmAppImgUrl ? true : false,
							}
						];
						this.themefileList = [];

						for(let i in themepreview) {
							this.themefileList.push({
								name: themepreview[i].fileName,
								url: this.imgbaseUrl + themepreview[i].filePath
							})
						}
						this.ruleForm.widthscroll = geteidtform.widthscroll; //滚屏row
						this.ruleForm.heighscroll = geteidtform.heighscroll; //滚屏col		
						if(!this.ruleForm.widthscroll) {
							this.ruleForm.widthscroll = 10;
						}
						if(!this.ruleForm.heighscroll) {
							this.ruleForm.heighscroll = 10;
						}
						this.themefile = geteidtform.filesJson;
						let copyJson = {
							widthscroll: this.ruleForm.widthscroll,
							heighscroll: this.ruleForm.heighscroll,
							longPalace: getbaseJson.row,
							widePalace: getbaseJson.col,
							screeStyle: getbaseJson,
							widgetJson: widgetjson
						};
						copyJson.longResolution = geteidtform.longResolution ? geteidtform.longResolution : 320;
						copyJson.wideResolution = geteidtform.wideResolution ? geteidtform.wideResolution : 580;
						bus.$emit('EditorCopy', copyJson);
						if(this.themeimg[0].path && this.themeimg[1].path && this.themeimg[2].path && this.themeimg[3].path) {
							this.ruleForm.apppicture = '1';
						}
						this.ruleForm.prethemmimg = '1';
						this.$refs['ruleForm'].validateField('prethemmimg', (validMessage) => {});
						this.emitChange();
					})
					.catch(err => {
						console.log(err);
					});
			}
			if(this.$route.path == '/theme/addtheme') {
				this.titMsg = '创建新主题';
				this.iseditorcopy = false;
				let utype = JSON.parse(sessionStorage.getItem('userMsg')).userType;
				if(utype == 0 || utype == 2) {
					this.iseditorcopy = true;
				}

			}

			//			else {

			//			}
		}
	},
	watch: { //监听
		'$route' (to, from) { // 对路由变化作出响应...

		},
		'istoSave' () {
			this.submitForm();
		},
		'isShowscroll' () {
			console.log(this.isShowscroll)
			if(this.isShowscroll) {
				this.ruleForm.gridOrRelative = 8;
			} else {
				this.ruleForm.gridOrRelative = 6;
			}
		}
	},
	created() { //实例创建之后
		this.changeTile();
		this.getqudao();
		this.getthemeOptions();
		this.getversionArr();
		this.getUsermsg();
	},
	components: {
		editvue
	}
}