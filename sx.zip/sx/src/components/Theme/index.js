import axios from "@/axios.js";
import "./theme.css";
//import bus from "@/bus.js";
export default {
	data() {
		return {
			loading: true,
			themeOptions: [],
			qudao: [],
			isOn: [{
				value: '',
				label: '全部'
			},
			{
				value: '0',
				label: '暂存'
			},{
				value: '1',
				label: '未上架'
			}, {
				value: '2',
				label: '已上架'
			},			 
			{
				value: '3',
				label: '已下架'
			}],
			qudaostr: '全部渠道', //存储选择的渠道
			tabPosition: '昨天',
			value6: '',
			tableData3: [], //列表数据
			dialogpreview: false, //控制预览
			multipleSelection: [],
			input21: '',
			category: '全部', //主题类别
			state: '全部', //上架状态
			version: '', //主题版本
			versionArr: [], //获取version数组
			themeName: '', //主题名称
			pazeSize: 10, //单页条数
			currentpage: 1, //当前页
			totalNum: 1, //总数
			themeimg: '', //主题名称
			file: [], //预览的文件
			theme: '', //预览主题名
			xuanzhong: [], //选中的列表
			xuanstr: '', //选中列表转成的str
			isqudao: false, //是否是渠道管理员
			itemstarttime: '', //开始时间
			itemendtime: '', //结束时间
			operatemsg: '批量操作', //显示操作字段
			isshowcheck: false,
			isshowfoot: false,
			preTitle: '',
			themeLimit:"",//主题权限
			searchFlag:false,//主题列表是否显示
			previewFlag:false,//预览主题是否显示
			createFlag:false,//创建副本是否显示
			groundFlag:false,//主题上下架功能是否显示
			newFlag:false,//新建主题是否显示
			editFlag:false,//编辑主题是否显示
			deleteFlag:false,//删除主题
			creator:"",//判断登录人的id
		}
	},
	mounted() { //实例挂载之后	
		this.getUsermsg();
		this.drawLine();
		this.drawPie();
		this.$router.push({ //清空query
			path: this.$route.path,
			query: {}
		})
		this.getTabledata(1, 10);
	},
	methods: { //方法	
		getUsermsg() { //获取用户
			let userMsg = JSON.parse(sessionStorage.getItem('userMsg'));
			this.isqudao = userMsg.userType;
			this.creator=userMsg.channelId;
			let limit=userMsg.listPermissions;
			for(let i in limit){
				if(limit[i].introducs=="主题管理"){
					this.themeLimit=limit[i].listPermissions;
				}
			}

			for(let i in this.themeLimit){
				switch(this.themeLimit[i].introducs){
					case "主题列表":
					  this.searchFlag=true;
					  break;
					case "预览主题":
					  this.previewFlag=true;
					  break;
					case "删除主题":
					  this.deleteFlag=true;
					  break;
					case "创建副本":
					  this.createFlag=true;
					  break;
					case "主题上下架":
					  this.groundFlag=true;
					  break;
					case "新建主题":
					  this.newFlag=true;
					  break;
					case "编辑主题":
					  this.editFlag=true;
					  break;
				}
			}
		},
		indexMethod(index) {
			return index + 1 + (this.currentpage - 1) * this.pazeSize
		},
		showcheck() {
			this.isshowcheck = !this.isshowcheck;
			if(this.isshowcheck) {
				this.operatemsg = '完成';
			} else {
				this.operatemsg = '批量操作';
			}
		},
		//tab
		toggleSelection(rows) {
			if(rows) {
				rows.forEach(row => {
					this.$refs.multipleTable.toggleRowSelection(row);
				});
			} else {
				this.$refs.multipleTable.clearSelection();
			}
		},
		saveQuery() {
			var queryData = {
				category: this.category,
				state: this.state,
				themeName: this.themeName,
				channel: this.$route.query.channel,
				version: this.version
			};
			this.$router.push({
				path: this.$route.path,
				query: queryData
			})
			this.getTabledata(1, 10)
		},
		getqudao() {
			axios.get('/system/channel/findAll')
				.then((res) => {
					this.qudao = res.data.data;
					this.qudao.unshift({
						"name": "全部渠道",
						"id": ""
					})
				})
				.catch(err => {
					console.log(err);
				});
		},
		getversionArr() { //获取版本数组
			axios.get('/system/theme/selectVersion')
				.then((res) => {
					this.versionArr = res.data.data
				})
				.catch(err => {
					console.log(err);
				});
		},
		savequdao() {
			this.$router.push({ //清空query
				path: this.$route.path,
				query: {
					channel: this.qudaostr
				}
			})
			this.category = '';
			this.state = '';
			this.themeName = '';
			this.getTabledata(1, 10);

		},
		getTabledata(page, size) { //获取表单数据
			this.loading = true;
			let data = {
				params: {
					channel: this.$route.query.channel ? this.$route.query.channel : '',
					type: this.$route.query.category && this.$route.query.category != '全部' ? this.$route.query.category : '',
					status: this.$route.query.state && this.$route.query.state != '全部' ? this.$route.query.state : '',
					title: this.$route.query.themeName ? this.$route.query.themeName : '',
					version: this.$route.query.version ? this.$route.query.version : '',
					pageSize: size,
					pageNum: page
				}
			};
			axios.get('/system/theme/selectByCount', data)
				.then((res) => {
					this.loading = false;
					this.tableData3 = res.data.data.list
					this.isshowfoot = res.data.data.list.length;
					this.totalNum = res.data.data.total;

					for(let i = 0; i < this.tableData3.length; i++) {
						this.tableData3[i].isShow="";
						if(this.tableData3[i].status == 1) {
							this.tableData3[i].status = '未上架'
							this.tableData3[i].msg = '上架'
						}
						if(this.tableData3[i].status == 2) {
							this.tableData3[i].status = '已上架'
							this.tableData3[i].msg = '下架'
						}
						if(this.tableData3[i].status == 3){
							this.tableData3[i].status = '已下架'
							this.tableData3[i].msg = '上架'
						}

						if(this.tableData3[i].status == 0){
							this.tableData3[i].status = '暂存'
							this.tableData3[i].msg = ''
						}

						if((this.isqudao==0) || (this.isqudao==2)){
							this.tableData3[i].isShow=true;
						}else{
							if(this.creator==this.tableData3[i].createId){
							  this.tableData3[i].isShow=true;
							}else{
							  this.tableData3[i].isShow=false;
							}
						}
					}
				})
				.catch(err => {
					console.log(err);
				});
		},
		getthemeOptions() {
			axios.get('/system/theme/selectByType')
				.then((res) => {
					this.themeOptions = res.data.data;
					this.themeOptions.unshift({
						"classificationName": "全部",
						"id": " "
					})
				})
				.catch(err => {
					console.log(err);
				});
		},
		handleEdit(index, row) {
			sessionStorage.setItem('currentTheme_ID',row.id);
			sessionStorage.setItem('currentTheme_createId',row.creatorChannelId)
			this.$router.push({
				path:'/theme/edittheme'
			})			
		},
		shangjiaxia(index, row) {
			let time = new Date().getTime();
			if(row.msg == "上架") {
				let status=row.status=="已上架"?3:1;
				if(time >= row.startTime && time <= row.endTime) {
					this.getsupdown(row.id,status)
				} else {
					this.$message({
						type: 'error',
						message: '此主题日期无效，请重新编辑设置!'
					});
				}
			} else {
				let statuscoid = row.msg == '上架' ? 1 : 2;
				this.getsupdown(row.id + ',', statuscoid)
			}

		},
		getsupdown(ids, status) {
			let data = {
				ids: ids,
				status: status
			};
			axios.post('/system/theme/modifyStatus', data)
				.then((res) => {
					this.$message({
						type: 'success',
						message: '操作成功!'
					});

					this.getTabledata(this.currentpage, 10)
				})
				.catch(err => {
					console.log(err);
				});
		},
		handleDelete(index, row) {
			let msg = '确定删除主题：' + row.title + '吗？'
			this.$confirm(msg, '提示', {
				confirmButtonText: '确定',
				cancelButtonText: '取消',
				type: 'warning'
			}).then(() => {
				let data = {
					id: row.id
				};
				axios.post('/system/theme/delectById', data)
					.then((res) => {
						this.$message({
							type: 'success',
							message: '删除成功!'
						});
						this.currentpage=1;
						this.getTabledata(this.currentpage, 10)
					})
					.catch(err => {
						console.log(err);
					});
			}).catch(() => {
				this.$message({
					type: 'info',
					message: '已取消删除'
				});
			});

		},
		creatCopy(index, row) {
			sessionStorage.setItem('currentTheme_ID',row.id)
			this.$router.push({
				path:'/theme/creattheme'
			})	
		},
		preView(index, row) {
			this.file = [];
			this.themeimg = ''
			this.dialogpreview = true;
			this.itemstarttime = this.get_Timer(new Date(row.startTime), 2);
			this.itemendtime = this.get_Timer(new Date(row.endTime), 2);
			this.preTitle = row.title;
			let data = {
				params: {
					id: row.id
				}

			};
			axios.get('/system/theme/selectById', data)
				.then((res) => {
					this.theme = res.data.data.theme;
					this.themeimg = res.data.data.file[0].filePath;
					for(let i = 0; i < res.data.data.file.length; i++) {
						if(res.data.data.file[i].type == 1) {
							this.themeimg = res.data.data.file[i].filePath;
						} else {
							if(this.file.length < 3) {
								this.file.push(res.data.data.file[i])
							}
						}
					}
				})
				.catch(err => {
					console.log(err);
				});

		},
		handleSelectionChange(val) {
			this.multipleSelection = val;
			var arr = [];
			for(let i = 0; i < val.length; i++) {
				arr.push(val[i].id)
			}
			this.xuanstr = arr.join(',');

		},
		handleSizeChange(val) {
			this.pazeSize = val;
			this.currentpage = 1;
			this.getTabledata(1, val)
		},
		handleCurrentChange(val) {
			this.currentpage = val;
			this.getTabledata(val, this.pazeSize)
		},
		newtheme() {
			this.$router.push({
				path: "/theme/addtheme"
			})
		},
		pshang() {
			this.getsupdown(this.xuanstr, 1)
		},
		pxia() {
			this.getsupdown(this.xuanstr, 2)
		},
		//折线图
		drawLine() {
			let line = this.$echarts.init(document.getElementById('line'));
			line.setOption({
				title: {
					text: '有效主题',
					left: 'center',
					top: "10px",
					textStyle: {
						fontFamily: 'PingFangSC-Semibold',
						fontSize: 18,
						color: '#96969E',
					}
				},
				tooltip: {
					trigger: 'axis'
				},
				legend: {
					bottom: '20px',
					data: ['百度', '360渠道', '腾讯手机应用', '易鑫', '滴滴'],
					axisLine: {
						lineStyle: {
							opacity: 0
						}
					}
				},
				xAxis: {
					type: '',
					//boundaryGap:''
					data: ['02-29', '03-03', '03-07', '03-11', '03-15', '03-19'],
					axisLine: {
						lineStyle: {
							opacity: 0,
							type: "dotted"
						}
					},
					axisTick: {
						show: false
					}
				},
				yAxis: {
					type: 'value',
					axisLine: {
						lineStyle: {
							opacity: 0
						}
					},
					axisTick: {
						show: false
					}
				},
				series: [{
						name: '百度',
						type: 'line',
						stack: '总量',
						smooth: true,
						data: [20, 32, 11, 34, 30, 20, 10]
					},
					{
						name: '360渠道',
						type: 'line',
						smooth: true,
						stack: '总量',
						data: [20, 32, 10, 34, 10, 23, 21]
					},
					{
						name: '腾讯手机应用',
						type: 'line',
						smooth: true,
						stack: '总量',
						data: [10, 32, 11, 34, 10, 30, 10]
					},
					{
						name: '易鑫',
						type: 'line',
						smooth: true,
						stack: '总量',
						data: [20, 13, 1, 14, 0, 30, 21]
					},
					{
						name: '滴滴',
						type: 'line',
						smooth: true,
						stack: '总量',
						data: [10, 32, 11, 34, 9, 30, 20]
					}
				]
			})
		},
		//饼图
		drawPie() {
			let legendData = [{
					name: '呆萌企鹅',
					icon: 'circle',
					textStyle: {
						color: '#E68191'
					}
				},
				{
					name: '十二生肖',
					icon: 'circle',
					textStyle: {
						color: '#A98BCD'
					}
				},
				{
					name: '年后时光',
					icon: 'circle',
					textStyle: {
						color: '#AECD8B'
					}
				},
				{
					name: '午夜精灵',
					icon: 'circle',
					textStyle: {
						color: '#85B4CA'
					}
				},
				{
					name: '空空空空',
					icon: 'circle',
					textStyle: {
						color: '#E6B981'
					}
				},
				{
					name: '其他',
					icon: 'circle',
					textStyle: {
						color: '#808080'
					}
				}
			];
			let seriesData = [{
					name: '呆萌企鹅',
					time: '2018-4-25',
					value: 225
				},
				{
					name: '十二生肖',
					time: '2018-4-25',
					value: 234
				},
				{
					name: '年后时光',
					time: '2018-4-25',
					value: 234
				},
				{
					name: '午夜精灵',
					time: '2018-4-25',
					value: 135
				},
				{
					name: '空空空空',
					time: '2018-4-25',
					value: 148
				},
				{
					name: '其他',
					time: '2018-4-25',
					value: 1548
				},

			]
			let pie = this.$echarts.init(document.getElementById('pie'));
			pie.setOption({
				//标题
				title: {
					text: '使用次数',
					//left:'center',
					top: '45%',
					left: '22%',
				},
				//提示框组件
				tooltip: {
					trigger: `item`,
					formatter: function(params, ticket, callback) {
						let paramsData = params.data;
						let res = '主题：' + paramsData.name +
							'<br/>' + '日期：' + paramsData.time + '<br/>' + '使用次数：' + paramsData.value + '<br/>' + '使用次数占比：' + params.percent + '%';
						return res;
					},
					backgroundColor: '#FFFFFF',
					//提示框字体设置
					textStyle: {
						width: 160,
						height: 130,
						fontSize: 14,
						color: '#96969E',
						fontFamily: 'PingFangSC-Regular',
						lineHeight: 20,
					}
				},
				//图例
				legend: {
					//type: 'scroll',
					orient: 'horizontal',
					width: 400,
					height: 100,
					right: 200,
					top: 90,
					bottom: 20,
					//单个图例设置
					itemWidth: 14,
					itemHeight: 100,
					itemGap: 30,

					textStyle: {
						fontFamily: 'PingFangSC-Semibold',
						fontSize: 16,
						color: ' #96969E',
						lineHeight: 22,
						padding: [6, 34, 7, 12],
					},
					data: legendData,
				},
				series: [{
					name: '',
					type: 'pie',
					radius: ['50%', '70%'],
					center: ['25%', '50%'],
					label: {
						normal: {
							show: true,
							formatter: '{d}%',
						}
					},
					data: seriesData,
				}]
			})
		},

	},
	watch: { //监听
		'$route' (to, from) { // 对路由变化作出响应...

		},
	},
	created() { //实例创建之后

	}
}