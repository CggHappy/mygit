import axios from "@/axios.js";
import bus from "@/bus.js";
import "./freeWidget.css";
import editvue from '../editWidget/index.vue';
import store from "@/vuex/store.js";
export default {
	data() {
		var validateUser = (rule, value, callback) => {
			let reg = /^[a-zA-Z0-9_\u4e00-\u9fa5]{1,20}$/;
			if(!reg.test(value)) {
				callback(new Error('请输入1-20位中文、字母、数字和下划线的名称'));
			}
			callback();
		};
		var validateNumber = (rule, value, callback) => {
			let reg = /^([1-9])([0-9]*)$/;
			if(!reg.test(value)) {
				callback(new Error('请输入一个正整数'));
			}
			callback();
		};
		return {
			dialogVisible: false,
			category: [], //新增分类列表
			ruleForm: {
				newName: '', //活动名称
				widgetCategory: '', //分类
				version: '', //
				description: "", //描述版本
				channels: [],
				widgetCategory:"",//widget分类
				widthSize:"",//宫格宽
				heightSize:"",//宫格高
				path:"",//封面图片
			},
			rules: {
				newName: [{
						required: true,
						message: '请输入widget名称',
						trigger: 'blur'
					},
					{
						validator: validateUser,
						trigger: 'blur'
					}
				],
				widgetCategory: [
                 	{ required: true, message: '请选择widget分类', trigger: 'change' }
               	],
               	version: [
                 	{ required: true, message: '请选择适用的版本', trigger: 'change' }
              	],
               	widthSize: [
                 	{ required: true, message: '请输入宫格的宽度', trigger: 'blur' },
                 	{validator: validateNumber,trigger: 'blur'}
               	],
               	heightSize: [
                 	{ required: true, message: '请输入宫格的高度', trigger: 'blur' },
                 	{validator: validateNumber,trigger: 'blur'}
               	],
               	path: [
                 	{  required: true,message: '请上传widget封面',trigger: 'change'}
               	],
               	description:[
               		{max:100,message: '请输入100以内的字符', trigger: 'blur' }
               	]
			},
			imageUrl: '',
			channels: [],
			freeTitle: "", //页面进来显示的标题
			dialogImageUrl: '',
			dialogVisible: false, //分类弹窗
			dialogVisibless: false, //图片弹窗
			labels: [], //label列表
			widgetCategoryList: [], //widget类型
			widgetVersinList: [],
			labelsArray: [], //check ID
			uploadToken: {},
			widgetData:"",//widget分类
			addBtnIS:false,//添加
			isAdd:true,
			add:true,
		}
	},
	mounted() { //实例挂载之后
		this.category = [];
		this.title(); //标题
		this.fromDatas()
		if(this.$route.path == '/diywidget/editfwidget' || this.$route.path == '/diywidget/createfwidget') {
			let data = {
				params: {
					widgetId: JSON.parse(sessionStorage.getItem('menuData'))[0].id
				}
			}
			axios.get('/system/showGroupWidget', data)
				.then(res => {
					this.ruleForm = JSON.parse(res.data.data.gproperty)
					this.ruleForm.id = JSON.parse(sessionStorage.getItem('menuData'))[0].id;
					if(this.$route.path == '/diywidget/createfwidget') {
						this.ruleForm.id = ''
					}
					let chani=[];
					if(this.ruleForm.channels.length>0){
						chani = this.ruleForm.channels.split(',');
						for(let i in chani){
							chani[i]=Number(chani[i])
						}
					}
					this.channels = chani;
					bus.$emit('geteditwids', {
						data: JSON.parse(res.data.data.property),
						style: this.ruleForm
					}) //bus传值
					bus.$emit('fromDatas', this.ruleForm) //bus传值
				})
				.catch(err => {
					console.log(err)
				})
		}

	},
	methods: { //方法
		handleAvatarSuccess(res, file) {
			this.imageUrl = URL.createObjectURL(file.raw);
			this.ruleForm.path = res;
			this.ruleForm.fengmian = file.name;
			this.$refs['ruleForm'].validateField('path',(validMessage)=>{
		        
		    })
			this.changes();
		},
		getUsermsg() {
			let userMsg=JSON.parse(sessionStorage.getItem('userMsg'));
			let isqudao=userMsg.userType;
			this.addBtnIS=(isqudao==0) || (isqudao==2)?true:false;
			let token = sessionStorage.getItem('Token');
			this.uploadToken = {
				Authorization: token
			};
			if(this.$route.path.indexOf('addwidget')>0){
				this.add=true;
				this.isAdd=true;
			}
			if(this.$route.path.indexOf("addwidget") <0) {
				let creator=JSON.parse(sessionStorage.getItem('creator'));
				if(!this.addBtnIS){//渠道
					this.checkListId=userMsg.channelId;
				}else{//管理员
					this.add=true;
					if(creator.channelUserName!="管理员"){
						this.isAdd=false;
					}else{
						this.isAdd=true;
					}
				}
			}
			

		},
		beforeAvatarUpload(file) {
			const isJPG = file.type === 'image/jpeg';
			const isPNG = file.type === 'image/png';
			if(!isJPG && !isPNG) {
				this.$message.error('上传封面图片只能是 JPG、PNG 格式!');
			}
			return isJPG || isPNG;
		},
		fromDatas() {
			//使用渠道
			axios.get('/system/channel/findAll')
				.then(res => {
					this.labels = res.data.data;
					let labels = this.labels;
					let labelsArray = [];
					for(let lab of labels) {
						labelsArray.push(lab.id);
						this.labelsArray = labelsArray
					}
				
				})
				.catch(err => {
					console.log(err)
				})

			//widget列表
			axios.get('/system/findWidgetCategory')
				.then(res => {
					this.widgetCategoryList = res.data.data.list
				})
				.catch(err => {
					console.log(err)
				})

			//widget版本
			axios.get('/system/findWidgetVersion')
				.then(res => {
					this.widgetVersinList = res.data.data
				})
				.catch(err => {
					console.log(err)
				})
		},
		title() {
			let path = this.$route.path;
			if(path.indexOf("addwidget") > 1) {
				this.freeTitle = "添加自定义控件"
			} else {
				this.freeTitle = "编辑基础widget";
				this.getMenudata()
			}
			if(this.$route.path == '/diywidget/createfwidget') {
				this.freeTitle = '创建副本'
			}
		},
		changes(value) {
			let userMsg=JSON.parse(sessionStorage.getItem('userMsg'));
			
		    if(!this.addBtnIS){
				this.ruleForm.channels=userMsg.channelId;
			}else{
				this.ruleForm.channels = this.channels.join(",");
			}
			
			if(this.ruleForm.channels === '') {
				this.ruleForm.channels = this.labelsArray.join();
			}
			if(this.$route.path == '/diywidget/editfwidget') {
				this.ruleForm.id = JSON.parse(sessionStorage.getItem('menuData'))[0].id;
			}
			bus.$emit('fromDatas', this.ruleForm) //bus传值
		},
		changeCheck(value){
			this.ruleForm.channels = this.channels.join(",");
			this.changes();
		},
		getMenudata() {
		},
		addstyle() { //添加分类
			this.dialogVisible = true;
			this.category = [];
		},
		addCategory() { //添加分类			
			let leng = this.category.length;
			if(this.category.msg != '') {
				this.category.push({
					msg: ''
				});
			}
		},
		removeCategory(index) { //添加分类弹出框删除数据
			this.category.splice(index, 1)
		},
		changesize() {
			if(this.ruleForm.widthSize=="" || this.ruleForm.heightSize==""){
				this.$message({
					type: 'warn',
					message: '请输入正确的widget宫格比例!'
				});
			}else{
				bus.$emit('changeSize', this.ruleForm) //bus传值
				this.$message({
					type: 'warn',
					message: '如果已添加的widget无法操作，说明超出宫格比例，请调整宫格比例，即可操作!'
				});
			}
			
		},
		categorySure() { //点击确定时保存数据
			this.dialogVisible = false;
			var arr = [];
			for(let i = 0; i < this.category.length; i++) {
				arr.push(this.category[i].msg)
			}
			let categoryAarry = this.category;
			let arrays = [];
			for(let cat of categoryAarry) {
				arrays.push(cat.msg)
			}
			let arraysData = [...new Set(arrays)]
			let data = {
				typeName: arraysData.join(",")
			};
			axios.post('/system/insertWidgetType', data)
				.then((res) => {
					this.$message({
						type: 'success',
						message: res.data.data
					});
					this.widgetCategory();
				})
				.catch(err => {
					console.log(err);
				});
		},
		widgetCategory() { //widget下拉框数据
			axios.get('/system/findWidgetCategory')
				.then((res) => {
					this.categorySelect=res.data.data.list
				})
				.catch(err => {
					console.log(err);
				});
		},
		availableVersion() { //版本下拉框数据
			axios.get('/system/findWidgetVersion')
				.then((res) => {
					this.sizeWidget=res.data.data.list
				})
				.catch(err => {
					console.log(err);
				});
		},
		handleRemove(file, fileList) {
		},
		handlePictureCardPreview(file) {
			this.dialogImageUrl = file.url;
			this.dialogVisibless = true;
		},
		submitForm() {
			this.$refs['ruleForm'].validateField('path',(validMessage)=>{
		        
		    })
			store.state.widgetValid=false;
	        this.$refs['ruleForm'].validate((valid) => {
	        	if (valid) {
	        	  store.state.widgetValid=valid;
	        	} else {
	        	  this.$message.error('请填写完整的信息！');
	        	  return false;
	        	}
	        });
	    },
	},
	watch: { //监听
		'$route' (to, from) { // 对路由变化作出响应...

		},
		'widgettoClick'(){
			this.submitForm()
		},
	},
	created() { //实例创建之后
		this.getUsermsg();
	},
	components: {
		editvue
	},
	computed:{
		widgettoClick(){
			return store.state.widgetClick
		},
	}

}