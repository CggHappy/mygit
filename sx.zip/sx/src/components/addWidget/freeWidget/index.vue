<template>
	<div class="zwjAddWidget">
		<div class="all_contain">
			<header class="widgetManage">
				<el-breadcrumb separator-class="el-icon-arrow-right">
					<el-breadcrumb-item :to="{ path: '/diywidget/index' }">布局控件管理</el-breadcrumb-item>
					<el-breadcrumb-item>{{freeTitle}}</el-breadcrumb-item>
				</el-breadcrumb>
			</header>
			<div class="widgetCustom">
				<el-form :model="ruleForm" :rules="rules" ref="ruleForm" label-width="100px" class="demo-ruleForm">
				  <el-form-item label="widget名称" prop="newName">
				    <el-input @change="changes" v-model="ruleForm.newName"></el-input>
				  </el-form-item>
          <el-form-item label="使用渠道" prop="channels" v-if="addBtnIS && isAdd && add">
          <div class="channelSelect">
              <template>
                <el-checkbox-group v-model="channels" @change="changeCheck">
                  <el-checkbox v-for="(lab,index) in labels" :key="index" :label="lab.id" :value="lab.id">{{lab.name}}</el-checkbox>
                </el-checkbox-group>
              </template>
          </div>
          <div class="tip">不勾选，默认全部使用</div>
          </el-form-item>
  				  <el-form-item label="Widget分类" prop="widgetCategory">
  				    <el-select  @change="changes" placeholder="请选择" v-model="ruleForm.widgetCategory" @focus="widgetCategory">
  				      <el-option v-for="(val,index) in widgetCategoryList" :key="index" :label="val.typeName" :value="val.id">{{val.typeName}}</el-option>
  				    </el-select>
  				    <el-button type="primary" @click="addstyle" style="background:#84A1E5;border-color:#84A1E5" v-if="addBtnIS && isAdd && add">添加分类</el-button>
  				    <el-dialog
  				      title="添加Widget分类"
  				      :visible.sync="dialogVisible"
  				      width="45%">
  				      	<div class="addCategoryTitle">
  				      		<el-button @click="addCategory">增加</el-button><span class="nameTitle">分类名称最多4个字符</span>
  				      	</div>
  				     	<div class="addCategory">
  				     		<div class="categoryModel" v-for="(item,index) in category" :key='index'>
  			     				<input class="customCategory" v-model='item.msg' maxlength=4 /><span class="remove" @click="removeCategory(index)">-</span>
  			     			</div>
  				     	</div>
  				      <span slot="footer" class="dialog-footer">
  				        <el-button @click="dialogVisible = false">取 消</el-button>
  				        <el-button type="primary" @click="categorySure">确 定</el-button>
  				      </span>
  				    </el-dialog>
  				  </el-form-item>
  				  <el-form-item label="适用" prop="version">
  				    <el-select @change="changes" placeholder="请选择尺寸" v-model="ruleForm.version" @focus="availableVersion">
  				      <el-option v-for="(val,index) in widgetVersinList" :key="index" :label="val.attributeValue" :value="val.attributeKeyIndex"></el-option>
  				    </el-select>
  				    <span>以上版本</span>
  				  </el-form-item>	
  				  <div class="selectModel el-form-item is-required">
              <label class="channel el-form-item__label" style="width:100px">宫格大小</label>
              <div class="el-form-item__content" style="margin-left: 100px!important;">
                  <el-form-item style="float:left" prop="widthSize">
                    <el-input @change="changes"  v-model="ruleForm.widthSize" style="width:100px;" prop="widthSize"></el-input>
                  </el-form-item>           
                  <span style="float:left">*</span>
                  <el-form-item prop="heightSize" style="float:left">
                    <el-input @change="changes"  v-model="ruleForm.heightSize" style="width:100px;" prop="heightSize"></el-input>
                  </el-form-item>           
                  <el-button type="primary" class="widgetBtn" style="" @click='changesize'>确定</el-button>
              </div>
            </div>
  				  <el-form-item label="Widget封面" prop="path">
  				   	<div class="widgetBgImg">
                
                
              <el-upload
  class="avatar-uploader"
  action="http://api.launcher.pactera-sln.club:8185/system/fileUpload"
  :show-file-list="false"
  :headers='uploadToken'
  :on-success="handleAvatarSuccess"
  :before-upload="beforeAvatarUpload" :on-change="changes">
  <img v-if="imageUrl||ruleForm.path" :src="imageUrl?imageUrl:imgbaseUrl+ruleForm.path" class="avatar">
  <i v-else class="el-icon-plus avatar-uploader-icon"></i>
</el-upload>
                
                
                <el-dialog :visible.sync="dialogVisibless">
                  <img width="100%" :src="dialogImageUrl" alt="">
                </el-dialog>
              </div>
  				  </el-form-item>
            <el-form-item label="描述" prop="description">
              <el-input @change="changes" type="textarea" resize="none" v-model="ruleForm.description" ></el-input>
            </el-form-item>
				</el-form>
			</div>
      <editvue></editvue>      
		</div>
	</div>
</template>
<script src="./index.js">
</script>
<style scoped="scoped" src="./index.less" lang="less">
</style>