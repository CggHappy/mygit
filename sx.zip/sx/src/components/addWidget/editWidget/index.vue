<template>
	<div class="editWidgets">
		<div class="toolBar">
			<div class="scrollbar">
				<el-collapse v-model="activeName" accordion>

					<el-collapse-item title="Widget" name="0">
						<div class="column-2" data-gs-width='2'>
							<el-select class='selectels' @change="changes" placeholder="请选择" v-model="widgetCategory" @focus="widgetCategory1">
								<el-option v-for="(val,index) in widgetCategoryList" :key="index" :label="val.typeName" :value="val.id"></el-option>
							</el-select>
							<ul>
								<li class="getvalue" v-for="(item,index) in meundata" @click="addWidget(item,index)">
									<div class="imgBox">
										<img :src="imgbaseUrl+item.path" alt="" />
									</div>
									<div class="scriptionB" :title="item.name">
										{{item.name}}({{item.defaultSize}})
									</div>
								</li>
							</ul>
						</div>
					</el-collapse-item>

				</el-collapse>
			</div>
		</div>
		<div class="viewPort">
			<div class="drawIMG" :style="defaultStyle">
				<div class="gridss" ref='screenon' @click="screenSet" :style="setscrStyle" v-if="echartsgird"></div>
				<div class="grid-stack">
				</div>
			</div>

		</div>
		<div class="srtAtributeBox">

			<div class="srtAtribute" v-if="setscreen">
				<p>背景色：{{setscrStyle.background}} <input type="color" v-model="setscrStyle.background" /></p>
			</div>
			<div class="srtAtribute" v-if='!setscreen'>
				<div class="nature">
					<p :title="setattribute.description">名称：<input type="text" v-model="setattribute.category" class="inputSelf" /></p>
					<p>x: {{setattribute.x}} y：{{setattribute.y}}</p>
					<p>宽 {{setattribute.width}} 高：{{setattribute.height}}</p>
					<div class="" v-for="(item,index) in setattribute.setting">
						<div class="property" v-if="item.type=='ImageSet'">
							<div class="title">
								{{item.label}}：
							</div>
							<div class="propertyMain">
								<ul class="propertyUl">
									<li class="typeMain" v-if="item.default.hasOwnProperty('alignType')">
									    <p class="typeName">对齐：</p>
									    <div class="typeBox">
									      <p class="type typeAlign" v-if="item.default.alignType">
									        <template>
									          <el-select v-model="item.default.alignType" placeholder="请选择" @focus="uploadClick(item,index)">
									            <el-option
									              v-for="(ele,index) in alignType"
									              :key="ele.value"
									              :label="ele.label"
									              :value="ele.value">
									            </el-option>
									          </el-select>
									        </template>
									      </p>
									    </div>
									</li>
									<li class="typeMain" v-if="item.default.hasOwnProperty('scaleType')">
									   <p class="typeName">缩放 ：</p>
									   <div class="typeBox">
									     <p class="type">
									         <template>
									           <el-select v-model="item.default.scaleType" placeholder="请选择" @focus="uploadClick(item,index)">
									             <el-option
									               v-for="(item,index) in scaleType"
									               :key="item.value"
									               :label="item.label"
									               :value="item.ident">
									             </el-option>
									           </el-select>
									         </template>
									     </p>
									   </div>
									</li>
									<li class="typeMain" style="margin:3px 0 5px 0" v-if="item.default.hasOwnProperty('color')">
	                                     <p class="typeName">颜色：</p>
	                                     <p class="type">
	                                        <span>{{item.default.color}}</span><input type="color" v-model="item.default.color"/>
	                                     </p>
	                                 </li>
									<li class="typeMain" style="height: 150px;" v-if="item.default.hasOwnProperty('nine-path') || item.default.hasOwnProperty('image')">
										<p class="typeName">图片上传：</p>
										<p class="type typeImg">
											<el-upload  :headers='uploadToken' v-if="item.default.hasOwnProperty('nine-path')" class="avatar-uploader" action="http://api.launcher.pactera-sln.club:8185/system/fileUpload" :show-file-list="false" :auto-upload="true" :valule=item.key :on-success="handleAvatarSuccess" :before-upload="beforeAvatarUpload">
												<img v-if="item.default['nine-path']" :src="item.backupSrc?item.backupSrc:imgbaseUrl+setattribute.file[item.default['nine-path']]" class="avatar" @click="uploadClick(item,index)">
												<i v-else class="el-icon-plus avatar-uploader-icon" @click="uploadClick(item,index)"></i>
											</el-upload>
											<el-upload  :headers='uploadToken' v-if="item.default.hasOwnProperty('image')" class="avatar-uploader" action="http://api.launcher.pactera-sln.club:8185/system/fileUpload" :show-file-list="false" :auto-upload="true" :on-success="handleAvatarSuccess" :before-upload="beforeAvatarUpload">
												<img v-if="item.default['image']" :src="item.backupSrc?item.backupSrc:imgbaseUrl+setattribute.file[item.default['image']]" class="avatar" @click="uploadClick(item,index)">
												<i v-else class="el-icon-plus avatar-uploader-icon" @click="uploadClick(item,index)"></i>
											</el-upload>
										</p>

									</li>
								</ul>
							</div>
						</div>
						<div class="property" v-if="item.type=='TextSet'">
							<div class="title">
								{{item.label}}：
							</div>
							<div class="propertyMain">
								<ul class="propertyUl">
									<li class="typeMain"  v-if="item.default.hasOwnProperty('def_text')">
										<p class="typeName" >内容：</p>
										<p class="type"><input type="text" v-model="item.default.def_text" class="inputSelf" /></p>
									</li>
									<li class="typeMain" v-if="item.default.hasOwnProperty('size')">
										<p class="typeName">大小：</p>
										<p class="type"><input type="text" v-model="item.default.size" class="inputSelf" /></p>
									</li>
									<li class="typeMain" v-if="item.default.hasOwnProperty('color')">
										<p class="typeName">颜色：</p>
										<p class="type">
											<span>{{item.default.color}}</span><input type="color" v-model="item.default.color" style='margin-left: 6px;' />
										</p>
									</li>
									<li class="typeMain" v-if="item.default.hasOwnProperty('font_style')">
										<p class="typeName">风格：</p>
										<p class="type">
											<template>
												<el-checkbox v-model="item.default.font_style" v-for="(ele,index) in fontStyle" :label="ele" :value="ele.index" :key="ele.index">{{ele}}</el-checkbox>
											</template>
										</p>
									</li>
									<li class="typeMain" v-if="item.default.hasOwnProperty('line_spacing')">
										<p class="typeName">行间距：</p>
										<p class="type"><input type="text" v-model="item.default.line_spacing" class="inputSelf" /></p>
									</li>
									<div class="typeMain flex" v-if="item.default.hasOwnProperty('background')">
                              <p class="">背景</p>
                              <div class="backgroundMain">
                                  <li class="typeMain" v-if="item.default.background.hasOwnProperty('color')">
                                     <p class="typeName">颜色：</p>
                                     <p class="type" style="margin-top:-2px;">
                                        <span>{{item.default.background.color}}</span><input type="color" v-model="item.default.background.color" class="inputSelf"/>
                                     </p>
                                 </li>
                                 <li class="typeMain" style="height:45px" v-if="item.default.background.hasOwnProperty('alignType')">
                                    <p class="typeName">对齐：</p>
                                    <div class="typeBox">
                                   <p class="type typeAlign" v-if="item.default.background.alignType">
                                     <template>
                                     <el-select v-model="item.default.background.alignType" placeholder="请选择" @focus="uploadClick(item,index)">
                                       <el-option
                                       v-for="(ele,index) in alignType"
                                       :key="ele.value"
                                       :label="ele.label"
                                       :value="ele.value">
                                       </el-option>
                                     </el-select>
                                     </template>
                                   </p>
                                    </div>
                                 </li>
                                 <li class="typeMain" style="height:45px" v-if="item.default.background.hasOwnProperty('scaleType')">
                                    <p class="typeName">缩放 ：</p>
                                    <div class="typeBox">
                                      <p class="type">
                                          <template>
                                            <el-select v-model="item.default.background.scaleType" placeholder="请选择" @focus="uploadClick(item,index)">
                                              <el-option
                                                v-for="(item,index) in scaleType"
                                                :key="item.value"
                                                :label="item.label"
                                                :value="item.ident">
                                              </el-option>
                                            </el-select>
                                          </template>
                                      </p>
                                    </div>
                                 </li>
                                 <li class="typeMain" style="height:150px;" v-if="item.default.background.hasOwnProperty('nine-path') || item.default.background.hasOwnProperty('image'
                                 )">
                                      <p class="typeName">图片上传：</p>
                                      <p class="type typeImg">
                                       <el-upload  :headers='uploadToken' v-if="item.default.background.hasOwnProperty('nine-path')" class="avatar-uploader" action="http://api.launcher.pactera-sln.club:8185/system/fileUpload" :show-file-list="false" :auto-upload="true" :valule=item.key :on-success="handleAvatarSuccessText" :before-upload="beforeAvatarUpload">
												<img v-if="item.default.background['nine-path']" :src="item.backupSrc?item.backupSrc:imgbaseUrl+setattribute.file[item.default.background['nine-path']]" class="avatar" @click="uploadClick(item,index)">
												<i v-else class="el-icon-plus avatar-uploader-icon" @click="uploadClick(item,index)"></i>
											</el-upload>
                                       <el-upload  :headers='uploadToken' v-if="item.default.background.hasOwnProperty('image')" class="avatar-uploader" action="http://api.launcher.pactera-sln.club:8185/system/fileUpload" :show-file-list="false" :auto-upload="true" :on-success="handleAvatarSuccessText" :before-upload="beforeAvatarUpload">
												<img v-if="item.default.background['image']" :src="item.backupSrc?item.backupSrc:imgbaseUrl+setattribute.file[item.default.background['image']]" class="avatar" @click="uploadClick(item,index)">
												<i v-else class="el-icon-plus avatar-uploader-icon" @click="uploadClick(item,index)"></i>
											</el-upload>
                                     </p>
                                     
                                  </li>
                              </div>
                           </div>
								</ul>
							</div>
						</div>
						<div class="property" v-if="item.type=='singleSelect'">
							<div class="title">
								{{item.label}}：
							</div>
							<div class="propertyMain">
								<ul class="propertyUl">
									<li class="typeMain">
										<template>
											<el-radio v-model="item.default" v-for="(ele,index) in item.values" :label="ele.value" :value="ele.index" :key="ele.index">{{ele.lable}}</el-radio>
										</template>
									</li>
								</ul>
							</div>
						</div>
						<div class="property" v-if="item.type=='multiSelect'">
							<div class="title">
								{{item.label}}：
							</div>
							<div class="propertyMain">
								<ul class="propertyUl">
									<li class="typeMain" style="height:auto;">
										<template>
											<el-checkbox-group v-model="item.default">
												<el-checkbox v-for="(item,index) in item.values" :label="item.value" :value="item.value" :key="item.index">{{item.label}}</el-checkbox>
											</el-checkbox-group>
										</template>
									</li>
								</ul>
							</div>
						</div>
						<div class="property" v-if="item.type=='color'">
                        <div class="title">
                          {{item.label}}：  <span>{{item.default.color}}</span><input type="color" v-model="item.default.color"/>
                        </div>
                    	</div>
                    	<div class="property" v-if="item.type=='number'">
                    	     <div class="title">
                    	       {{item.label}}： <el-input style="display:inline-block"></el-input>
                    	     </div>
                    	</div>
                    	<div class="property" v-if="item.type=='text'">
                    	     <div class="title">
                    	       {{item.label}}： <el-input style="display:inline-block" v-model='item.default'></el-input>
                    	     </div>
                    	</div>
					</div>
				</div>
				<div class="fotterAttr">
					<el-button class='footbtn' @click='clearWidget'>删除</el-button>
					<el-button type="primary" @click='saveDate' class='btn_blue footbtn'>完成</el-button>
				</div>
			</div>
		</div>
		<div style="clear: both;"></div>
		<div class="bott_widget">
			<el-button class='footbtn' @click='quit'>取消</el-button>
			<el-button type="primary" @click='saveDatecp' class='btn_blue footbtn'>保存</el-button>
		</div>
	</div>
</template>
<script src="./index.js">
</script>
<style scoped="scoped" src="./index.less" lang="less">

</style>