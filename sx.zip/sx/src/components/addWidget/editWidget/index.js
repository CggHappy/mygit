import axios from "@/axios.js"
import './gridstack.css' //底屏css
import bus from "@/bus.js";
import editvue from '../editWidget/index.vue';
import store from "@/vuex/store.js";
export default {
	data() {
		return {
			setscreen: false, //控制底屏样式与widget样式切换flag
			setscrStyle: {
				background: '#ffffff',
				width: '580',
				height: '580',
				row: '5',
				col: '5'
			},
			defaultStyle: { //底屏style 初始化
				width: '580px',
				height: '350px',
				'margin-left': '-290px'
			},
			addFlag: false, //添加widget到哪个屏的控制
			scrollArr: [], //判断是否是滚动屏还是底屏			
			activeName: '0', //左侧手风琴菜单默认激活项
			options: { //底屏的grid初始化				
				cell_height: 100, //单元格的高度。默认值为60。
				animate: true, //转换为动画。默认为false。
				vertical_margin: 0,
				acceptWidgets: false,
				//				ddPlugin:true,
				auto: true, //如果设置为false将不会初始化已经存在的项。默认为true。
				// draggable：允许覆盖 jQuery UI draggable 选项。默认值：{handle: '.grid-stack-item-content', scroll: true, appendTo: 'body'}。
				always_show_resize_handle: false, //如果设置为true，缩放手柄将会一直显示。默认为false。
				handle: '.grid-stack-item-content', //拖放手柄选择器。默认值为：'.grid-stack-item-content'。
				height: 10, //最大行数。默认为0，意思是没有最大行数。
				width: 10, //网格的列数。默认值为12。
				float: true, //允许元素浮动。默认值：false。
				item_class: 'grid-stack-item', //元素组件的class。默认值'grid-stack-item'。
				min_width: 768, //最小宽度。如果窗口的宽度小于网格的宽度，将会以单列显示。默认值为768。
				placeholder_class: 'grid-stack-placeholder', //placeholder的class。默认值为'grid-stack-placeholder'。
				resizable: {
					autoHide: true,
					handles: 'se'
				}, //允许覆盖jQuery UI resizable选项。默认值为：{autoHide: true, handles: 'se'}。
				//网格属性
				//            data-gs-animate:true,
			},
			meundata: [],
			pushdata: [], //底屏数据保存
			setattribute: {}, //右侧属性
			//从widget拿过来
			fengmian: '',
			alignType: [{
					"label": "左上",
					"value": "LT"
				},
				{
					"label": "左下",
					"value": "LB"
				},
				{
					"label": "右上",
					"value": "RT"
				},
				{
					"label": "右下",
					"value": "RB"
				},
				{
					"label": "顶部居中",
					"value": "THC"
				},
				{
					"label": "底部居中",
					"value": "BHC"
				},
				{
					"label": "左侧居中",
					"value": "LVC"
				},
				{
					"label": "右侧居中",
					"value": "RVC"
				},
				{
					"label": "居中",
					"value": "CENTER"
				}
			],

			scaleType: [{
					"label": "拉伸填充",
					"value": "FIT_XY",
					"ident": "1"
				},
				{
					"label": "原图居中",
					"value": "CENTER",
					"ident": "5"
				},
				{
					"label": "剪切居中",
					"value": "CENTER_CROP",
					"ident": "6"
				},
				{
					"label": "缩小居中",
					"value": "CENTER_INSIDE",
					"ident": "7"
				},
				{
					"label": "左上",
					"value": "FIT_START",
					"ident": "2"
				},
				{
					"label": "居中",
					"value": "FIT_CENTER",
					"ident": "3"
				},
				{
					"label": "右下",
					"value": "FIT_END",
					"ident": "4"
				}
			],
			img: "", //5个图片			
			fontStyle: ["italic", "bold", "underline", "deleteline"],
			currentindex: -1, //当前页			
			//接收上面的数据
			setFormData: {}, //上面form表单数据
			sreenname: '',
			widgetWidth: 5,
			widgetHidth: 8,
			widgetCategory: '',
			widgetCategoryList: [],
			echartsgird: true,
			uType: 0,
			editpushdata: [],
			uploadToken: {},
			alignTypeCheck: "", //对齐默认回显
			scaleTypeCheck: "", //填充默认回显
			saveType: "",
			countZindex: 0,
			currentDom: {},
			channels: "",
			channelnum: "",
			version: "",
		}
	},
	props: ['setForm'], //获取组件外数据
	created() { //实例挂载之前		
		this.setStyle(); //底屏样式初始化
		this.getWidgetsmeun();
		this.getUsermsg()
		bus.$on('fromDatas', (e) => {
			this.setFormData = e;
			this.sreenname = e.newName;
			this.widgetWidth = e.widthSize;
			this.widgetHidth = e.heightSize;
			this.channels = e.channels;
			this.version = e.version;
			this.channelnum = this.channels.split(",").length;
			this.getWidgetsmeun()
		})

	},
	mounted() { //实例挂载之后
		let viewPortWidth = $('.viewPort').outerWidth();
		this.setscrStyle.width = viewPortWidth;
		this.setscrStyle.height = this.setscrStyle.width;
		this.getDefaultstyle(this.setscrStyle.width, this.setscrStyle.height, this.setscrStyle.row, this.setscrStyle.col) //调取初始底屏方法
		bus.$on('changeSize', (e) => {
			this.echartsgird = false;
			this.getDefaultstyle(Number(this.setscrStyle.width) - Number(e.widthSize), Number(this.setscrStyle.height) - Number(e.heightSize), e.widthSize, e.heightSize) //调取初始底屏方法		
		})
		bus.$on('geteditwids', (e) => {
			this.editpushdata = e.data
			this.echartsgird = false;
			this.getDefaultstyle(Number(this.setscrStyle.width) - Number(e.style.widthSize), Number(this.setscrStyle.height) - Number(e.style.heightSize), e.style.widthSize, e.style.heightSize) //调取初始底屏方法		
		})
		//echarts画出宫格
		var that = this;
		//获取widgets
		//		this.getwidgets();
		var serializeWidgetMap = function(item) {
			$.each(that.pushdata, function(value, key) {
				if(item.length) {
					if($(item[0].el[0]).attr('data-uid') == key.Uid) {
						key.x = item[0].x;
						key.y = item[0].y;
						key.height = item[0].height.toString();
						key.width = item[0].width.toString();
						key.Uid = $(item[0].el).attr('data-uid');
						key.isScroll = $(item[0].el).attr('data-gs-isScroll');
						key.name = $(item[0].el).attr('data-name');
						that.setattribute = key;
					}
				} else {
					return;
				}
			});
		};
		$('.grid-stack').on('change', (event, item) => {
			$('.grid-stack-item').css({
				"border": "none",
			});
			if(item.length) {
				let el = $(item[0].el[0]);
				el.css({
					"border": "1px solid #BFBFBF",
					"z-index": JSON.parse(el.attr('data-all')).Zindex
				});
			} else { //逻辑
				that.currentDom.css({
					"border": "1px solid #BFBFBF",
					"z-index": JSON.parse(that.currentDom.attr('data-all')).Zindex
				});
			}
			serializeWidgetMap(item);
			this.setscreen = false;
		});

		$('.grid-stack').on('click', '.grid-stack-item', function() {
			that.setscreen = false;
			let currentdom = $(this);
			that.currentDom = $(this);
			$('.grid-stack-item').css({
				"border": "none",
			});
			currentdom.css({
				"border": "1px solid #BFBFBF",
			});
			//点击事件触发右边属性
			$.each(that.pushdata, function(value, key) {
				if(currentdom.attr('data-uid') == key.Uid) {
					key.x = parseInt(currentdom.attr('data-gs-x'));
					key.y = parseInt(currentdom.attr('data-gs-y'));
					key.height = currentdom.attr('data-gs-height');
					key.width = currentdom.attr('data-gs-width');
					key.Uid = currentdom.attr('data-uid');
					key.isScroll = parseInt(currentdom.attr('data-gs-isScroll'));
					if(!(key.isScroll || key.isPoster)) {

					}
					that.setattribute = key;
				}
			});
		})
		//mouseup记录当前操作dom--底屏
		$('.grid-stack').on('mouseup', '.grid-stack-item', function() {
			that.currentDom = {};
			that.setscreen = false;
			that.currentDom = $(this);
		})
	},
	methods: { //方法
		getUsermsg() { //获取用户
			let userMsg = JSON.parse(sessionStorage.getItem('userMsg'));
			this.uType = userMsg.userType;
			let token = sessionStorage.getItem('Token');
			this.uploadToken = {
				Authorization: token
			};
		},
		getWidgetsmeun() {
			let uType = JSON.parse(sessionStorage.getItem('userMsg')).userType;
			if(uType == 0 || uType == 2) {
				uType = 0;
			} else {
				uType = 1;
			}

			let data = {
				params: {
					type: uType,
					pageSize: 9999999,
					channels: this.channels,
					channelnum: this.channelnum
				}
			}
			axios.get('/system/findWidgetsPullList', data)
				.then((res) => {
					this.meundata = res.data.data.list;
				})
				.catch(err => {
					console.log(err);
				});
		},
		screenSet() {
			this.setscreen = true;
		},
		getDefaultstyle(w, h, wp, hp) { //绘制底屏宫格 初始化dom屏宽高-->参数依次为 宽 高 、行列比
			setTimeout(() => {
				this.echartsgird = true;
				this.setStyle();
				//初始化宫格
				$('.grid-stack').gridstack(this.options);
				this.$nextTick(() => {
					this.getgrids(this.$refs.screenon, w, w / wp, h, h / hp);
					this.getupdatedata();
					this.pushdata = this.editpushdata;
					this.getwidgets();
				})
			}, 500)
			w = w - wp - 1;
			h = h - hp - 1;
			this.defaultStyle = {
				width: w + 'px',
				height: h + 'px !important',
				'margin-left': -w / 2 + 'px'
			}
			//初始化底屏options的格子高以及分的行列
			this.options.cell_height = h / hp;
			this.options.height = hp;
			this.options.width = wp;
		},
		setStyle() { //获取底屏样式
			this.less.render(`@flag:${this.options.width};
					.loop( @count,@i:@flag )when( @count >0) {
					    .grid-stack-item[data-gs-width= "@{count}"] {
					         width: (@count * 100% / @i); 
					    }
					    .grid-stack-item[data-gs-x= "@{count}"] {
					         left: (@count * 100% / @i); 
					    }
					    .grid-stack-item[data-gs-min-width= "@{count}"] {
					         width: (@count * 100% / @i); 
					    }
					    .grid-stack-item[data-gs-max-width= "@{count}"] {
					         width: (@count * 100% / @i); 
					    }    
					    .loop((@count - 1));
					}
					
					.grid-stack {
					    .loop(@flag);
					}`, function(e, output) {
				var doc = document;
				var style = doc.createElement("style");
				style.setAttribute("type", "text/css");
				if(style.styleSheet) { // IE  
					style.styleSheet.cssText = output.css;
				} else { // w3c  
					var cssText = doc.createTextNode(output.css);
					style.appendChild(cssText);
				}

				var heads = doc.getElementsByTagName("head");
				if(heads.length)
					heads[0].appendChild(style);
				else
					doc.documentElement.appendChild(style);
			});
		},
		clearWidget() { //清空widget
			let dom = this.currentDom;
			if(dom[0] != undefined) {
				$('.grid-stack').data('gridstack').remove_widget(dom);
				this.currentDom = {};
				this.setattribute = {};
				this.getupdatedata();
			} else {
				this.$message({
					message: '请先选中要删除的widget！',
					type: 'warning'
				});
			}

		},
		saveDate() { //保存数据	
			store.state.widgetClick++;
			this.saveType = "0";

		},
		saveDateClick() {
			for(let i = 0; i < this.pushdata.length; i++) {
				if(this.pushdata[i].isScroll) {
					this.pushdata[i].widgets = this.scrollPushdata
				}
			}
			if(!this.setFormData.id) {
				this.setFormData.id = ''
			}
			this.setFormData.Uid = new Date().getTime().toString();
			this.setFormData.widthSize = parseInt(this.setFormData.widthSize);
			this.setFormData.heightSize = parseInt(this.setFormData.heightSize);
			let data = {
				widgetjon: JSON.stringify(this.setFormData),
				groupjson: JSON.stringify(this.pushdata)
			}
			axios.post('/system/saveGroupWidget', data)
				.then((res) => {
					if(res.data.data != '系统异常') {
						this.setFormData.id = res.data.data
						this.$message({
							type: 'success',
							message: '保存成功!'
						});
						this.getWidgetsmeun();
					} else {
						this.$message({
							type: 'error',
							message: res.data.data
						});
					}
				})
				.catch(err => {
					console.log(err);
				});
		},
		saveDatecp() {
			store.state.widgetClick++;
			this.saveType = "1"
		},
		savedata() {
			for(let i = 0; i < this.pushdata.length; i++) {
				if(this.pushdata[i].isScroll) {
					this.pushdata[i].widgets = this.scrollPushdata
				}
			}
			if(!this.setFormData.id) {
				this.setFormData.id = ''
			}
			this.setFormData.Uid = new Date().getTime().toString();
			this.setFormData.widthSize = parseInt(this.setFormData.widthSize);
			this.setFormData.heightSize = parseInt(this.setFormData.heightSize);
			let data = {
				widgetjon: JSON.stringify(this.setFormData),
				groupjson: JSON.stringify(this.pushdata)
			}
			axios.post('/system/saveGroupWidget', data)
				.then((res) => {
					if(res.data.data != '系统异常') {
						this.setFormData.id = res.data.data
						this.$message({
							type: 'success',
							message: '保存成功!'
						});
						this.$router.push({
							path: '/diywidget/index'
						})
					}
				})
				.catch(err => {
					console.log(err);
				});
		},
		quit() {
			this.$router.push({
				path: '/diywidget/index'
			})
		},
		getmaxnum(arr) {
			let newselmax = [];
			//寻找最大值
			for(let i in arr) {
				newselmax.push(arr[i].Zindex)
			}
			if(newselmax.length > 0) {
				this.countZindex = Math.max.apply(null, newselmax) + 1;
			}
		},
		addWidget(item, index) { //添加widget
			this.countZindex++;
			let that = this;
			//拼接后台给的二次数据
			/*二次请求*/
			let data = {
				params: {
					widgetId: item.id
				}
			}
			axios.get('/system/getGoupWidgetById', data)
				.then((res) => {
					let setting = JSON.parse(res.data.data);
					this.setattribute = setting;

					//拿到二次数据进行拼接到setting里					
					//添加到底屏
					this.getupdatedata();
					this.getmaxnum(this.pushdata);
					this.pushdata.push(Object.assign({}, setting, {
						'Uid': new Date().getTime().toString(),
						'codeId': item.codeId,
						'id': item.id,
						'type': item.type,
						'Zindex': this.countZindex
						//						'auto_position': true //开启添加随机位置
					}));
					this.getwidgets();
					//如何解决底屏初始添加未记录位置的bug  important
				})
				.catch(err => {
					console.log(err);
				});

		},
		getupdatedata() { //获取更新数据
			var that = this;
			this.pushdata = _.map($('.grid-stack > .grid-stack-item:visible'), function(el) {
				var node = $(el).data('_gridstack_node');
				var Uid = $(el).attr('data-uid');
				var strIss = $(el).attr('data-gs-isScroll');
				return {
					Uid: Uid,
					x: parseInt(node.x),
					y: parseInt(node.y),
					width: node.width.toString(),
					height: node.height.toString(),
					name: $(el).attr('data-name'),
					isScroll: strIss ? 1 : 0,
					setting: JSON.parse($(el).attr('data-all')).setting,
					backgroud: JSON.parse($(el).attr('data-all')).backgroud,
					category: JSON.parse($(el).attr('data-all')).category,
					description: JSON.parse($(el).attr('data-all')).description,
					file: JSON.parse($(el).attr('data-all')).file,
					codeId: JSON.parse($(el).attr('data-all')).codeId,
					id: JSON.parse($(el).attr('data-all')).id,
					type: parseInt(JSON.parse($(el).attr('data-all')).type),
					Zindex: JSON.parse($(el).attr('data-all')).Zindex
				};
			});
		},
		getwidgets() { //获取Widget		
			var that = this;
			var t = {};
			t.serialized_data = this.pushdata;
			t.grid = $('.grid-stack').data('gridstack');
			t.load_grid = function() {
				$('.grid-stack').data('gridstack').remove_all();
				//				t.grid._update_styles()		
				var items = GridStackUI.Utils.sort(t.serialized_data);
				_.each(items, function(node) {
					var domstr = '<div style="z-index :' + node.Zindex + '"><div class="grid-stack-item-content grid-stack-item-content-back" style="background:url(' + that.imgbaseUrl + node.file[node.backgroud] + ') no-repeat center;background-size: 100% 100%;"></div></div>';
					t.grid.add_widget($(domstr), node.x, node.y, node.width, node.height, undefined, node);
				}, t);
			}.bind(t);
			t.load_grid();
			//保存发送值
		},
		getgrids(dom, xmax, xscale, ymax, yscale) { //绘制底屏宫格
			let myChart = this.$echarts.init(dom);
			var options = {
				title: {
					//text: 'Click to Add Points'
				},
				tooltip: {},
				grid: {
					left: '1',
					right: '1',
					bottom: '1',
					top: '1',
					containLabel: false
				},
				xAxis: {
					min: 0,
					max: xmax,
					type: 'value',
					interval: xscale,
					axisTick: {
						show: false
					},
					axisLabel: {
						show: false
					},
					axisLine: {
						onZero: false,
						show: false
					}
				},
				yAxis: {
					min: 0,
					max: ymax,
					type: 'value',
					interval: yscale,
					axisTick: {
						show: false
					},
					axisLabel: {
						show: false
					},
					axisLine: {
						onZero: false,
						show: false

					}
				}
			};
			myChart.setOption(options)
		},
		//widget拿过来
		handleAvatarSuccess(res, file) { //上传编辑器中的图片
			let that = this;
			this.getimgurl(res, URL.createObjectURL(file.raw));
			let picnameDot = new Date().getTime() + file.name.slice(file.name.lastIndexOf('.') - 2, file.name.length);
			let picnameImg = new Date().getTime() + file.name.slice(file.name.lastIndexOf('.'), file.name.length);

			if(that.setattribute.setting[this.currentindex].default['nine-path']) {
				delete that.setattribute.file[that.setattribute.setting[this.currentindex].default['nine-path']]
				this.isNineImg("nine-path", file, res)
			} else {
				delete that.setattribute.file[that.setattribute.setting[this.currentindex].default['image']]
				this.isNineImg("image", file, res)
			}
		},
		handleAvatarSuccessText(res, file) { //上传编辑器中文字类型中的图片
			let that = this;
			this.getimgurl(res, URL.createObjectURL(file.raw));
			let picnameDot = new Date().getTime() + file.name.slice(file.name.lastIndexOf('.') - 2, file.name.length);
			let picnameImg = new Date().getTime() + file.name.slice(file.name.lastIndexOf('.'), file.name.length);

			if(that.widegetData.setting[this.currentindex].default.background) {
				if(that.widegetData.setting[this.currentindex].default.background['nine-path']) {
					delete that.setattribute.file[that.setattribute.setting[this.currentindex].default.background['nine-path']]
					this.isNineImg("nine-pathText", file, res)
				} else {
					delete that.setattribute.file[that.setattribute.setting[this.currentindex].default.background['image']]
					this.isNineImg("imageText", file, res)
				}
			}
		},
		isNineImg(value, file, res) { //给widgetData修改图片
			let picnameDot = new Date().getTime() + file.name.slice(file.name.lastIndexOf('.') - 2, file.name.length);
			let picnameImg = new Date().getTime() + file.name.slice(file.name.lastIndexOf('.'), file.name.length);
			if(value == "nine-path") { //点九图
				if(picnameDot.indexOf(".9") > 0) {
					this.setattribute.setting[this.currentindex].default['nine-path'] = picnameDot;
					this.setattribute.file[picnameDot] = res;
				} else {
					this.setattribute.setting[this.currentindex].default['nine-path'] = picnameImg;
					this.setattribute.file[picnameImg] = res;
				}
			} else if(value == "image") { //image类型
				if(picnameDot.indexOf(".9") > 0) {
					this.setattribute.setting[this.currentindex].default['image'] = picnameDot;
					this.setattribute.file[picnameDot] = res;
				} else {
					this.setattribute.setting[this.currentindex].default['image'] = picnameImg;
					this.setattribute.file[picnameImg] = res;
				}
			}
			if(value == "backgroud") { //封面图
				if(picnameDot.indexOf(".9") > 0) {
					this.setattribute.backgroud = picnameDot;
					this.setattribute.file[this.setattribute.backgroud] = res;
				} else {
					this.setattribute.backgroud = picnameImg;
					this.setattribute.file[this.setattribute.backgroud] = res;
				}
			}
			if(value == "nine-pathText") {
				if(picnameDot.indexOf(".9") > 0) {
					this.setattribute.setting[this.currentindex].default.background['nine-path'] = picnameDot;
					this.setattribute.file[picnameDot] = res;
				} else {
					this.setattribute.setting[this.currentindex].default.background['nine-path'] = picnameImg;
					this.setattribute.file[picnameImg] = res;
				}
			}
			if(value == "imageText") {
				if(picnameDot.indexOf(".9") > 0) {
					this.setattribute.setting[this.currentindex].default.background['image'] = picnameDot;
					this.setattribute.file[picnameDot] = res;
				} else {
					this.setattribute.setting[this.currentindex].default.background['image'] = picnameImg;
					this.setattribute.file[picnameImg] = res;
				}
			}

		},
		beforeAvatarUpload(file, value) {
			const isJPG = file.type === 'image/jpeg';
			const isPNG = file.type === 'image/png';
			if(!isJPG && !isPNG) {
				this.$message.error('上传封面图片只能是 JPG、PNG 格式!');
			}
			return isJPG || isPNG;
		},
		handleRemove(file, fileList) {},
		deleteFile() {
			this.deleteBtn = true;
		},
		getimgurl(res, url) { //给数据里暂存字段，方便取
			this.setattribute.setting[this.currentindex].editorImg = res;
			var that = this;
			for(let i = 0; i < this.pushdata.length; i++) { //找到底屏的数据置换
				if(this.setattribute.x == this.pushdata[i].x && this.setattribute.y == this.pushdata[i].y) {
					if(this.pushdata[i].file[this.setattribute.setting[this.currentindex].default['nine-path']]) {
						this.pushdata[i].file[this.setattribute.setting[this.currentindex].default['nine-path']] = res;
					}
					if(this.pushdata[i].file[this.setattribute.setting[this.currentindex].default['image']]) {
						this.pushdata[i].file[this.setattribute.setting[this.currentindex].default['image']] = res;
					}
					_.map($('.grid-stack > .grid-stack-item:visible'), function(el) { //更新dom属性  可能还需要添加
						if(that.pushdata[i].Uid == $(el).attr('data-uid')) {
							$(el).attr('data-all', JSON.stringify(that.pushdata[i]))
						}
					});

				}
			}
			//找到滚动屏的数据置换
			this.setattribute.setting[this.currentindex].backupSrc = url;
		},
		uploadClick(item, index) {
			this.currentindex = index;
		},
		changes() {
			let uType = JSON.parse(sessionStorage.getItem('userMsg')).userType;
			if(uType == 0 || uType == 2) {
				uType = 0;
			} else {
				uType = 1;
			}
			let data = {
				params: {
					category: this.widgetCategory,
					type: uType, //管理员
					pageSize: 9999999,
					version: this.version
				}
			};
			axios.get('/system/findWidgetsPullList', data)
				.then((res) => {
					this.meundata = res.data.data.list;
				})
				.catch(err => {
					console.log(err);
				});

		},
		widgetCategory1() {
			axios.get('/system/findWidgetCategory')
				.then(res => {
					this.widgetCategoryList = res.data.data.list;
				})
				.catch(err => {
					console.log(err)
				})
		}

	},
	watch: { //监听
		$route(to, from) { // 对路由变化作出响应...

		},
		widgetWidth() {
			//			this.getDefaultstyle(this.setscrStyle.width, this.setscrStyle.height, this.widgetWidth, this.widgetHidth)
		},
		widgetHidth() {
			//			this.getDefaultstyle(this.setscrStyle.width, this.setscrStyle.height, this.widgetWidth, this.widgetHidth) //调取初始底屏方法
		},
		'widgetValid' () {
			if(store.state.widgetValid) {
				if(this.saveType == "1") {
					this.savedata()
				} else {
					this.saveDateClick();
				}
			}
		},

	},
	computed: {
		widgetValid() {
			return store.state.widgetClick
		},
	}
}