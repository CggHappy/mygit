<script src="../../../../../submitCode/lanucher-page/src/components/appMge/index.js"></script>
<template>
    <div class="Channel">
        <div class="all_contain">
            <div v-if="addBtn">
                <div class="channelTop">
                    <p class="channelTopTitle">渠道管理</p>
                </div>
                <div class="addTip">
                    <div class="tipMain">
                        <p class="tipTitle">请添加渠道后，再对渠道权限进行管理</p>
                        <p class="addBtn">
                            <el-button type="primary" icon="el-icon-plus" @click="addChannel">添加</el-button>
                        </p>
                    </div>
                </div>
            </div>
            <div class="channelData" v-if="dataBtn">
                <div class="channelTop">
                    <p class="channelTopTitle">渠道管理</p>
                    <p class="channelTopBtn" v-if="deleBtnIS">
                        <button type="button" class="el-button el-button--primary btnSearch btnBox"
                                style="background:#84A1E5" @click="channelEdit">编辑
                        </button>
                    </p>
                    <div class="saveBox">
                        <el-button type="primary" @click="addChannel" style="margin-right: 13px" class="greenbox"
                                   v-if="addFlag">添加渠道
                        </el-button>
                        <div v-if="editFlag">
                            <button type="button" class="el-button el-button--primary btnSearch btnBox"
                                    style="background:#84A1E5" @click="channelSave" :loading="loadingB">保存
                            </button>
                            <button type="button" class="el-button el-button--primary btnSearch btnBox"
                                    style="background:#84A1E5" @click="channelCancel">取消
                            </button>
                        </div>

                    </div>
                </div>
                <div class="channelTab">
                    <div class="channeTable">
                        <el-table :data="channelTabData" style="width: 100%" v-loading='pageLoad'
                                  element-loading-text="数据加载中...">
                            <el-table-column label="渠道">
                                <template slot-scope="scope">
                                    <p class="channelImg"><img :src="imgbaseUrl + scope.row.logo"
                                                               style="width: 100%;height: 100%"/></p>
                                    <p class="channelName">{{scope.row.name}}</p>
                                </template>
                            </el-table-column>
                            <el-table-column prop="" label="主题管理" v-if="themeManage? true: false">
                                <template slot-scope="scope">
                                    <el-dropdown :hide-on-click="false" trigger="click" @command="handleCommand">
                                        <el-button class="selectAuth">
                                            <span class="selsctSpan"></span>
                                            <i class="el-icon-caret-bottom el-icon--right"></i>
                                        </el-button>
                                        <el-dropdown-menu slot="dropdown">
                                            <div v-for="item in scope.row.themeManage" class="dropdownAuth">
                                                <el-dropdown-item :command="item" :disabled="btnsDisabled"
                                                                  style="display: flex;justify-content: space-between">
                                                    <span>{{ item.label }}</span>
                                                    <span v-if="deleBtnIS">
                                                        <i class="el-icon-check " v-if="item.checked?true:false"
                                                           style="color: rgb(103, 194, 58);"></i>
                                                        <i class="el-icon-close " v-if="item.checked?false:true"
                                                           style="color: red;"></i>
                                                    </span>
                                                    <span v-if="!deleBtnIS">
                                                        <i class="el-icon-check " v-if="item.checked?true:false" style="color: rgb(103, 194, 58);border: 1px solid #ccc;border-radius: 4px;
                                                    padding: 2px;"></i>
                                                        <i class="el-icon-close " v-if="item.checked?false:true" style="color: red;border: 1px solid #ccc;border-radius: 4px;
                                                    padding: 2px;"></i>
                                                    </span>
                                                </el-dropdown-item>
                                            </div>
                                        </el-dropdown-menu>
                                    </el-dropdown>
                                </template>
                            </el-table-column>
                            <el-table-column prop="" label="应用管理" v-if="applicationManage? true: false">
                                <template slot-scope="scope">
                                    <el-dropdown :hide-on-click="false" trigger="click" @command="handleCommand">
                                        <el-button class="selectAuth">
                                            <span class="selsctSpan"></span>
                                            <i class="el-icon-caret-bottom el-icon--right"></i>
                                        </el-button>
                                        <el-dropdown-menu slot="dropdown">
                                            <div v-for="item in scope.row.applicationManage" class="dropdownAuth">
                                                <el-dropdown-item :command="item" :disabled="btnsDisabled"
                                                                  style="display: flex;justify-content: space-between">
                                                    <span>{{ item.label }}</span>
                                                    <span v-if="deleBtnIS">
                                                        <i class="el-icon-check " v-if="item.checked?true:false"
                                                           style="color: rgb(103, 194, 58);"></i>
                                                        <i class="el-icon-close " v-if="item.checked?false:true"
                                                           style="color: red;"></i>
                                                    </span>
                                                    <span v-if="!deleBtnIS">
                                                        <i class="el-icon-check " v-if="item.checked?true:false" style="color: rgb(103, 194, 58);border: 1px solid #ccc;border-radius: 4px;
                                                    padding: 2px;"></i>
                                                        <i class="el-icon-close " v-if="item.checked?false:true" style="color: red;border: 1px solid #ccc;border-radius: 4px;
                                                    padding: 2px;"></i>
                                                    </span>
                                                </el-dropdown-item>
                                            </div>
                                        </el-dropdown-menu>
                                    </el-dropdown>
                                </template>
                            </el-table-column>
                            <el-table-column prop="" label="widget管理" v-if="widgetManage? true: false">
                                <template slot-scope="scope">
                                    <el-dropdown :hide-on-click="false" trigger="click" @command="handleCommand">
                                        <el-button class="selectAuth">
                                            <span class="selsctSpan"></span>
                                            <i class="el-icon-caret-bottom el-icon--right"></i>
                                        </el-button>
                                        <el-dropdown-menu slot="dropdown">
                                            <div v-for="item in scope.row.widgetManage" class="dropdownAuth">
                                                <el-dropdown-item :command="item" :disabled="btnsDisabled"
                                                                  style="display: flex;justify-content: space-between">
                                                    <span>{{ item.label }}</span>
                                                    <span v-if="deleBtnIS">
                                                        <i class="el-icon-check " v-if="item.checked?true:false"
                                                           style="color: rgb(103, 194, 58);"></i>
                                                        <i class="el-icon-close " v-if="item.checked?false:true"
                                                           style="color: red;"></i>
                                                    </span>
                                                    <span v-if="!deleBtnIS">
                                                        <i class="el-icon-check " v-if="item.checked?true:false" style="color: rgb(103, 194, 58);border: 1px solid #ccc;border-radius: 4px;
                                                    padding: 2px;"></i>
                                                        <i class="el-icon-close " v-if="item.checked?false:true" style="color: red;border: 1px solid #ccc;border-radius: 4px;
                                                    padding: 2px;"></i>
                                                    </span>
                                                </el-dropdown-item>
                                            </div>
                                        </el-dropdown-menu>
                                    </el-dropdown>
                                </template>
                            </el-table-column>
                            <el-table-column prop="" label="渠道管理" v-if="channelManage? true:false">
                                <template slot-scope="scope">
                                    <el-dropdown :hide-on-click="false" trigger="click" @command="handleCommand">
                                        <el-button class="selectAuth">
                                            <span class="selsctSpan"></span>
                                            <i class="el-icon-caret-bottom el-icon--right"></i>
                                        </el-button>
                                        <el-dropdown-menu slot="dropdown">
                                            <div v-for="item in scope.row.channelManage" class="dropdownAuth">
                                                <el-dropdown-item :command="item" :disabled="btnsDisabled"
                                                                  style="display: flex;justify-content: space-between">
                                                    <span>{{ item.label }}</span>
                                                    <span v-if="deleBtnIS">
                                                        <i class="el-icon-check " v-if="item.checked?true:false"
                                                           style="color: rgb(103, 194, 58);"></i>
                                                        <i class="el-icon-close " v-if="item.checked?false:true"
                                                           style="color: red;"></i>
                                                    </span>
                                                    <span v-if="!deleBtnIS">
                                                        <i class="el-icon-check " v-if="item.checked?true:false" style="color: rgb(103, 194, 58);border: 1px solid #ccc;border-radius: 4px;
                                                    padding: 2px;"></i>
                                                        <i class="el-icon-close " v-if="item.checked?false:true" style="color: red;border: 1px solid #ccc;border-radius: 4px;
                                                    padding: 2px;"></i>
                                                    </span>
                                                </el-dropdown-item>
                                            </div>
                                        </el-dropdown-menu>
                                    </el-dropdown>
                                </template>
                            </el-table-column>
                            <el-table-column prop="" label="账号授权" v-if="accountMange? true: false">
                                <template slot-scope="scope">
                                    <el-dropdown :hide-on-click="false" trigger="click" @command="handleCommand">
                                        <el-button class="selectAuth">
                                            <span class="selsctSpan"></span>
                                            <i class="el-icon-caret-bottom el-icon--right"></i>
                                        </el-button>
                                        <el-dropdown-menu slot="dropdown">
                                            <div v-for="item in scope.row.accountMange" class="dropdownAuth">
                                                <el-dropdown-item :command="item" :disabled="btnsDisabled"
                                                                  style="display: flex;justify-content: space-between">
                                                    <span>{{ item.label }}</span>
                                                    <span v-if="deleBtnIS">
                                                        <i class="el-icon-check " v-if="item.checked?true:false"
                                                           style="color: rgb(103, 194, 58);"></i>
                                                        <i class="el-icon-close " v-if="item.checked?false:true"
                                                           style="color: red;"></i>
                                                    </span>
                                                    <span v-if="!deleBtnIS">
                                                        <i class="el-icon-check " v-if="item.checked?true:false" style="color: rgb(103, 194, 58);border: 1px solid #ccc;border-radius: 4px;
                                                    padding: 2px;"></i>
                                                        <i class="el-icon-close " v-if="item.checked?false:true" style="color: red;border: 1px solid #ccc;border-radius: 4px;
                                                    padding: 2px;"></i>
                                                    </span>
                                                </el-dropdown-item>
                                            </div>
                                        </el-dropdown-menu>
                                    </el-dropdown>
                                </template>
                            </el-table-column>
                            <el-table-column prop="" label="统计分析" v-if="statisticalManage? true: false ">
                                <template slot-scope="scope">
                                    <el-dropdown :hide-on-click="false" trigger="click" @command="handleCommand">
                                        <el-button class="selectAuth">
                                            <span class="selsctSpan"></span>
                                            <i class="el-icon-caret-bottom el-icon--right"></i>
                                        </el-button>
                                        <el-dropdown-menu slot="dropdown">
                                            <div v-for="item in scope.row.statisticalManage" class="dropdownAuth">
                                                <el-dropdown-item :command="item" :disabled="btnsDisabled"
                                                                  style="display: flex;justify-content: space-between">
                                                    <span>{{ item.label }}</span>
                                                    <span v-if="deleBtnIS">
                                                        <i class="el-icon-check " v-if="item.checked?true:false"
                                                           style="color: rgb(103, 194, 58);"></i>
                                                        <i class="el-icon-close " v-if="item.checked?false:true"
                                                           style="color: red;"></i>
                                                    </span>
                                                    <span v-if="!deleBtnIS">
                                                        <i class="el-icon-check " v-if="item.checked?true:false" style="color: rgb(103, 194, 58);border: 1px solid #ccc;border-radius: 4px;
                                                    padding: 2px;"></i>
                                                        <i class="el-icon-close " v-if="item.checked?false:true" style="color: red;border: 1px solid #ccc;border-radius: 4px;
                                                    padding: 2px;"></i>
                                                    </span>
                                                </el-dropdown-item>
                                            </div>
                                        </el-dropdown-menu>
                                    </el-dropdown>
                                </template>
                            </el-table-column>
                            <el-table-column prop="" label="运维日志" v-if="operationLog? true: false">
                                <template slot-scope="scope">
                                    <el-dropdown :hide-on-click="false" trigger="click" @command="handleCommand">
                                        <el-button class="selectAuth">
                                            <span class="selsctSpan"></span>
                                            <i class="el-icon-caret-bottom el-icon--right"></i>
                                        </el-button>
                                        <el-dropdown-menu slot="dropdown">
                                            <div v-for="item in scope.row.operationLog" class="dropdownAuth">
                                                <el-dropdown-item :command="item" :disabled="btnsDisabled"
                                                                  style="display: flex;justify-content: space-between">
                                                    <span>{{ item.label }}</span>
                                                    <span v-if="deleBtnIS">
                                                        <i class="el-icon-check " v-if="item.checked?true:false"
                                                           style="color: rgb(103, 194, 58);margin-left: 5px;"></i>
                                                        <i class="el-icon-close " v-if="item.checked?false:true"
                                                           style="color: red;margin-left: 5px;"></i>
                                                    </span>
                                                    <span v-if="!deleBtnIS">
                                                        <i class="el-icon-check " v-if="item.checked?true:false" style="color: rgb(103, 194, 58);border: 1px solid #ccc;margin-left: 5px;border-radius: 4px;
                                                    padding: 2px;"></i>
                                                        <i class="el-icon-close " v-if="item.checked?false:true" style="color: red;border: 1px solid #ccc;margin-left: 5px;border-radius: 4px;
                                                    padding: 2px;"></i>
                                                    </span>
                                                </el-dropdown-item>
                                            </div>
                                        </el-dropdown-menu>
                                    </el-dropdown>
                                </template>
                            </el-table-column>
                            <el-table-column prop="" label="操作" v-if="moreFlag || deleteFlag">
                                <template slot-scope="scope">
                                    <el-button size="mini" class='greenBox' @click="getMore(scope.$index, scope.row)"
                                               v-if="moreFlag">更多
                                    </el-button>
                                    <el-button size="mini" type="danger" @click="deleteRow(scope.$index,scope.row)"
                                               :disabled="btnsDisabled" v-if="deleteFlag">删除
                                    </el-button>
                                </template>
                            </el-table-column>
                        </el-table>
                        <div class="tableFooter" v-if="isShowPagination">
                            <div class="widgetTabRecord">
                                <span>共<span class="spantotal">{{totalNum}}</span>条数据，每页<span class="spansize">10</span>条</span>
                            </div>
                            <div class="widgetTabFoot">
                                <div class="widgetPage">
                                    <el-pagination
                                            @size-change="handleSizeChange"
                                            @current-change="handleCurrentChange"
                                            :current-page="pageNum"
                                            :page-size="pageSize"
                                            layout="prev, pager, next, jumper"
                                            :total="totalNum">
                                    </el-pagination>
                                </div>
                                <button type="button" class="el-button el-button--primary btnSearch btn_s">确定</button>
                            </div>
                        </div>
                        <div class="bg" :style='{top:top+"px"}' v-if="boxIsshow">
                            保存后删除即生效,<a class="resizeDelete" href="javaScript:;" @click="resizeDelete">撤销删除</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

</template>
<script src="./index.js">
</script>
<style scoped="scoped" src="./index.less" lang="less">
</style>
