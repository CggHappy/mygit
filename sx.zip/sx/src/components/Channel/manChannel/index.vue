<template>
	<div class="manChannel">
		<div class="all_contain">
			<div class="manChannelTop">
				<el-breadcrumb separator-class="el-icon-arrow-right">
					<el-breadcrumb-item :to="{ path: '/channel/index' }">渠道管理</el-breadcrumb-item>
					<el-breadcrumb-item v-model="titleContainer">{{titleContainer}}</el-breadcrumb-item>
				</el-breadcrumb>
			</div>
			
			<el-form label-position="top" :model="ruleForm" :rules="rules" ref="ruleForm" label-width="100px" class="demo-ruleForm">
				<div class="manChannelMain">
					<el-form-item class='half50' label="渠道名称" prop="channelName">
						<el-input v-model="ruleForm.channelName"  placeholder="请输入渠道名称"></el-input>
					</el-form-item>
					<el-form-item class='half50' label="渠道ID" prop="channelId">
						<el-input v-model="ruleForm.channelId" disabled></el-input>
					</el-form-item>
					<el-form-item class='half50' label="渠道管理员账户" prop="channelAccount" style='clear: both;'>
            <el-autocomplete class="inline-input" v-model="ruleForm.channelAccount" :fetch-suggestions="querySearch" placeholder="请输入渠道管理员账户"
                             @select="handleSelect" style="width: 75%"
            ></el-autocomplete>
					</el-form-item>
					<el-form-item class='half50 logo' label="渠道LOGO" prop="channelLogo">
						<el-upload
						  class="avatar-uploader"
						  action="http://api.launcher.pactera-sln.club:8185/system/fileUpload"
                          :headers=uploadToken
						  :show-file-list="false"
						  :on-success="handleAvatarSuccess"
						  :before-upload="beforeAvatarUpload">
						  <img v-if="imageUrl" :src=" imgbaseUrl + imageUrl" class="avatar" style="width: 100%;height: 100%">
						  <i v-else class="el-icon-plus avatar-uploader-icon"></i>
						</el-upload>
					</el-form-item>
			
          <el-form-item class='authoryItme is-required' label="权限设置" prop="themStyle" >
            <div v-for="(jur,index) in jurisdictionList" :key="index" class="authory">
              <div class="authoryModel">
                <div class="authoryTop">{{jur.name}}</div>
                <div class="authoryCity">
                  <el-checkbox-group v-model="ruleForm.listPermissions" >
                    <el-checkbox v-for="item in jur.listPermissions" :label="item.id" :key="item.id" >{{item.name}}</el-checkbox>
                  </el-checkbox-group>
                </div>
              </div>
            </div>
          </el-form-item>

				</div>
        <el-form-item>
          <div class="footBtn">
            <el-button @click="resetForm('ruleForm')">取消</el-button>
            <el-button type="primary" @click="submitForm('ruleForm')" :loading="loadingB">保存</el-button>
          </div>
        </el-form-item>
			</el-form>
		</div>
	</div>
</template>
<script src="./index.js">
</script>
<style scoped="scoped" src="./index.less" lang="less">
</style>
