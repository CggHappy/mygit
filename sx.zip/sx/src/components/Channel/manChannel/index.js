import axios from "@/axios.js";
//import bus from "@/bus.js";
import "./manChannel.css";

export default {
    data() {
        var validateUser = (rule, value, callback) => {
            let valid = false;
            if (value == this.editUserName) {
                callback();
            }
            if (this.editFlag && this.listPermissions.length == 0) {
                valid = true;
                this.editFlag = false;
            } else {
                for (let i = 0; i < this.listPermissions.length; i++) {
                    if (this.listPermissions[i] == value) {
                        valid = true;
                        break
                    }
                }
            }
            if (valid) {
                callback()
            } else {
                callback(new Error('请选择正确的授权账号'))
            }
        };
        let checkedChannelName = (rule, value, callback) => {
            if (this.editFlag == true && this.channelName) {
                this.editFlag = false;
                callback();
            }
            if (value == this.channelName) {
                callback();
            }
            let data = {
                channelName: value
            };
            axios.post('auth/channel/checkRepeatChannel', data)
                .then(res => {
                    if (res.data.data == 0) {
                        callback();
                    }
                    callback(new Error('用户名已存在'));
                })
                .catch(err => {
                });
        };

        return {
            ruleForm: {
                channelName: '', //渠道名称
                channelId: '', //渠道ID
                channelAccount: '', //渠道管理员账户
                listPermissions: [],
            },
            rules: {
                channelName: [
                    {
                        required: true,
                        message: '请输入渠道名称',
                        trigger: 'blur'
                    },
                    {
                        pattern: /^(?!_)(?!.*?_$)[a-zA-Z0-9_\u4e00-\u9fa5]+$/,
                        message: '只能输入中文、英文、下划线、数字',
                        trigger: 'blur'
                    },
                    {
                        min: 1,
                        max: 15,
                        message: '长度小于15 个字符',
                        trigger: 'blur'
                    },
                    {
                        validator: checkedChannelName,
                        trigger: 'blur'
                    }
                ],
                channelId: [{
                    required: true,
                    message: '',
                    trigger: 'change'
                }],
                channelAccount: [{
                    required: true,
                    message: '账号不能为空',
                    trigger: 'blur'
                },
                    {
                        validator: validateUser,
                        trigger: 'change'
                    }
                ],

            },
            isIndeterminate: true,
            titleContainer: "",//判断显示编辑或新增
            imageUrl: '',
            jurisdictionList: [], //权限列表
            searchData: [],//下拉搜索的显示列表
            userId: '',  //账户管理员id
            listPermissions: [],
            loadingB: false,
            id: '', //渠道的唯一标识
            defaultLogo: 'group1/M00/00/13/wKgJElsEyiSAKsdOAAvea_OGt2M022.jpg',
            editFlag: false,
            uploadToken: {},//用户token
            channelName: '',//渠道名称保存
            editUserName: '',//回显的账号

        }
    },
    mounted() { //实例挂载之后
        this.routeIs();
        this.getLoadData();
        this.getUsermsg();
    },
    methods: { //方法
        //获取用户信息
        getUsermsg() {
            let userMsg = JSON.parse(sessionStorage.getItem('userMsg'));
            let token = sessionStorage.getItem('Token');
            this.uploadToken = {
                Authorization: token
            };
        },
        //加载列表
        getLoadData() {
            axios.get('auth/permissions/findPermissionsByUser')
                .then(res => {
                    this.jurisdictionList = res.data.data;
                })
                .catch(err => {
                })
        },
        //加载渠道id
        getChannelId() {
            axios.post('auth/channel/findChannelId')
                .then(res => {
                    this.ruleForm.channelId = res.data.data
                })
                .catch(err => {
                })
        },
        //下拉搜索
        querySearch(queryString, callback) {
            let searchData = this.searchData;
            let type = '';
            if (this.id == false) {
                type = 1;
            } else {
                type = 2
            }
            let data = {
                params: {
                    userName: this.ruleForm.channelAccount,
                    type: type,
                    channelId: this.id
                }
            };
            axios.get('auth/accountNumber/findUserByLike', data)
                .then(res => {
                    for (let i = 0; i < res.data.data.length; i++) {
                        res.data.data[i].value = res.data.data[i].userName;
                    }
                    this.searchData = res.data.data;
                    let results = queryString ? res.data.data.filter(this.createFilter(queryString)) : res.data.data;
                    let perArray = [];
                    for (let item of res.data.data) {
                        perArray.push(item.userName);
                    }
                    this.listPermissions = [...new Set(perArray)];
                    callback(results)
                })
                .catch(err => {
                })
        },
        createFilter(queryString) {
            return (restaurant) => {
                if (restaurant.str) return false;
                return (restaurant.value.indexOf(queryString) >= 0);
            };
        },
        handleSelect(item) {
            this.userId = item.id;
        },
        //保存按钮
        submitForm(formName) {
            this.$refs[formName].validate((valid) => {
                if (valid) {
                    if(this.ruleForm.listPermissions.length==0){
                        this.$message.error('权限未勾选');
                        return
                    }
                    this.loadingB = true;
                    let data = {
                        id: this.id,
                        name: this.ruleForm.channelName,
                        channelId: this.ruleForm.channelId,
                        logo: this.imageUrl,
                        userId: this.userId,
                        permissionids: (this.ruleForm.listPermissions).join(',')
                    };
                    axios.post('auth/channel/saveChannel', data)
                        .then(res => {
                            this.$message.success('保存信息成功');
                            this.resetForm(formName);
                            this.loadingB = false;
                        })
                        .catch(err => {
                            this.$message.error('保存信息失败');
                        })
                } else {
                    this.$message.error('信息未填写完整，请完善信息后，再做保存');
                    return false;
                }
            });
        },
        //判断编辑、添加状态切换
        routeIs() {
            let path = this.$route.path;
            if (path.indexOf("editchannel") > 1) {
                this.titleContainer = "编辑渠道";
                let data = {
                    id: sessionStorage.getItem('id'),
                };
                axios.post('auth/channel/findChannelById', data)
                    .then(res => {
                        this.editFlag = true;
                        this.editUserName = res.data.data.user.userName;
                        this.channelName = res.data.data.name;
                        this.imageUrl = res.data.data.logo;
                        this.id = res.data.data.id;
                        this.userId = res.data.data.userId;
                        this.ruleForm.channelName = res.data.data.name;
                        this.ruleForm.channelId = res.data.data.channelId;
                        this.ruleForm.channelAccount = res.data.data.user.userName;
                        for (let itemList of res.data.data.listPermissions) {
                            for (let item of itemList.listPermissions) {
                                if (item.chooseType == 1) {
                                    this.ruleForm.listPermissions.push(item.id)
                                }
                            }
                        }
                    })
                    .catch(err => {
                    })
            } else if (path.indexOf("addchannel")) {
                this.titleContainer = "添加渠道";
                this.getChannelId();
                this.imageUrl = this.defaultLogo;
            }
        },
        //取消
        resetForm(formName) {
            this.$refs[formName].resetFields();
            this.$router.push({
                path: "/channel/index"
            })
        },
        //上传成功
        handleAvatarSuccess(res, file) {
            this.imageUrl = res
        },
        //上传文件验证
        beforeAvatarUpload(file) {
            const isJPG = file.type === 'image/jpeg';
            const isPNG = file.type === 'image/png';
            const isLt2M = file.size / 1024 / 1024 < 2;
            if (!isJPG && !isPNG) {
                this.$message.error('上传图片只能是 JPG 格式或 PNG 格式!');
            }
            if (!isLt2M) {
                this.$message.error('上传图片大小不能超过 2MB!');
            }
            return (isPNG || isJPG) && isLt2M;
        },
    },
    watch: { //监听
        '$route'(to, from) { // 对路由变化作出响应...

        },
    },
    created() { //实例创建之后

    }
}
