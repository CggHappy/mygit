import axios from "@/axios.js";
//import bus from "@/bus.js";
import "./channel.css";

export default {
    data() {
        return {
            channelTabData: [],
            addBtn: false,//添加页面是否出来
            dataBtn: true,//数据页面是否显示
            channelMain: "-",
            deleBtnIS: false,//编辑按钮是否显示
            top: 48,
            boxIsshow: false,//删除弹层
            isShowPagination: false,//是否显示分页
            pageSize: 10,//每页显示数据条数
            totalNum: 0,//数据总条数
            pageNum: 1,//当前页
            btnsDisabled: true, //按钮禁止状态
            statisticalManage: null, //统计管理
            widgetManage: null, //widget管理
            themeManage: null, //主题管理
            applicationManage: null, //应用管理
            accountMange: null, //账号授权
            operationLog: null,//运维日志
            channelManage: null, //渠道管理
            powerData: {}, //6个权限列的数据
            loadingB: false,
            pageLoad: true,
            addFlag: false,//添加按钮显示
            deleteFlag: false,//删除按钮的显示
            moreFlag: false,//更多按钮显示
            editFlag: false,//保存取消按钮显示
            opationShow:false,//操作列显示

        }
    },
    mounted() { //实例挂载之后
        this.loadData();
        this.getUsermsg()
    },
    methods: { //方法
        //权限
        getUsermsg() {
            let userMsg = JSON.parse(sessionStorage.getItem('userMsg'));
            let list = [];
            for (let i = 0; i < userMsg.listPermissions.length; i++) {
                if (userMsg.listPermissions[i].name == '渠道管理') {
                    list = userMsg.listPermissions[i].listPermissions;
                }
            }
            for (let i in list) {
                switch (list[i].name) {
                    case "渠道列表":
                        break;
                    case "添加渠道":
                        this.addFlag = true;
                        break;
                    case "编辑渠道":
                        this.moreFlag = true;
                        break;
                    case "删除渠道":
                        this.deleteFlag = true;
                        break;
                    case "编辑渠道权限":
                        this.deleBtnIS = true;
                        break;
                }
            }
        },
        //获取数据
        loadData() {
            this.pageLoad = true;
            let data = {
                pageNum: this.pageNum,
                pageSize: 10
            };
            axios.post('auth/channel/findChannelList', data)
                .then(res => {
                    this.pageLoad = false;
                    this.channelTabData = [];
                    this.totalNum = res.data.data.total;
                    this.pageSize = res.data.data.pageSize;
                    let dataList = res.data.data.list;
                    let userItme = {};//单个渠道对象
                    let powerData = {};//权限列表
                    for (let i = 0; i < dataList.length; i++) {
                        userItme = {
                            id: dataList[i].id,
                            name: dataList[i].name,
                            logo: dataList[i].logo
                        };
                        powerData = dataList[i].listPermissions;
                        for (let j = 0; j < powerData.length; j++) {
                            if (powerData[j].name == '统计分析') {
                                this.statisticalManage = this.setTableItem(powerData[j].listPermissions, dataList[i].id);
                            }
                            if (powerData[j].name == 'widget管理') {
                                this.widgetManage = this.setTableItem(powerData[j].listPermissions, dataList[i].id);
                            }
                            if (powerData[j].name == '主题管理') {
                                this.themeManage = this.setTableItem(powerData[j].listPermissions, dataList[i].id);
                            }
                            if (powerData[j].name == '账号授权') {
                                this.accountMange = this.setTableItem(powerData[j].listPermissions, dataList[i].id)
                            }
                            if (powerData[j].name == '渠道管理') {
                                this.channelManage = this.setTableItem(powerData[j].listPermissions, dataList[i].id);
                            }
                            if (powerData[j].name == '应用管理') {
                                this.applicationManage = this.setTableItem(powerData[j].listPermissions, dataList[i].id);
                            }
                            if (powerData[j].name == '运维日志') {
                                this.operationLog = this.setTableItem(powerData[j].listPermissions, dataList[i].id);
                            }
                            userItme.statisticalManage = this.statisticalManage;
                            userItme.widgetManage = this.widgetManage;
                            userItme.themeManage = this.themeManage;
                            userItme.applicationManage = this.applicationManage;
                            userItme.accountMange = this.accountMange;
                            userItme.channelManage = this.channelManage;
                            userItme.operationLog = this.operationLog;
                        }
                        this.channelTabData.push(userItme)
                    }
                    this.isShow(this.addBtn, this.dataBtn);
                    if (this.channelTabData.length == 0) {
                        this.isShowPagination = false
                    } else {
                        this.isShowPagination = true
                    }
                })
                .catch(res => {
                })
        },
        //列表数据封装
        setTableItem(arr, userId) {
            let itemArr = [];
            for (var i = 0; i < arr.length; i++) {
                let item = {};
                if (arr[i].chooseType == '1') {
                    item.checked = true;
                } else {
                    item.checked = false;
                }
                item.userId = userId;
                item.id = arr[i].id;
                item.label = arr[i].name;
                itemArr.push(item);
            }
            return itemArr;
        },
        // 筛选ture的结果，返回id集合
        selecTrueData(powerObj) {
            let idList = [];
            for (let i = 0; i < powerObj.length; i++) {
                if (powerObj[i].checked == true) {
                    idList.push(powerObj[i].id)
                }
            }
            return idList.join();
        },
        //单个渠道封装成后台格式
        channel(channelItem) {
            let channel = {
                id: channelItem.id,
                permissions: []
            };
            if (channelItem.statisticalManage) {
                channel.permissions.push(this.selecTrueData(channelItem.statisticalManage))
            }
            if (channelItem.widgetManage) {
                channel.permissions.push(this.selecTrueData(channelItem.widgetManage))
            }
            if (channelItem.themeManage) {
                channel.permissions.push(this.selecTrueData(channelItem.themeManage))
            }
            if (channelItem.applicationManage) {
                channel.permissions.push(this.selecTrueData(channelItem.applicationManage))
            }
            if (channelItem.accountMange) {
                channel.permissions.push(this.selecTrueData(channelItem.accountMange))
            }
            if (channelItem.channelManage) {
                channel.permissions.push(this.selecTrueData(channelItem.channelManage))
            }
            if (channelItem.operationLog) {
                channel.permissions.push(this.selecTrueData(channelItem.operationLog))
            }
            let arryAll = channel.permissions;
            for (let i = 0; i < arryAll.length; i++) {
                if (arryAll[i] == '' || typeof(arryAll[i]) == "undefined") {
                    arryAll.splice(i, 1);
                    i = i - 1;
                }
            }
            if (arryAll.join(',').split(",") == '') {
                channel.permissions = []
            } else {
                channel.permissions = arryAll.join(',').split(",")
            }
            return channel;
        },
        //分页
        handleSizeChange(val) {},
        handleCurrentChange(val) {
            this.pageNum = val;
            this.loadData()
        },
        changeitem(item) {
            item.checked = !item.checked;
        },
        //改变下拉框中对勾状态
        handleCommand(command) {
            let item = command;
            if (this.deleBtnIS) {
                item.checked = item.checked;
            } else {
                item.checked = !item.checked;
            }
        },
        isShow(addBtn, dataBtn) {
            if (this.channelTabData.length == 0) {
                this.addBtn = true;
                this.dataBtn = false;
            } else {
                this.addBtn = false;
                this.dataBtn = true;
            }
        },
        //取消按钮
        channelCancel() {
            this.deleBtnIS = !this.deleBtnIS;
            this.btnsDisabled = !this.btnsDisabled;
            this.loadData();
            if(this.boxIsshow==true){
                this.boxIsshow=false;
            }else{
                this.boxIsshow=false;
            }
            this.isShowEdit();
        },
        //点击添加
        addChannel() {
            this.$router.push({
                path: "/channel/addchannel"
            })
        },
        //点击编辑
        channelEdit() {
            this.deleBtnIS = !this.deleBtnIS;
            this.btnsDisabled = !this.btnsDisabled;
            this.isShowEdit();
        },
        isShowEdit(){
            if(this.deleBtnIS==true){
                this.editFlag=false
            }else{
                this.editFlag=true
            }
        },
        //点击更多时跳转
        getMore(index, row) {
            this.$router.push({
                path: "/channel/editchannel"
            });
            sessionStorage.setItem('id', row.id)
        },
        //删除按钮
        deleteRow(index, row) {
            this.top = 48 + (96 * index);
            this.boxIsshow = !this.boxIsshow;
            sessionStorage.setItem('delId', row.id);
        },
        //撤销按钮
        resizeDelete() {
            this.boxIsshow = !this.boxIsshow;
        },
        //保存按钮
        channelSave() {
            this.loadingB = true;
            if (this.boxIsshow == true) {
                let data = {
                    id: sessionStorage.getItem('delId'),
                };
                axios.post('auth/channel/deleteChannel', data)
                    .then(res => {
                        this.$message.success('删除数据成功');
                        this.boxIsshow = false;
                        this.loadData();
                        this.loadingB = false
                    })
                    .catch(err => {
                        this.$message.error('删除数据失败')
                    })
            } else {
                let dataAll = [];
                for (let i = 0; i < this.channelTabData.length; i++) {
                    let item = this.channel(this.channelTabData[i]);
                    dataAll.push(item);
                }
                let data = {
                    channelList: JSON.stringify(dataAll)
                };
                axios.post('auth/channel/updateChannelList', data)
                    .then(res => {
                        this.$message.success('保存数据成功');
                        this.loadData();
                        this.loadingB = false
                    })
                    .catch(err => {
                        this.$message.error('保存数据失败');
                    })
            }
        },
    },
    watch: { //监听
        '$route'(to, from) { // 对路由变化作出响应...

        },
    },
    created() { //实例创建之后

    }
}
