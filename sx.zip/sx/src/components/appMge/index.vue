<template>
  <div class="appManage">
    <div class="all_contain">
      <div class="appManageList">
        <el-breadcrumb separator-class="el-icon-arrow-right">
          <el-breadcrumb-item :to="{ path: '/' }" class="appManageListTxt">应用管理</el-breadcrumb-item>
          <el-breadcrumb-item v-if="isShowAddAppListItem" class="appManageListTxtTow">应用列表</el-breadcrumb-item>
        </el-breadcrumb>
      </div>
      <div class="appManageChannel" v-if="ApplicationQuery">
        <div class="selectModel" v-if="userType==0 || userType==2 ">
          <label class="channel">渠道:</label>
          <el-select clearable class="selectOpation" v-model="channelId">
            <el-option v-for="item in channelOptions" :key="item.id" :label="item.name" :value="item.channelId">
            </el-option>
          </el-select>
        </div>
        <div class="appName">
          <el-input clearable v-model='keyWords' placeholder="请输入名称/ID"></el-input>
        </div>
        <div class="appSearch">
          <el-button type="primary" @click="searchData">查询</el-button>
        </div>
      </div>
      <div class="appManageBar">
        <div class="appManageBarTop">
          <span class="appManageBarTopTxt" v-if="!isShowLineTopTxt">应用分布TOP10<i class="isIcon">?</i></span>
        </div>
        <div id='topLine' class="appManageBartabel" :style="{width:'100%',height:'90%'}"></div>
      </div>
      <div class="appManageTabel">
        <div class="appManageTabelTop">
          <span class="tabelTopTxt">应用分布</span>
          <el-button type="primary" icon="el-icon-plus" class="add" @click="jumpAddApp" v-if="ApplicationAdd">添加</el-button>
        </div>
        <div class="appManageTabelData">
          <el-table :data="tableData" :span-method="objectSpanMethod" ref="multipleTable" class="tableHead" v-loading="loading" element-loading-text="拼命加载中">
            <el-table-column prop="channelId" label="渠道ID" width="180" v-if="userType===0" :index="indexMethod">
            </el-table-column>
            <el-table-column prop="channelName" label="渠道名称" v-if="userType===0">
            </el-table-column>
            <el-table-column label="所属应用">
              <template slot-scope="scope">
                <span @click="enterEdit(scope.row)" v-if="ApplicationModification">{{scope.row.name}}</span>
                <span v-if="!ApplicationModification">{{scope.row.name}}</span>
              </template>
            </el-table-column>
            <el-table-column prop="packageId" label="应用ID">
            </el-table-column>
            <el-table-column label="海报配置">
              <template slot-scope="scope">
                <span @click="jumpPoster(scope.$index,scope.row)" v-if="PostersConfiguration" :class="{'txtColor':scope.row.configed=='已配置'?true:false}">{{ scope.row.configed}}</span>
                <span v-if="!PostersConfiguration" :class="{'txtColor':scope.row.configed=='已配置'?true:false}">{{ scope.row.configed}}</span>
              </template>
            </el-table-column>
            <el-table-column label="海报有效期">
              <template slot-scope="scope">
                <span v-if="scope.row.startTime && scope.row.endTime" v-html="('从'+ scope.row.startTime+'<br/>'+'至'+scope.row.endTime) || '-'"></span>
                <span v-if="!(scope.row.startTime && scope.row.endTime)">-</span>
              </template>
            </el-table-column>
            <el-table-column prop="yesterdayStartCount" label="昨日启动次数">
            </el-table-column>
            <el-table-column prop="startCountRatio" label="启动次数占比">
            </el-table-column>
          </el-table>
          <div class="tableFooter" v-if="isShowPagination">
            <div class="widgetTabRecord">
              <span>共
                <span class="spantotal">{{totalNum}}</span>条数据，每页
                <span class="spansize">10</span>条</span>
            </div>
            <div class="widgetTabFoot">
              <div class="widgetPage">
                <el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange" :current-page="pageNum" :page-size="pageSize" layout="prev, pager, next, jumper" :total="totalNum">
                </el-pagination>
              </div>
              <button type="button" class="el-button el-button--primary btnSearch btn_s">确定</button>
            </div>
          </div>
        </div>
        <div class="btn">
          <el-button type="primary" class="bottomAddBtn" @click="jumpAddApp" v-if="tableData.length?false:true || ApplicationAdd">添加</el-button>
        </div>
      </div>
    </div>
  </div>
</template>
<script src="./index.js">
</script>
<style scoped="scoped" src="./index.less" lang="less">

</style>
