<template>
  <div class="addApp">
    <div class="all_contain">
      <div class="addAppTitle">
        <el-breadcrumb separator-class="el-icon-arrow-right">
          <el-breadcrumb-item :to="{ path: '/appmange/index' }" class="appManageListTxt">应用管理</el-breadcrumb-item>
          <el-breadcrumb-item>{{titmsg}}</el-breadcrumb-item>
        </el-breadcrumb>
      </div>
      <div class="selectModelWrap" v-if="userType==0 || userType==2">
        <div class="selectModel">
          <el-form ref="ruleForm">
            <el-form-item class="channel" required label="渠道:"></el-form-item>
          </el-form>
          <div class="channelOptionWrap">
            <p v-if="channelOptions.length ? 0: true" class="optionTxt">暂无数据</p>
            <el-checkbox-group @change='getSelectQ' v-model="channelIds" v-for="item in channelOptions" :key="item.id" class="option">
              <el-checkbox :disabled='titmsg=="编辑应用"' :label='item.id'>{{item.name}}</el-checkbox>
            </el-checkbox-group>
          </div>
        </div>
      </div>
      <div class="upLoadWrap">
        <el-form>
          <div class="upLoadLeft">
            <el-form-item label="安装包" required><br>
              <el-upload ref="upload" class="upload-demo" action="http://api.launcher.pactera-sln.club:8185/system/application/upload" :auto-upload="true" :on-success="upLoadSuccess" :headers=uploadToken :before-upload="beforeAvatarUpload" :on-exceed="handleExceed" :file-list="fileList" :limit=1>
                <el-button type="primary" @click="upLoadPakage" v-text="btnTxt"></el-button>
              </el-upload>
            </el-form-item>
            <el-form-item label="应用名称" required>
              <el-input v-model="appName" disabled="disabled"></el-input>
            </el-form-item>
            <el-form-item label="应用ID" required>
              <el-input disabled="disabled" v-model="appId"></el-input>
            </el-form-item>
          </div>
          <div class="upLoadRight">
            <el-form-item label="应用图标" required><br>
              <img :src="imgbaseUrl+appIcon" alt="" class="imgStyle">
            </el-form-item>
            <el-form-item label="包名" required>
              <el-input disabled="disabled" v-model="packageName"></el-input>
            </el-form-item>
          </div>
        </el-form>
      </div>
      <div class="footBtns">
        <el-button @click="cancel">取消</el-button>
        <el-button type="primary" @click="save">保存</el-button>
      </div>
    </div>
  </div>
</template>
<script src="./index.js">
</script>
<style scoped="scoped" src="./index.less" lang="less">

</style>
