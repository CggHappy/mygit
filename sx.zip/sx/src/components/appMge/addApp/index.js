import axios from "@/axios.js";
//import bus from "@/bus.js";
import './addApp.css'
export default {
	data() {
		return {
			userType: 0,
			selectedC: [],
			channelId: '飞歌', //渠道id
			channelOptions: [], //获取渠道列表数据
			isShowChannels: true, //是否显示渠道
			disabled: true, //禁止修改表单项
			isIndeterminate: true,
			isCheckAll: '',
			appName: '', //应用名称
			appId: '', //应用id
			appIcon: '', //应用图标
			packageName: '', //包名
			packagePath: '', //包地址
			fileList: [],//上传文件回显
			channelIds: [], // 提交时的渠道数据
			customerType: '', //身份类型
			btnTxt: '点击上传',
			titmsg: '',
			uploadToken: '',
			fileName: '',
			id: '',
		}
	},
	mounted() { //实例挂载之后
		this.getUsermsg();
	},
	methods: { //方法
		getSelectQ(v) {
			this.selectedC = v;
		},

		getUsermsg() { //获取用户
			let userMsg = JSON.parse(sessionStorage.getItem('userMsg'));
			this.userType = userMsg.userType;
		},

		getUsermsgs() {
			let token = sessionStorage.getItem('Token');
			this.uploadToken = {
				Authorization: token
			};
		},

		//获取渠道
		getChannelOptions() {
			axios.get('/system/channel/findAll')
				.then(res => {
					this.channelOptions = res.data.data;
				})
				.catch(err => {
					console.log('获取渠道数据失败');
				})
		},

		getChannelcur() {
			let row = {};
			this.channelOptions = [];
			this.channelIds = [];
			let data = {
				params: {
					id: JSON.parse(sessionStorage.getItem('appEditcur'))
				}
			}
			axios.get('/system/application/findById', data)
				.then(res => {
					row = res.data.data;
					this.channelOptions.push({
						name: row.channelName,
						id: row.channelId
					})
					this.channelIds.push(row.channelId);
					this.id = row.id;
					this.fileName = row.fileName;
					this.appName = row.name; //名称
					this.appId = row.packageId; //应用id
					this.appIcon = row.logoPath; //应用图标
					this.packageName = row.packageName; //包名
					this.btnTxt = '重新上传';
					this.fileList = [{ name: this.fileName }]
				})
				.catch(err => {
					console.log('获取渠道数据失败');
				})
		},

		// 上传前文件校验
		beforeAvatarUpload(file) {
			let fileName = file.name;
			let pos = fileName.lastIndexOf("\."); //查找文件名最后一个.的位置
			let suffix = fileName.substring(pos + 1); //截取最后一个.位置到字符长度，也就是后缀名
			let isApk = "apk" === suffix;
			if (!isApk) {
				this.$message.error('上传文件不是apk文件，请上传apk文件');
			}
			return isApk;
		},

		//上传文件个数超出限制提示
		handleExceed(files, fileList) {
			this.$message.error(`当前只能上传1个文件`);
		},

		//上传文件
		upLoadPakage() {
			console.log(this.fileList,'a')
			this.fileList = []
			
		},

		handleExceed(file, fileList) {
			
		},

		beforeRemove(file, fileList) {
			return this.$confirm(`确定移除 ${file.name}？`);
		},

		uploadChange(file, fileList) {

		},

		//上传成功
		upLoadSuccess(response, file, fileList) {
			this.fileName = response.data.fileName;
			this.appName = response.data.name;
			this.appId = response.data.packageId;
			this.packageName = response.data.packageName;
			this.appIcon = response.data.logoPath;
			this.packagePath = response.data.packagePath;
			this.btnTxt = '重新上传';
			// if (fileList.length > 1) {
			// 	fileList.splice(0, 1)
			// 	this.fileList = fileList;
			// }
		},

		//取消保存按钮
		cancel() {
			this.$router.push({
				path: "/appmange/index"
			})
		},

		//保存按钮
		save() {
			if (this.$route.path !== '/appmange/editapp') {
				if (this.btnTxt == '重新上传' && this.selectedC.length > 0) {
					let data = {
						fileName: this.fileName,
						channelIds: this.channelIds.toString(), //所选渠道
						name: this.appName, //应用名称
						packageId: this.appId, //应用ID
						logoPath: this.appIcon, //应用图标地址
						packagePath: this.packagePath,
						packageName: this.packageName, //包名
					};
					axios.post('/system/application/save', data)
						.then(res => {
							if (res.data.data == 1) {
								this.$message.success("保存应用信息成功");
								this.$router.push({
									path: "/appmange/index"
								})
							} else {
								this.$message.error(`保存应用信息失败`);
							}
						})
						.catch(err => {
							this.$message.error(`保存应用信息失败`);
						})
				} else {
					this.$message.error(`请勾选渠道和上传apk包!`);
				}
			} else {
				let data = {
					id: this.id,
					fileName: this.fileName,
					channelIds: this.channelIds.toString(), //所选渠道
					name: this.appName, //应用名称
					packageId: this.appId, //应用ID
					logoPath: this.appIcon, //应用图标地址
					packagePath: this.packagePath,
					packageName: this.packageName, //包名
				};
				axios.post('/system/application/update', data)
					.then(res => {
						if (res.data.data == 1) {
							this.$message.success("更新应用信息成功");
							this.$router.push({
								path: "/appmange/index"
							})
						} else {
							this.$message.error(`更新应用信息失败`);
						}
					})
					.catch(err => {
						this.$message.error(`更新失败`);
					})
			}
		},

	},
	watch: { //监听
		'$route'(to, from) { // 对路由变化作出响应...

		},
	},
	created() { //实例创建之后
		if (this.$route.path == '/appmange/editapp') {
			this.getChannelcur();
			this.titmsg = '编辑应用';
		}
		if (this.$route.path == '/appmange/addapp') {
			this.getChannelOptions();
			this.titmsg = '添加应用';
		}
		this.getUsermsgs();
	}
}