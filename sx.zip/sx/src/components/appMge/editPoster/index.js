import axios from "@/axios.js";
//import bus from "@/bus.js";
import './editPoster.css'
export default {
	data() {
		var checkAge = (rule, value, callback) => {
			if (!value || value < 0) {
				return callback(new Error('数值不能为空、0或负数'));
			} else if (!Number.isInteger(value)) {
				callback(new Error('请输入数字值'));
			}
			callback();
		};
		return {
			startTime: '', //起始时间
			endTime: '', //结束时间
			id: sessionStorage.getItem('id'), //当前应用的id
			widthScale: '', // 九宫格宽度
			heightScale: '', //九宫格高度
			dialogFormVisible: false,
			checked: true, //上传框选中
			isShowCheckBox: true, //显示选中框
			isShowUploadTxt: true, //是否显示上传海报文字
			uploadIndex: null,
			fileList: [], //是否有上传，上传了显示true
			layoutNum: [], //配置框个数
			obj: {
				width: 2,
				height: 3,
				type: 0,
				posterPath: [{
					url: 'http://img1.imgtn.bdimg.com/it/u=2628014292,3893886143&fm=27&gp=0.jpg'
				}]
			},
			checkedList: [], //复选框
			nowIndex: '', //当前索引
			ruleForm: {
				widthScale: '',
				heightScale: ''
			},
			rules: {
				widthScale: [{
					validator: checkAge,
					trigger: 'blur'
				}],
				heightScale: [{
					validator: checkAge,
					trigger: 'blur'
				}]
			},
			defaultLogoPath: '',
			uploadToken: '',
			CustomUterus: ''
		}
	},
	mounted() { //实例挂载之后
		this.getPosterData();
		
	},
	methods: { //方法
		//生成相应比例的上传框
		uploadWrap(data) {
			let scale = Math.max(data.width, data.height);
			let uploadWidth = parseInt(200 * (data.width / scale));
			let uploadHeight = parseInt(200 * (data.height / scale));
			let layOut = {
				width: uploadWidth + 'px',
				height: uploadHeight + 'px',
				widthScale: data.width,
				heightScale: data.height,
				posterPath: data.posterPath,
				type: data.type
			};
			this.layoutNum.push(layOut);
			//console.log($('.upLoad').width(),'aaaa')
			// if(layOut.width<){}
			//let heightStyle =this.$refs.ImgBox.style.height;
			let realWidth;//真实的宽度 
      		let realHeight;//真实的高度 //这里做下说明，
			$("ImgBox").each(function (i) {
			let img = $(this);
			$("<img/>").attr("src", $('.ImgBox').attr("src")).load(function () {
				/* 如果要获取图片的真实的宽度和高度有三点必须注意 1、需要创建一个image对象：如这里的$("<img/>") 2、指定图片的src路径 3、一定要在图片加载完成后执行如.load()函数里执行 */
				realWidth = this.width;
				realHeight = this.height;
				console.log(realWidth, 'abcdaaaaaaa')
				//如果真实的宽度大于浏览器的宽度就按照100%显示 
				if (realHeight >= uploadHeight) {
					$('.ImgBox').css("width", "100%").css("height", "100%");
				}
				else {
					//如果小于浏览器的宽度按照原尺寸显示 
					$('.ImgBox').css("width", realWidth + 'px').css("height", realHeight + 'px');
				}
				// $(".imgW").html(realWidth+" 高："+realHeight);
				// });
			})
		})
		},

		//自定义弹框确定按钮
		submitForm(formName) {
			this.$refs[formName].validate((valid) => {
				if (valid) {
					let data = {
						width: this.ruleForm.widthScale,
						height: this.ruleForm.heightScale,
					};
					this.uploadWrap(data);
					this.dialogFormVisible = false;
					this.$refs[formName].resetFields();
				} else {
					return false;
				}
			});
		},

		// 自定义弹框重置
		resetForm(formName) {
			this.$refs[formName].resetFields();
			this.dialogFormVisible = false;
		},

		//自定义弹框取消按钮
		cancelSize() {
			this.dialogFormVisible = false;
			this.widthScale = '';
			this.heightScale = '';
		},

		//上传之前对图片格式进行限制
		beforeAvatarUpload(file) {
			const isJPG = file.type === 'image/jpeg';
			const isPNG = file.type === 'image/png';
			if (!isJPG && !isPNG) {
				this.$message.error('上传图片必须是JPG/PNG 格式!');
			}
			return isPNG || isJPG;
		},

		//删除图片
		removePicture(fileList) {
			setTimeout(() => {
				this.fileList[this.nowIndex] = false;
				this.layoutNum[this.nowIndex].posterPath = undefined;
			}, 200)

		},

		//上传文件发生变化时
		uploadChange(file, fileList) {

		},

		getIndexnum(index) {
			this.nowIndex = index;
		},

		handlePictureCardPreview(file) {

		},

		//上传成功的
		upLoadSuccess(res, file, fileList) {
			this.layoutNum[this.nowIndex].posterPath = [];
			this.layoutNum[this.nowIndex].posterPath.push({
				url: this.imgbaseUrl + res.data
			});
			this.layoutNum[this.nowIndex].type = 1;
			for (let i = 0; i < this.fileList.length; i++) {

			}
			this.fileList[this.nowIndex] = true;
		},

		//选中，显示logo
		uploadCheckBoxChange(index) {

		},

		//开始，结束时间限制
		pickerStartTime() {
			const that = this
			return {
				disabledDate(time) {

					if (!that.endTime) {
						return time.getTime() < Date.now() - 8.64e7
					}
					return time.getTime() < Date.now() - 8.64e7 || time.getTime() > new Date(that.endTime).getTime() - 8.64e7
				}
			}
		},
		pickerEndTime() {
			const that = this
			return {
				disabledDate(time) {
					if (!that.startTime) {
						return time.getTime() < Date.now()
					}
					return time.getTime() < new Date(that.startTime).getTime() + 8.64e7
				}
			}
		},

		//海报详情设置取消按钮
		cancelConfig() {
			this.$router.push({
				path: "/appmange/index"
			})
		},

		//编辑
		saveConfig() {
			let time = 3600000 * 24;
			let arrL = [];
			let posterInfo = [];
			let flag = false;
			//时间限制
			for (var i in this.checkedList) {
				if (this.checkedList[i]) {
					flag = true;
				}
			}
			if (!flag) {
				this.$message.error('请选择海报配置');
				return;
			}
			if (!this.startTime || !this.endTime) {
				this.$message.error('未设置海报有效期');
				return
			} else if ((this.endTime - this.startTime) < time) {
				this.$message.error('海报有效期最少为一天');
				return
			} else {

				for (let i = 0; i < this.layoutNum.length; i++) {
					if (!this.checkedList[i]) {
						this.checkedList[i] = false;
					}
				}

				for (let i = 0; i < this.checkedList.length; i++) {
					arrL.push({
						arr: this.layoutNum[i],
						check: this.checkedList[i]
					})
				}
				//如果前三个都没有被选中
				if (!arrL[0].check && !arrL[1].check && !arrL[2].check) {
					arrL.splice(0, 3);

					for (let i = 0; i < arrL.length; i++) {
						if (!arrL[i].check) {
							delete arrL[i];
						} else {
							//选中的，且没有图片路径，给默认logo路径
							if (arrL[i].arr.posterPath == undefined) {
								arrL[i].arr.posterPath = [{
									url: this.defaultLogoPath
								}];
							}
							arrL[i].arr.type = 1;
						}
					}
				} else {
					//前三个有选中的，循环前三个
					let arr3 = [arrL[0], arrL[1], arrL[2]];
					for (let i = 0; i < arr3.length; i++) {
						arrL[i].arr.type = 0;
						if (arrL[i].check) {
							if (arrL[i].arr.posterPath == undefined) {
								arrL[i].arr.posterPath = [{
									url: this.defaultLogoPath
								}];
							} else {
								for (let i = 3; i < arrL.length; i++) {
									if (arrL[i] != undefined && !arrL[i].check) {
										delete arrL[i]
									} else {
										if (arrL[i] != undefined && arrL[i].arr.posterPath == undefined) {
											arrL[i].arr.posterPath = [{
												url: this.defaultLogoPath
											}];
										}
									}
								}
							};
						}
						else {
							arrL[i].arr.posterPath = undefined
						};
					}
					for (let i = 3; i < arrL.length; i++) {
						if (arrL[i] != undefined && arrL[i].check) {
							if (arrL[i].arr.posterPath == undefined) {
								arrL[i].arr.posterPath = [{
									url: this.defaultLogoPath
								}];;
							}
							arrL[i].arr.type = 1;
						};
						if (arrL[i] != undefined && !arrL[i].check) {
							delete arrL[i]
						}
					}
				}
				for (i in arrL) {
					let obj = {
						width: arrL[i].arr.widthScale,
						height: arrL[i].arr.heightScale,
						type: arrL[i].arr.type,
					};
					if (arrL[i].arr.posterPath) {
						obj.posterPath = arrL[i].arr.posterPath[0].url;
						obj.posterPath = (obj.posterPath).replace(this.imgbaseUrl, "")
					} else {
						obj.posterPath = null
					}
					posterInfo.push(obj);
				}
				let data = {
					applicationId: this.id,
					startTime: this.get_Timer(new Date(this.startTime)),
					endTime: this.get_Timer(new Date(this.endTime)),
					posterListStr: JSON.stringify(posterInfo),
				};
				axios.post('/system/application/savePoster', data)
					.then(res => {
						//提示弹框
						this.$message.success('保存成功');
						this.$router.push({
							path: "/appmange/index"
						})
					})
					.catch(err => {
						this.$message.error('保存失败');
					})
			}
		},

		getUsermsg() {
			let token = sessionStorage.getItem('Token');
			this.uploadToken = {
				Authorization: token
			};
		},

		getPosterData() {
			let userMsg = JSON.parse(sessionStorage.getItem('userMsg'));
			let listPermissions = userMsg.listPermissions;
			for (let i = 0; i < listPermissions.length; i++) {
				let getlistPermissions = listPermissions[i].listPermissions;
				for (let i = 0; i < getlistPermissions.length; i++) {
					if (getlistPermissions[i].name == '自定义宫格') {
						this.CustomUterus = true
					}
				}
			}
			let id = sessionStorage.getItem('id');
			let data = {
				params: {
					id: id
				}
			};
			axios.get('/system/application/findPosterByAppId', data)
				.then(res => {
					this.defaultLogoPath = res.data.data.defaultLogoPath;
					this.startTime = res.data.data.startTime;
					this.endTime = res.data.data.endTime;
					for (let i = 0; i < res.data.data.posterList.length; i++) {
						let obj = {
							width: res.data.data.posterList[i].width,
							height: res.data.data.posterList[i].height,
							type: res.data.data.posterList[i].type,
						};
						if (res.data.data.posterList[i].posterPath == null) {
							obj.posterPath = undefined;
						} else {
							if (res.data.data.posterList[i].posterPath == this.defaultLogoPath) {
								obj.posterPath = undefined;
							} else {
								obj.posterPath = [{
									url: this.imgbaseUrl + res.data.data.posterList[i].posterPath
								}];
							}
							this.checkedList[i] = true;
						};
						this.uploadWrap(obj);
					}
				})
				.catch(err => {
					console.log('海报详情数据加载失败');
				})
		},

	},
	watch: { //监听
		'$route'(to, from) { // 对路由变化作出响应...

		},
	},
	created() { //实例创建之后
		this.getUsermsg()
	},

}