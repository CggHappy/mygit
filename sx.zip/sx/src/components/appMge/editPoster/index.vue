<script src="../../../../config/index.js"></script>
<template>
  <div class="editPoster">
    <div class="all_contain">
      <div class="editPosterTop">
        <el-breadcrumb separator-class="el-icon-arrow-right">
          <el-breadcrumb-item :to="{ path: '/appmange/index' }" class="editPosterTopTitle">应用管理</el-breadcrumb-item>
          <el-breadcrumb-item class="postersDetails">编辑海报详情</el-breadcrumb-item>
        </el-breadcrumb>
      </div>
      <el-form ref="ruleForm">
        <div class="editPosterConfigWrap">
          <div class="editPosterConfig">
            <div>
              <el-form-item class="spanTxt" label="海报配置" required>
                <span class="spanTxtPng">（图片格式为PNG或JPG）</span>
              </el-form-item>
            </div>
            <div class="editPosterUpload">
              <div class="editPosterConfigUpload" v-for="(layout,index) in layoutNum" :key="index" @click="nowIndex = index">
                <div class="uploadWrap" @click="getIndexnum(index)">
                  <el-upload class="upLoad" :style="{width:layout.width,height:layout.height}" action="http://api.launcher.pactera-sln.club:8185/system/application/uploadPoster" list-type="picture-card" :on-preview="handlePictureCardPreview" :before-upload="beforeAvatarUpload" :on-success="upLoadSuccess" :show-file-list="true" :auto-upload="true" :headers=uploadToken :on-change='uploadChange' :on-remove='removePicture' :data="{
                                   id:id,
                                   width:layout.widthScale,
                                   height:layout.heightScale,
                               }" :file-list="layout.posterPath">

                    <img :src="layout.posterPath" alt="" class="uploadImgs">
                    <i class="el-icon-plus avatar-uploader-icon"></i>
                    <img :src="imgbaseUrl+defaultLogoPath" alt="" v-if="checkedList[index] && !fileList[index]" style="position: absolute;top:0;right:0;left:0;bottom:0;margin:auto;max-width:100%;max-height:100%" class="ImgBox">
                  </el-upload>
                  <el-checkbox :key="index" style="position: absolute;top:0;right: 0;" :value="index" :name="'checkbox' + index" v-model="checkedList[index]" @change="uploadCheckBoxChange(index)"></el-checkbox>
                  <p class='uploadTxt' v-if="layout.posterPath?false:true && !checkedList[index] && !fileList[index]">上传海报</p>
                  <span class="scale">{{layout.widthScale+':'+layout.heightScale}}</span>
                </div>
              </div>
            </div>
            <el-button @click="dialogFormVisible = true" class="addBtn" v-if="CustomUterus">
              <span class="btnTxt">添加自定义宫格</span>
            </el-button>
            <div class="editPosterConfigTime">
              <el-form-item class="editPosterConfigTxt" required label="海报有效期"></el-form-item>
              <div>
                <el-date-picker v-model="startTime" type="date" placeholder="开始日期" :picker-options="pickerStartTime()"></el-date-picker>
                <span>至</span>
                <el-date-picker v-model="endTime" type="date" placeholder="结束日期" :picker-options="pickerEndTime()" class="endTime"></el-date-picker>
              </div>
            </div>
          </div>
        </div>
        <div class="editPosterBtns">
          <el-button @click="cancelConfig">取消</el-button>
          <el-button type="primary" @click="saveConfig">保存</el-button>
        </div>
      </el-form>
      <div class="">
        <el-dialog title="自定义宫格布局" :visible.sync="dialogFormVisible" class="dialog">
          <div class="inputs">
            <el-form :model="ruleForm" :rules="rules" ref="ruleForm" class="dialogForm">
              <el-form-item class="leftInput" prop="widthScale">
                <el-input v-model.number="ruleForm.widthScale"></el-input>
              </el-form-item>
              <el-form-item class="rightInput" prop="heightScale">
                <span class="span">X</span>
                <el-input v-model.number="ruleForm.heightScale"></el-input>
              </el-form-item>
              <el-form-item class="formBtns">
                <el-button @click="resetForm('ruleForm')">取 消</el-button>
                <el-button type="primary" @click="submitForm('ruleForm')">提交</el-button>
              </el-form-item>
            </el-form>
          </div>
        </el-dialog>
      </div>
    </div>
  </div>
</template>
<script src="./index.js">
</script>
<style scoped="scoped" src="./index.less" lang="less">

</style>
