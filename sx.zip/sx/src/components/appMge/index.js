import axios from "@/axios.js";
import "./appMge.css";
export default {
	data() {
		return {
			userType: 0,
			channelId: '全部渠道', //渠道ID
			keyWords: '', //查询搜索框关键字
			channelOptions: [], //渠道数据
			tableData: [], //应用列表数据
			multipleSelection: [],
			pageNum: 1, //当前页
			pageSize: 10, //每页显示数据
			totalNum: 0, // 数据总条数
			merge: [], //合并的数据
			customerType: '', //身份类型
			isShowAddAppListItem: false, // 是否显示二级标题
			isShowAddAppBtn: true, //是否显示按钮
			isShowChannelId: true, //是否显示渠道id列
			isShowChannelName: true, //是否显示渠道名称列
			isShowPagination: true, //是否显示分页
			isShowLineTopTxt: false, //是否显示linetop
			seriesData: [], //图表seriesData
			yAxisData: [], //图表y轴数据
			isChangeColor: true, //已/未配置颜色更改
			loading: true,
			ApplicationQuery: false,
			ApplicationAdd: false,
			PostersConfiguration: false,
			CustomUterus: false,
			ApplicationModification: false
		}
	},
	created() {

	},
	mounted() { //实例挂载之后
		this.$router.push(this.$route.path)
		this.getChannelOpations();
		this.getUsermsg();
		this.loadData();
		this.drawTopLine();
	},
	methods: { //方法
		getUsermsg() { //获取用户
			let userMsg = JSON.parse(sessionStorage.getItem('userMsg'));
			this.userType = userMsg.userType;
			let listPermissions = userMsg.listPermissions;
			for (let i = 0; i < listPermissions.length; i++) {
				let getlistPermissions = listPermissions[i].listPermissions;
				for (let i = 0; i < getlistPermissions.length; i++) {
					if (getlistPermissions[i].name == '应用查询') {
						this.ApplicationQuery = true
					}
					if (getlistPermissions[i].name == '应用添加') {
						this.ApplicationAdd = true
					}
					if (getlistPermissions[i].name == '海报配置') {
						this.PostersConfiguration = true
					}
					if (getlistPermissions[i].name == '应用修改') {
						this.ApplicationModification = true
					}
				}
			}
		},
		
		//加载列表数据
		loadData(pageNum, pageSize) {
			this.loading = true;
			let data = {
				params: {
					keyWords: this.$route.query.keyWords ? this.$route.query.keyWords : '',
					channelId: this.$route.query.channelId ? this.$route.query.channelId : '',
					pageNum: pageNum,
					pageSize: pageSize
				}
			};
			axios.get('/system/application/list', data)
				.then((response) => {
					this.loading = false;
					this.merge = [];
					this.tableData = response.data.data.list;
					this.totalNum = response.data.data.total;
					this.seen = this.tableData.length;
					this.isShowPagination = true;
					if (this.tableData.length == 0) {
						this.isShowLine = !this.isShowLine;
						this.isShowAddAppBtn = !this.isShowAddAppBtn;
						this.isShowPagination = false;
					} else {
						for (let i = 0; i < this.tableData.length; i++) {
							if (this.tableData[i].startTime) {
								this.tableData[i].startTime = this.get_Timer(new Date(this.tableData[i].startTime));
							}
							if (this.tableData[i].endTime) {
								this.tableData[i].endTime = this.get_Timer(new Date(this.tableData[i].endTime));
							}
							if (this.tableData[i].configed == 1) {
								this.tableData[i].configed = '已配置';
							} else {
								this.tableData[i].configed = '未配置';
							};
						}
					};
				})
				.catch((error) => {
					console.log('列表数据请求失败')
				})
		},

		//应用分布top
		drawTopLine() {
			let topLine = this.$echarts.init(document.getElementById('topLine'));

			let seriesData = [{
				name: '图吧导航',
				value: '200',
				percent: '12'
			},
			{
				name: '音乐',
				value: '300',
				percent: '30'
			},
			{
				name: '喜马拉雅FM',
				value: '100',
				percent: '10'
			},
			{
				name: '高德地图',
				value: '200',
				percent: '12'
			},
			{
				name: '音乐2',
				value: '200',
				percent: '12'
			},
			{
				name: 'QQ音乐',
				value: '200',
				percent: '12'
			},
			{
				name: '蜻蜓电台',
				value: '432',
				percent: '23'
			},

			{
				name: '喜马拉雅',
				value: '432',
				percent: '23'
			},

			{
				name: '喜马拉雅4',
				value: '432',
				percent: '23'
			},
			{
				name: '喜马拉雅3',
				value: '472',
				percent: '25'
			},

			]
			let yAxisData = ['图吧导航', '音乐', '喜马拉雅FM', '高德地图', '音乐2', 'QQ音乐', '蜻蜓电台', '喜马拉雅', '喜马拉雅4', '喜马拉雅3']
			topLine.setOption({
				title: {
					text: '启动次数',
					left: 'center',
					top: 15,
					textStyle: {
						fontFamily: 'PingFangSC-Semibold',
						fontSize: 18,
						color: '#28324A',
					},
				},
				xAxis: {
					type: 'value',
					boundaryGap: [0, 0.1, 0.2, 0.3, 0.4],
					splitLine: {
						show: false
					},
					nameTextStyle: {
						fontFamily: 'PingFangSC-Medium',
						fontSize: 14,
						color: '#96969E',
					},
					axisTick: {
						show: false
					},
					axisLine: {
						lineStyle: {
							opacity: 0
						}
					},
				},
				yAxis: {
					type: 'category',
					data: yAxisData,
					splitLine: {
						show: false,
					},
					nameTextStyle: {
						fontFamily: 'ArialMT',
						fontSize: 12,
						color: '#96969E',
						textAline: 'center',
					},
					axisTick: {
						show: false
					},
					axisLine: {
						lineStyle: {
							opacity: 0
						}
					},
				},
				tooltip: {
					trigger: 'axis',
					axisPointer: { //阴影指示器
						type: 'shadow'
					},
					formatter: function (params, ticket, callback) {
						let res = '应用：' + params[0].name +
							'<br/>' + '启动次数：' + params[0].data.value + '<br/>' + '启动次数占比：' + params[0].data.percent + '%';
						return res;
					},
					backgroundColor: '#FFFFFF',
					textStyle: {
						width: 169,
						height: 100,
						fontSize: 14,
						color: ' #96969E',
						fontFamily: 'PingFangSC-Medium',
						lineHeight: 20,
					}
				},
				series: [{
					type: 'bar',
					data: seriesData,
					itemStyle: {
						normal: {
							color: '#E78494',
						}
					},
					barWidth: 12,
				},]
			})
		},

		//分页
		indexMethod(index) { //前面索引变化
			return index + 1 + (this.pageNum - 1) * this.pageSize
		},

		toggleSelection(rows) {
			if (rows) {
				rows.forEach(row => {
					this.$refs.multipleTable.toggleRowSelection(row);
				});
			} else {
				this.$refs.multipleTable.clearSelection();
			}
		},

		handleSelectionChange(val) {
			let arr = [];
			for (let i = 0; i < val.length; i++) {
				arr.push(val[i].id)
			}
		},

		handleSizeChange(val) {
			this.loadData(1, val);
		},

		handleCurrentChange(val) {
			this.loadData(val, this.pageSize)
		},
		//查询按钮
		searchData() {
			let queryData = {
				keyWords: this.keyWords,
				channelId: this.channelId == '全部渠道' ? '' : this.channelId,
			};
			this.$router.push({
				path: this.$route.path,
				query: queryData,
			});
			this.loadData(1, 10);
		},

		//获取渠道数据
		getChannelOpations() {
			axios.get('/system/channel/findAll')
				.then(response => {
					this.channelOptions = response.data.data;
				})
				.catch(err => {
					console.log('获取渠道数据失败');
				})
		},

		//海报配置选跳转
		jumpPoster(index, row) {
			this.$router.push({
				path: "/appmange/editposter"
			});
			sessionStorage.setItem('id', row.id);

		},

		enterEdit(row) {
			sessionStorage.setItem('appEditcur', JSON.stringify(row.id));
			this.$router.push({
				path: "/appmange/editapp"
			});
		},

		//添加
		jumpAddApp() {
			this.$router.push({
				path: "/appmange/addapp"
			})
		},

		//列表合并
		objectSpanMethod({
			row,
			column,
			rowIndex,
			columnIndex
		}) {
			if (row.megerRow > 1) {
				if (this.merge.indexOf(row.channelId) == -1) {
					this.merge.push(row.channelId);
				}
				if (columnIndex == 0 || columnIndex == 1) {
					return {
						rowspan: row.megerRow,
						colspan: 1
					};
				}
			} else {
				if (this.merge.indexOf(row.channelId) >= 0) { //删除第0列
					if (columnIndex == 0 || columnIndex == 1) {
						return {
							rowspan: 0,
							colspan: 0
						};
					}
				}
			}
		},
	},
	watch: { //监听
		'$route'(to, from) { // 对路由变化作出响应...

		},
	}

}