import axios from "@/axios.js";
//import bus from "@/bus.js";
export default {
	data() {
		return {
			isCollapse: false,
			activePathStr: '',
			userMsg: {},
			username: '',
			statisticalShow: false,//统计分析显示
			widgetShow: false,//widget显示
			themeShow: false,//主题显示
			applicationShow: false,//应用显示
			accountShow: false,//账号显示
			operationLogShow: false,//运维日志显示
			channelShow: false,//渠道显示
			carVehicleShow: false, //车辆趋势
			appareaShow: false, //应用分布
			versionShow: false, //版本分布
			wusageShow: false, //widget使用情况
			themeusageShow: false, //主题使用
			customevents: false, //自定义事件
			managementShow: false //事件管理
		}
	},
	mounted() { //实例挂载之后
		this.activePathStr = this.$route.path;
		if (this.$route.meta.length > 0) {
			this.activePathStr = this.$route.meta;
		}
		this.getListPermissions();
	},
	methods: { //方法	
		quitSystem(item) {
			if (item == 1) {
				axios.post('/sso/token/logout')
					.then((res) => {
						if (res.data) {
							sessionStorage.clear();
							this.$router.push({
								path: '/'
							})
						}
					})
					.catch(err => {
						console.log(err);
					});
			}
		},

		handleOpen(key, keyPath) {
			
		},

		getUsermsg() {
			this.userMsg = JSON.parse(sessionStorage.getItem('userMsg'));
			this.username = this.userMsg.userName;
		},

		handleClose(key, keyPath) {
			
		},

		getListPermissions() {
			let listPermissions = this.userMsg.listPermissions;
			for (let i = 0; i < listPermissions.length; i++) {
				if (listPermissions[i].name == '主题管理') {
					this.themeShow = true
				}
				if (listPermissions[i].name == '应用管理') {
					this.applicationShow = true
				}
				if (listPermissions[i].name == 'widget管理') {
					this.widgetShow = true
				}
				if (listPermissions[i].name == '渠道管理') {
					this.channelShow = true
				}
				if (listPermissions[i].name == '账号授权') {
					this.accountShow = true
				}
				if (listPermissions[i].name == '统计分析') {
					this.statisticalShow = true;
					let twoListPermissions = listPermissions[i].listPermissions;
					for (let i = 0; i < twoListPermissions.length; i++) {
						if (twoListPermissions[i].name == '车辆趋势') {
							this.carVehicleShow = true;
						}
						if (twoListPermissions[i].name == '应用分布') {
							this.appareaShow = true;
						}
						if (twoListPermissions[i].name == '版本分布') {
							this.versionShow = true;
						}
						if (twoListPermissions[i].name == 'widget统计') {
							this.wusageShow = true;
						}
						if (twoListPermissions[i].name == '主题统计') {
							this.themeusageShow = true;
						}
						if (twoListPermissions[i].name == '事件管理') {
							this.managementShow = true;
						}
						if (twoListPermissions[i].name == '自定义事件管理') {
							this.customevents = true;
						}
					}
				}
				if (listPermissions[i].name == '运维日志') {
					this.operationLogShow = true
				}
			}
		}
	},
	watch: { //监听
		$route(to, from) { // 对路由变化作出响应...
			let random = 0;
			random++;
			this.$route.query.rd = random
			//携带路由信息
			this.$router.push({
				path: this.$route.path,
				query: this.$route.query
			})
			this.activePathStr = to.path;
			if (to.meta.length > 0) {
				this.activePathStr = to.meta;
			}
		},
	},
	created() { //实例创建之后
		this.getUsermsg();
	}
}