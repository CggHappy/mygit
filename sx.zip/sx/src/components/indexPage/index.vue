<template>
	<div class="indexPage">
		<div class="left" :class="{'active_left':isCollapse}">
			<div class="companyhead">
				<img src="../../assets/Img/index/logo.png" alt="" :class="{'imgauto':isCollapse}" />
				<span v-if="!isCollapse">Launcher配置平台</span>
			</div>
			<el-menu :router='true' :unique-opened='true' :default-active="activePathStr" class="el-menu-vertical-demo" @open="handleOpen" @close="handleClose" :collapse="isCollapse">
				<el-menu-item index="/index/situation">
					<img class="el-icon-menu menuimg" src="../../assets/Img/index/1.png" alt="" />
					<span slot="title">整体概况</span>
				</el-menu-item>
				<el-menu-item index="/theme/index" v-if="themeShow">
					<img class="el-icon-menu menuimg" src="../../assets/Img/index/2.png" alt="" />
					<span slot="title">主题管理</span>
				</el-menu-item>
				<el-menu-item index="/appmange/index" v-if="applicationShow">
					<img class="el-icon-menu menuimg" src="../../assets/Img/index/4.png" alt="" />
					<span slot="title">应用管理</span>
				</el-menu-item>
				<el-menu-item index="/diywidget/index" v-if="widgetShow">
					<img class="el-icon-menu menuimg" src="../../assets/Img/index/5.png" alt="" />
					<span slot="title">Widget管理</span>
				</el-menu-item>
				<el-menu-item index="/channel/index" v-if="channelShow">
					<img class="el-icon-menu menuimg" src="../../assets/Img/index/6.png" alt="" />
					<span slot="title">渠道管理</span>
				</el-menu-item>
				<el-menu-item index="/account/index" v-if="accountShow">
					<img class="el-icon-menu menuimg" src="../../assets/Img/index/7.png" alt="" />
					<span slot="title">账号授权</span>
				</el-menu-item>

				<el-submenu index="/analysis" v-if="statisticalShow">
					<template slot="title">
						<img style="" class="el-icon-menu menuimg" src="../../assets/Img/index/8.png" alt="" />
						<span slot="title">统计分析</span>
					</template>
					<el-menu-item-group>
						<el-menu-item index="/analysis/carVehicle" v-if="carVehicleShow">车辆趋势</el-menu-item>
						<el-menu-item index="/analysis/apparea/index" v-if="appareaShow">应用分布</el-menu-item>
						<el-menu-item index="/analysis/version/index" v-if="versionShow">版本分布</el-menu-item>
						<el-menu-item index="/analysis/wusage/index" v-if="wusageShow">widget使用情况</el-menu-item>
						<el-menu-item index="/analysis/themeusage" v-if="themeusageShow">主题使用统计</el-menu-item>
						<el-menu-item index="/analysis/customevents/index" v-if="customevents">自定义事件</el-menu-item>
						<el-menu-item index="/analysis/management" v-if="managementShow">事件管理</el-menu-item>
						<el-menu-item index="/analysis/advertising">广告统计</el-menu-item>
					</el-menu-item-group>
				</el-submenu>
				<el-menu-item index="/index/operatlog" v-if="operationLogShow">
					<img style="width: 13px !important;" class="el-icon-menu menuimg" src="../../assets/Img/index/9.png" alt="" />
					<span slot="title">运维日志</span>
				</el-menu-item>
			</el-menu>
		</div>
		<div class="homeRight" :class="{'activehomeright':isCollapse}">
			<header>
				<div class="rig">
					<div class="imgbox"><img src="../../assets/Img/user.png" alt="" /></div>
					<div class="userbox">
						<el-dropdown @command='quitSystem'>
							<p style="color: white;cursor: pointer;" class="el-dropdown-link">
								<span class="loginUser">{{username}}</span>
								<i class="el-icon-arrow-down el-icon--right"></i>
							</p>
							<el-dropdown-menu slot="dropdown">
								<el-dropdown-item command='1'>退出</el-dropdown-item>
							</el-dropdown-menu>
						</el-dropdown>
					</div>
				</div>
			</header>
			<div class="viewcontent">
				<router-view/>
			</div>
		</div>
	</div>
</template>
<script src="./index.js">
</script>
<style scoped="scoped" src="./index.less" lang="less">

</style>
