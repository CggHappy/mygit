<template>
	<div class="containerlogin" @keyup.enter="login">
		<div class="login-background">
			<div class="img"></div>
		</div>
		<transition name="scale">
			<div class="login-content" v-show="show">
				<div class="top">
					Launcher后台系统
				</div>
				<div class="con">
					<!-- 用户名 -->
					<div class="con-user">
						<i class="iconfont icon-yonghu"></i>
						<input type="text" placeholder="用户名" id="user" v-model.trim="userInput" @focus="userFocus">
						<p v-show="userShow">{{userMsg}}</p>
					</div>
					<!-- 密码 -->
					<div class="con-pass">
						<i class="iconfont icon-suoding1"></i>
						<input type="password" placeholder="密码" id="pass" v-model.trim="passInput" @focus="passFocus">
						<p v-show="passShow">{{passMsg}}</p>
					</div>
					<div class="con-pass">
						<i class="iconfont icon-xunjianjianyan"></i>
						<input placeholder="验证码" id="pass1" v-model.trim="veriInput" @focus="veriFocus">
						<p v-show="veriShow">{{veriMsg}}</p>
						<veria class='veria'></veria>
					</div>
					<!-- 按钮 -->
					<div class="con-button">
						<span>记住密码</span>
						<el-switch v-model="value3">
						</el-switch>
						<!-- 登录按钮 -->
						<button id="login" @click="login"><i class="iconfont icon-dayuhao"></i>登录系统</button>
					</div>
				</div>
				<div class="footer">
					©<span>文思海辉</span>					
				</div>
			</div>
		</transition>

	</div>
</template>

<script>
	import veria from './verification.vue'
	import axios from "@/axios.js";
	import bus from "@/bus.js";	
	import backimg from '@/assets/Img/login_header.jpg'
	export default {
		components: {
			veria
		},
		data() {
			return {
				show: false, //输入框动画
				value3: true,
				userMsg: '', //用户提示信息
				passMsg: '', //密码提示信息
				veriMsg: '', //验证码
				userShow: false,
				passShow: false,
				veriShow: false,
				userInput: '',
				passInput: '',
				veriInput: '',			
			}
		},
		created() {
			let userName = localStorage.getItem('user')
			let passWord = localStorage.getItem('pass')
			if(userName !== null && passWord !== null) {
				this.passInput = passWord;
				this.userInput = userName;
			}
		},
		mounted() {
			this.show = true;			
		},
		watch: {

		},
		methods: {
			login() {
				sessionStorage.setItem('Token',123456)
//				this.$router.push('/index/situation')
				if(this.userInput === '') {
					this.userShow = true;
					this.userMsg = '请输入用户名'
				}
				if(this.passInput === '') {
					this.passShow = true;
					this.passMsg = '请输入密码'
				}
				if(this.veriInput === '') {
					this.veriShow = true;
					this.veriMsg = '请输入验证码'
				}
				if(this.userInput !== '' && this.passInput !== '' && this.veriInput !== '') {
					let datas = {
						userName: this.userInput,
						psd: this.passInput,
						valatCode: this.veriInput
					}
					axios.post('/users/login.do', datas)
						.then(res => {
							//						console.log(res.data.body)
							if(res.data.context == '登陆成功') {
								sessionStorage.setItem('usermsg', JSON.stringify(res.data.body))
								if(this.value3) {
									localStorage.setItem('user', this.userInput)
									localStorage.setItem('pass', this.passInput)
								} else {
									//   localStorage.clear()
									localStorage.removeItem('user')
									localStorage.removeItem('pass')
								}
								
									if(res.data.body.uType == 2) {
										this.$router.push('/index/showgoods')
									}
									else if(res.data.body.uType == 1 || res.data.body.uType == 0) {
										this.$router.push('/index')
									}
									else{
										this.$router.push('/')
									}
								
							} else {
								this.passMsg = res.data.info
								this.passShow = true;
								bus.$emit('freshveri')
							}
						})
						.catch(err => {
							console.log(err)
						})
				}
			},
			userFocus() {
				this.userShow = false;
				this.passShow = false;
				this.veriShow = false;
			},
			passFocus() {
				this.userShow = false;
				this.passShow = false;
				this.veriShow = false;
			},

			veriFocus() {
				this.userShow = false;
				this.passShow = false;
				this.veriShow = false;
			}

		}
	};
</script>
<style lang="less" scoped>
	html,
	body {
		width: 100%;
		height: 100%;
	}
	
	.containerlogin {
		width: 100%;
		height: 100%;
		background-color: #004b80;
		position: relative;
		.login-background {
			height: 400px;
			overflow: hidden;
			width: 100%;
			.img{
				height: 400px;
				background: url(../../assets/Img/loginBg.jpg) no-repeat center;
				animation: myfirst 30s infinite;
			}
		}
		.scale-enter-active,
		.scale-leave-active {
			transition: transform 1s;
		}
		.scale-enter,
		.scale-leave-to {
			transform: scale(0.1);
		}
		.login-content {
			width: 480px;
			height: 359px;
			position: absolute;
			left: 50%;
			margin-left: -240px;
			top: 145px;
			.top {
				width: 480px;
				height: 90px;
				line-height: 90px;
				background: rgba(0, 0, 0, 0.6);
				font-size: 26px;
				font-weight: 600;
				color: #fff;
				text-align: center;
			}
			.con {
				background-color: #fff;
				margin-bottom: 10px;
				.con-user {
					width: 100%;
					height: 64px;
					border-bottom: 1px dashed #eaedf1;
					// padding: 15px 5px;
					position: relative;
					i {
						position: absolute;
						top: 20px;
						left: 40px;
						font-size: 18px;
						color: #666666;
					}
					#user {
						width: 100%;
						height: 100%;
						border: none;
						padding-left: 70px;
					}
					p {
						padding-left: 70px;
						color: red;
						font-size: 12px;
						position: absolute;
						bottom: 0;
					}
				}
				.con-pass {
					width: 100%;
					height: 63px;
					border-bottom: 1px dashed #eaedf1;
					// padding: 15px 5px;
					position: relative;
					i {
						position: absolute;
						top: 19px;
						left: 40px;
						font-size: 18px;
						color: #666666;
					}
					.veria {
						float: right;
						top: -48px;
						right: 40px;
					}
					#pass {
						width: 100%;
						height: 100%;
						border: none;
						padding-left: 70px;
					}
					#pass1 {
						width: 100%;
						height: 100%;
						border: none;
						padding-left: 70px;
					}
					p {
						padding-left: 70px;
						color: red;
						font-size: 12px;
						position: absolute;
						bottom: 0;
					}
				}
				.con-button {
					width: 100%;
					height: 65px;
					background-color: #f9fafc;
					text-align: left;
					line-height: 65px;
					padding-left: 35px;
					span {
						font-size: 14px;
						color: #666666;
						vertical-align: middle;
					}
					button {
						float: right;
						margin-right: 25px;
						margin-top: 17px;
						background-color: #6ad2eb;
						border: 1px solid #1bbae1;
						border-radius: 3px;
						padding: 5px 10px 5px 15px;
						cursor: pointer;
						font-size: 12px;
						color: #fff;
						position: relative;
						i {
							position: absolute;
							font-size: 12px;
							left: 2px;
							top: 7px;
						}
					}
				}
			}
			.footer {
				font-size: 14px;
				color: #999999;
				text-align: center;
				span {
					color: #1bbae1;
				}
			}
		}
	}
	
	@keyframes myfirst {
		0% {
			transform: scale(1.1);
		}
		50% {
			transform: scale(1);
		}
		100% {
			transform: scale(1.1);
		}
	}
	
	@-webkit-keyframes myfirst {
		0% {
			transform: scale(1.1);
		}
		50% {
			transform: scale(1);
		}
		100% {
			transform: scale(1.1);
		}
	}
	
	@-moz-keyframes myfirst {
		0% {
			transform: scale(1.1);
		}
		50% {
			transform: scale(1);
		}
		100% {
			transform: scale(1.1);
		}
	}
	
	@-ms-keyframes myfirst {
		0% {
			transform: scale(1.1);
		}
		50% {
			transform: scale(1);
		}
		100% {
			transform: scale(1.1);
		}
	}
</style>