import axios from "@/axios.js";
//import bus from "@/bus.js";
export default {
	data() {
		return {
			color:''
		}
	},	
	mounted() { //实例挂载之后

	},
	methods: { //方法	
		headleChangeColor(){
			console.log(this.color)
		}
	},
	watch: { //监听
		'$route' (to, from) { // 对路由变化作出响应...

		},
	},
	created() { //实例创建之后

	}
}