<template>
	<div class="Login">登录界面
	
	<colorPicker v-model="color" v-on:change="headleChangeColor"></colorPicker>
	
	</div>
</template>
<script src="./index.js">
</script>
<style scoped="scoped" src="./index.less" lang="less">
</style>