<template>
	<div class="containerlogin" @keyup.enter="login">
		<div class="login-background">
			<div class="img"></div>
		</div>
		<transition name="scale">
			<div class="login-content" v-show="show">
				<div class="top">
					<div class="imgbox"></div>
					<p class="loginTitle">Launcher后台系统</p>
					<p class="loginWelcome">欢迎您登录!</p>
				</div>
				<div class="con1">
					<p class="loginName">管理员登录</p>
					<!-- 用户名 -->
					<div class="con-user">
						<!--<i class="iconfont icon-yonghu"></i>
						<input type="text" placeholder="用户名" id="user" v-model.trim="userInput" @focus="userFocus">
						<p v-show="userShow">{{userMsg}}</p>-->
						<i class="iconfont icon-yonghu"></i>
						<input type="text" placeholder="用户名" id="user" v-model.trim="userInput" @focus="userFocus">
					</div>
					<!-- 密码 -->
					<div class="con-pass">
						<!--<i class="iconfont icon-suoding1"></i>
						<input type="password" placeholder="密码" id="pass" v-model.trim="passInput" @focus="passFocus">
						<p v-show="passShow">{{passMsg}}</p>-->
						<i class="iconfont icon-suoding1"></i>
						<input type="password" placeholder="密码" id="pass" v-model.trim="passInput" @focus="passFocus">
					</div>
					<!--<div class="con-pass">
						<i class="iconfont icon-xunjianjianyan"></i>
						<input placeholder="验证码" id="pass1" v-model.trim="veriInput" @focus="veriFocus">
						<p v-show="veriShow">{{veriMsg}}</p>
						<veria class='veria'></veria>
					</div>-->
					<!-- 按钮 -->
					<div class="con-button">
						<!--<span>记住密码</span>
						<el-switch v-model="value3">
						</el-switch>-->
						<el-checkbox v-model="value3">记住密码</el-checkbox>
						<!-- 登录按钮 -->
						<p><button id="login" @click="login"><i class="iconfont icon-dayuhao"></i>登录系统</button></p>
					</div>
				</div>
			</div>
		</transition>

	</div>
</template>

<script>
	import veria from './verification.vue'
	import axios from "@/axios.js";
	import bus from "@/bus.js";	
	import backimg from '@/assets/Img/loginBgImg.jpg'
	export default {
		components: {
			veria
		},
		data() {
			return {
				show: false, //输入框动画
				value3: true,
				userMsg: '', //用户提示信息
				passMsg: '', //密码提示信息
				veriMsg: '', //验证码
				userShow: false,
				passShow: false,
				veriShow: false,
				userInput: '',
				passInput: '',
				veriInput: '',			
			}
		},
		created() {
			let userName = localStorage.getItem('user')
			let passWord = localStorage.getItem('pass')
			if(userName !== null && passWord !== null) {
				this.passInput = passWord;
				this.userInput = userName;
			}
		},
		mounted() {
			this.show = true;			
		},
		watch: {

		},
		methods: {
			login() {
				if(this.userInput === '') {
					this.userShow = true;
					this.userMsg = '请输入用户名'
				}
				if(this.passInput === '') {
					this.passShow = true;
					this.passMsg = '请输入密码'
				}
				if(this.userInput !== '' && this.passInput !== '') {
					let datas = {
						username: this.userInput,
						password: this.passInput,					
					}
					axios.post('/sso/user/login', datas)
						.then(res => {
	              let Token= `${res.data.token_type} ${res.data.access_token}`;
								sessionStorage.setItem('Token',Token)
								sessionStorage.setItem('userMsg',JSON.stringify(res.data.user))
								this.$router.push('/index/situation')
								if(this.value3) {
									localStorage.setItem('user', this.userInput)
									localStorage.setItem('pass', this.passInput)
								} else {
									localStorage.removeItem('user')
									localStorage.removeItem('pass')
								}
						})
						.catch(err => {
							console.log(err)
							this.$message({
     						  message: '用户名或密码有误！',
     						  type: 'warning'
     						});
        					sessionStorage.clear(); //清空session
						})
				}
			},
			userFocus() {
				this.userShow = false;
				this.passShow = false;
				this.veriShow = false;
			},
			passFocus() {
				this.userShow = false;
				this.passShow = false;
				this.veriShow = false;
			},

			veriFocus() {
				this.userShow = false;
				this.passShow = false;
				this.veriShow = false;
			}

		}
	};
</script>
<style lang="less" scoped>
	html,
	body {
		width: 100%;
		height: 100%;
	}
	
	.containerlogin {
		width: 100%;
		height: 100%;
		background-color: #004b80;
		position: relative;
		.login-background {
			height: 100%;
			overflow: hidden;
			width: 100%;
			.img{
				width:100%;
				height: 100%;
				background: url(../../assets/Img/loginBgImg.jpg) no-repeat center;
				background-size: cover;
			}
		}
		.scale-enter-active,
		.scale-leave-active {
			transition: transform 1s;
		}
		.scale-enter,
		.scale-leave-to {
			transform: scale(0.1);
		}
		.login-content {
			width: 480px;
			
			position: absolute;
			left: 50%;
			margin-left: -240px;
			top: 170px;
			.top {
				width: 155px;
				height: 228px;
				line-height: 90px;
				background: #7290d5;
				font-size: 26px;
				font-weight: 600;
				color: #fff;
				text-align: center;
				float:left;
				position:relative;

				.imgbox{
					background: url(../../assets/Img/index/logo.png) no-repeat center;
					background-size: cover;
					width:30px;
					height:30px;
					position:absolute;
					top:22px;
					left:50%;
					margin-left:-15px;
				}

				.loginTitle,.loginWelcome{
					font-size:14px;
					text-decoration:underline;
					margin-top:62px;
				}

				.loginWelcome{
					margin-top:24px;
					text-decoration:none;
				}
			}
			.con1 {
				background-color: #fff;
				margin-bottom: 10px;
				float:left;
				width:322px;
				height:228px;
				.loginName{
					font-size:14px;
					color:#000;
					text-decoration:underline;
					margin:16px 0px 5px 10px;
				}
				.con-user {
					width: 75%;
					height: 30px;
					position: relative;
					margin:20px auto;
					i {
						position: absolute;
						top: 6px;
						left:3px;
						font-size: 18px;
						color: #ccc;
					}
					#user {
						width: 100%;
						height:30px;
						border: 1px solid #ccc;
						border-radius:5px;
						padding-left: 24px;
					}
					p {
						padding-left: 70px;
						color: red;
						font-size: 12px;
						position: absolute;
						bottom: 0;
					}
				}
				.con-pass {
					width: 75%;
					height: 30px;
					position: relative;
					margin:5px auto;
					i {
						position: absolute;
						top: 6px;
						left:3px;
						font-size: 18px;
						color: #ccc;
					}
					.veria {
						float: right;
						top: -48px;
						right: 40px;
					}
					#pass {
						width: 100%;
						height:30px;
						border: 1px solid #ccc;
						border-radius:5px;
						padding-left: 24px;
					}
					#pass1 {
						width: 100%;
						height: 100%;
						border: none;
						padding-left: 70px;
					}
					p {
						padding-left: 70px;
						color: red;
						font-size: 12px;
						position: absolute;
						bottom: 0;
					}
				}
				.con-button {
					width: 100%;
					height: 26px;
					text-align: left;
					line-height: 26px;
					padding-left: 35px;
					span {
						font-size: 14px;
						color: #666666;
						vertical-align: middle;
					}
					button {
						margin-top: 17px;
						border-color:#6ad2eb!important;
						border: 1px solid #1bbae1;
						border-radius: 3px;
						padding: 5px 10px 5px 15px;
						cursor: pointer;
						font-size: 12px;
						color: #fff;
						position: relative;
						background:#6da1d7!important;
						width:85%;
						i {
							position: absolute;
							font-size: 12px;
							left: 2px;
							top: 7px;
						}
					}
				}
			}
			.footer {
				font-size: 14px;
				color: #999999;
				text-align: center;
				span {
					color: #1bbae1;
				}
			}
		}
	}
	
	@keyframes myfirst {
		0% {
			transform: scale(1.1);
		}
		50% {
			transform: scale(1);
		}
		100% {
			transform: scale(1.1);
		}
	}
	
	@-webkit-keyframes myfirst {
		0% {
			transform: scale(1.1);
		}
		50% {
			transform: scale(1);
		}
		100% {
			transform: scale(1.1);
		}
	}
	
	@-moz-keyframes myfirst {
		0% {
			transform: scale(1.1);
		}
		50% {
			transform: scale(1);
		}
		100% {
			transform: scale(1.1);
		}
	}
	
	@-ms-keyframes myfirst {
		0% {
			transform: scale(1.1);
		}
		50% {
			transform: scale(1);
		}
		100% {
			transform: scale(1.1);
		}
	}
</style>