<template>
	<div class="customEvents">
		<div class="all_contain">
		  <header class="carVehicleManage">
		    <el-breadcrumb separator-class="el-icon-arrow-right">
		      <el-breadcrumb-item>统计分析</el-breadcrumb-item>
		      <el-breadcrumb-item :to="{ path: '/analysis/customevents/index' }">自定义事件</el-breadcrumb-item>
		      <el-breadcrumb-item>详情</el-breadcrumb-item>
		    </el-breadcrumb>
		  </header>
		  <div class="carVehicleUse">
		    <div class="carVehicleUseTop">
		      <div class="carbtn">
                  <div class="radioGroup">
                      <el-radio-group v-model="timeFilter" @change='timeChange'>
                          <el-radio-button label="0">昨天</el-radio-button>
                          <el-radio-button label="1">近一周</el-radio-button>
                          <el-radio-button label="2">最近三十天</el-radio-button>
                          <el-radio-button label="3">自定义时间</el-radio-button>
                      </el-radio-group>
                  </div>
                  <div class="block range" v-if="datePicker">
                      <el-date-picker v-model="valueRange" type="daterange" start-placeholder="开始日期"
                                      end-placeholder="结束日期" align="right" range-separator="~" @change="datePick" format="yyyy 年 MM 月 dd 日" value-format="yyyy-MM-dd">
                      </el-date-picker>
                  </div>
		      </div>
		    </div>
		    <div class="themeUseMain">
		      <div class="carVersion">
		        <div class="selectModel">
		          <label class="channel">渠道：</label>
		          <el-select clearable v-model="channel" placeholder="请选择" >
		            <el-option v-for="item in channelData" :key="item.id" :label="item.label" :value="item.id">
		            </el-option>
		          </el-select>
		        </div>
		        <div class="selectModel">
		          <label class="channel">版本选择：</label>
		          <el-select clearable v-model="version" placeholder="请选择">
		            <el-option v-for="item in versionData" :key="item.id" :label="item.label" :value="item.id">
		            </el-option>
		          </el-select>
		        </div>
		        <div class="selectModel">
		          <label class="channel">事件：</label>
		          <el-select clearable v-model="event" placeholder="请选择">
		            <el-option v-for="item in eventsData" :key="item.id" :label="item.label" :value="item.id">
		            </el-option>
		          </el-select>
		        </div>
		      </div>
		    </div>
		  </div>
		  <div class="carVehicleUse carNumTrend">
		  	<div class="carTrendTop">
		  		<p class="carTrendTitle">事件统计<i class="isIcon">?</i></p>
		  		<div class="carVehicleTitleTab">
		  			<el-radio-group v-model="carFilter" @change='carChange'>
		  				<el-radio-button label="1">事件消息数量</el-radio-button>
		  				<el-radio-button label="2">消息平均时长</el-radio-button>
		  			</el-radio-group>
		  		</div>
		  	</div>
		  	<div class="carTrendMain">
		  		<div id="carData" :style="{width: '100%', height: '100%'}"></div>
		  	</div>
		  </div>
		  <div class="carDataDetail preview">
		      <div class="carDataTop">
		        <p class="carTrendTitle">事件统计明细</p>
		        <div class="carVehicleTitleTab">
		          <el-button class="exportBtn">导出excel</el-button>
		        </div>
		      </div>
		      <div class="carTableMain">
		        <div class="carTableModel">
		          <el-table ref="multipleTable" :data="datas" tooltip-effect="dark" style="width: 100%">
		            <el-table-column prop="time" label="日期">
		            </el-table-column>
		            <el-table-column prop="value" label="事件消息数量">
		            </el-table-column>
		            <el-table-column prop="ms" label="消息平均时长(ms)">
		            </el-table-column>
		          </el-table>
		        </div>
		      </div>
		    </div>
		    <div class="carDataDetail preview">
		        <div class="carDataTop">
		          <p class="carTrendTitle">参数统计<i class="isIcon">?</i></p>
		          <div class="carVehicleTitleTab">
                      <el-select v-model="searchValue" placeholder="请选择" class="selectWidth">
                          <el-option
                                  v-for="item in searchData"
                                  :key="item.id"
                                  :label="item.value"
                                  :value="item.id">
                          </el-option>
                          </el-select>
                      <el-radio-group v-model="parameterFilter" @change='carChange'>
                          <el-radio-button label="1">次数分布</el-radio-button>
                          <el-radio-button label="2">时长分布</el-radio-button>
                      </el-radio-group>
		            <el-button class="exportBtn">导出excel</el-button>
		          </div>
		        </div>
		        <div class="carTableMain">
		          <div class="carTableModel">
		            <el-table ref="multipleTable" :data="datas" tooltip-effect="dark" style="width: 100%" @cell-click="cellClick">
		              <el-table-column prop="parameter" label="参数值">
                          <template slot-scope="scope">
                              <span class="customTab">{{scope.row.parameter}}</span>
                          </template>
		              </el-table-column>
		              <el-table-column prop="value" label="消息数量">
		              </el-table-column>
		              <el-table-column prop="percent" label="占比">
                          <template slot-scope="scope">
                              <span>{{scope.row.percent}}%</span>
                          </template>
		              </el-table-column>
		            </el-table>
		          </div>
		          <div class="tableFooter">
		            <div class="widgetTabRecord">
		              <span>共<span class="spantotal" v-model="totalNum">{{totalNum}}</span>条数据，每页<span class="spansize">{{pageSize}}</span>条</span>
		            </div>
		            <div class="widgetTabFoot">
		              <div class="widgetPage">
		                <el-pagination
		                  @size-change="handleSizeChange"
		                  @current-change="handleCurrentChange"
		                  :current-page.sync="currentpage"
		                  :page-size=pageSize
		                  layout="prev, pager, next, jumper"
		                  :total=totalNum>
		                </el-pagination>
		              </div>
		              <button type="button" class="el-button el-button--primary btnSearch btn" style="border-color:#84A1E5;margin:3px;line-height:3px;background: #84A1E5;">确定</button>
		            </div>
		          </div>
		        </div>
		      </div>
		    </div>
		  </div>
	</div>
</template>
<script src="./index.js">
</script>
<style scoped="scoped" src="./index.less" lang="less">
</style>