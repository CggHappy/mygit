import axios from "@/axios.js";
//import bus from "@/bus.js";
import "../customEvents.css";
import './detail.css'

export default {
    data() {
        return {
            channel: '',
            channelData: [
                {
                    id:'',
                    label:'全部'
                }
            ], //渠道
            version: '',
            versionData: [
                {
                    id:'',
                    label:'全部'
                }
            ], //版本
            event:'',//事件
            eventsData:[
                {
                    id:'',
                    label:'全部'
                }
            ],//事件
            timeFilter: '0',// 默认选中   label值
            lineFilter: 1,
            currentpage: 1,//当前页
            pageSize: 10,//每页条数
            totalNum: 8,//总条数
            tableData: [
                {
                    themeId: '33444',
                    themeClass: '会员专属',
                    themeName: '长草颜',
                    count: '90',
                    time: '89.6',
                    totalCar: '900'

                }
            ],//表格数据
            carFilter: 1,//车辆筛选
            datePicker: false,//点击自定义显示
            valueRange: "",//自定义时间戳
            searchValue:'',
            searchData:[{
                id:'',
                value:'A_Event_ModuleTime(搜索统计)'
            }],//参数统计 select数据
            parameterFilter:'1',//次数分布选中
            datas:[ //假数据
                {
                    time:'2017-12-27',
                    value:'100',
                    percent:'10',
                    ms:'1234',
                    parameter:'time_moudle_time_moudle'
                },
                {
                    time:'2017-12-28',
                    value:'200',
                    percent:'20',
                    ms:'1234',
                    parameter:'time_moudle_time_moudle'
                },
                {
                    time:'2017-12-29',
                    value:'600',
                    percent:'60',
                    ms:'1234',
                    parameter:'time_moudle_time_moudle'
                },
                {
                    time:'2017-12-30',
                    value:'500',
                    percent:'50',
                    ms:'1234',
                    parameter:'time_moudle_time_moudle'
                },
                {
                    time:'2017-12-31',
                    value:'400',
                    percent:'40',
                    ms:'1234',
                    parameter:'time_moudle_time_moudle'
                },
                {
                    time:'2017-01-01',
                    value:'780',
                    percent:'78',
                    ms:'1234',
                    parameter:'time_moudle_time_moudle'
                },
                {
                    time:'2017-01-02',
                    value:'510',
                    percent:'51',
                    ms:'1234',
                    parameter:'time_moudle_time_moudle'
                },
                {
                    time:'2017-01-03',
                    value:'300',
                    percent:'30',
                    ms:'1234',
                    parameter:'time_moudle_time_moudle'
                },
            ],


        }
    },
    mounted() { //实例挂载之后
        //this.drawTopLine();
        this.drawLine()
    },
    methods: { //方法
        timeChange(value) {//点击时间筛选数据
            if (value == 0) {
                this.datePicker = false
            }
            if (value == 1) {
                this.datePicker = false
            }
            if (value == 2) {
                this.datePicker = false
            }
            if (value == 3) {
                this.datePicker = true
            }

        },
        datePick() {
        },
        drawLine() {
            let data = {
                params: {
                    startTime: this.$route.query.startTime ? this.$route.query.startTime : '',
                    endTime: this.$route.query.endTime ? this.$route.query.endTime : '',
                    version: this.$route.query.version ? this.$route.query.version : '',
                    channelId: this.$route.query.channelId ? this.$route.query.channelId : '',

                }
            };
            let line = this.$echarts.init(document.getElementById('carData'));

            line.setOption({
                /*
                tooltip: {
                  trigger: 'axis'
                },

                xAxis: {
                  type: 'category',
                  boundaryGap:false,
                  data: [],
                  axisLine: {
                    lineStyle: {
                      opacity: 0,
                      type: "dotted"
                    }
                  },
                  axisTick: {
                    show: false
                  }
                },
                yAxis: {
                  type: 'value',

                  axisTick: {
                    show: false
                  },
                  axisLine: {
                    lineStyle: {
                      opacity: 0,

                    }
                  },
                },
                series: [

                ]*/

                xAxis: {
                    type: 'category',
                    boundaryGap: true,
                    data: ['12月27日', '12月28日', '12月29日', '12月30日', '12月31日', '1月1日', '1月2日', '1月3日'],
                    axisLine: {
                        lineStyle: {
                            opacity: 0,
                            type: "dotted"
                        }
                    },
                    axisTick: {
                        show: false
                    },
                },
                yAxis: {
                    type: 'value',
                    axisTick: {
                        show: true
                    },
                    axisLine: {
                        lineStyle: {
                            opacity: 0,

                        }
                    },
                    axisTick: {
                        show: false
                    },
                    splitLine:{  
							show:true,
							lineStyle:{
								color:'#F1F1F1',
								type:'dashed'
							}
						},
                },
                tooltip: {
                    trigger: 'axis',
                    formatter: function(params, ticket, callback) {
                        //console.log(params[0]);
                        let res = '时间：' + params[0].data.time
                            +
                            '<br/>' + '事件消息数量：' + params[0].data.value +  '<br/>' + '事件消息占比：' + params[0].data.percent + '%';
                        return res;
                    },
                    backgroundColor: '#FFFFFF',
                    borderRadius: 4,
                    borderWidth: 1,
                    borderColor: '#e5e7f4',
                    textStyle: {
                        width: 160,
                        height: 150,
                        fontSize: 14,
                        color: '#96969E',
                        fontFamily: 'PingFangSC-Regular',
                        lineHeight: 20,
                    }

                },
                axisPointer: {
                    lineStyle: {
                        type: 'dashed',
                        color:'#F6D3D9',
                    }
                },
                series: [{
                    data: this.datas,
                    type: 'line',
                    areaStyle: {
                        normal: {
                            color: {
                                type: 'linear',
                                x: 0,
                                y: 0,
                                x2: 0,
                                y2: 1,
                                colorStops: [{
                                    offset: 0, color: 'rgb(248,218,223)' // 0% 处的颜色
                                }, {
                                    offset: 1, color: '#fff' // 100% 处的颜色
                                }],
                                globalCoord: false // 缺省为 false
                            }
                        }
                    },

                }]

            })

            /*axios.get('/system/statistics/findWisdgetStatic',data)
              .then((res) => {console.log(res.data.data)
              // 填入数据
                 line.setOption({
                     xAxis: {
                         data: res.data.data.timeList
                     },
                     series: [{
                         // 根据名字对应到相应的系列

                              name:'新增车辆',
                              type:'line',
                              areaStyle: {normal: {
                                      color: {
                                          type: 'linear',
                                          x: 0,
                                          y: 0,
                                          x2: 0,
                                          y2: 1,
                                          colorStops: [{
                                              offset: 0, color: 'rgb(248,218,223)' // 0% 处的颜色
                                          }, {
                                              offset: 1, color: '#fff' // 100% 处的颜色
                                          }],
                                          globalCoord: false // 缺省为 false
                                      }
                                  }},
                                 lineStyle:{
                                  color:"rgb(235,154,167)"
                                 },
                              data:res.data.data.carList

                     }]
                 });

              })
              .catch(err => {
                console.log(err);
              });*/
        },

        handleSizeChange() {

        },
        handleCurrentChange() {

        },
        carChange() {

        },
        cellClick(row, column, cell, event) {
            if (column.label == "参数值") {
                this.$router.push({
                    path: "/analysis/customevents/eventsTrend"
                });
            }
        }

    },
    watch: { //监听
        '$route'(to, from) { // 对路由变化作出响应...

        },
    },
    created() { //实例创建之后

    }
}
