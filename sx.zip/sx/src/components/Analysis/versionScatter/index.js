import axios from "@/axios.js";
//import bus from "@/bus.js";
import "./versionScatter.css";
export default {
	data() {
		return {
			carFilter: "0",
			carTrendFilter: "0",
			channel: "",//渠道下拉
			channelData: [
				{
					name: '全部',
					id: ''
				}
			], //渠道
			searchCar: "",//搜索框
			currentpage: 1,//当前页
			pageSize: 10,//每页条数
			totalNum: 1,//总条数
			tableData3: [{
				version: '4.1.2.392',
				name: '435',
				address: '705',
				add: "480",
				count: "865",
				total: "234342342"
			}],//表格数据
			valueDate: "",//日期
			datePicker: false,//自定义时间
			valueRange: '',
			btn: false,
			selected: -1,
            maxNum:10,//版本多选的最大数量
            checkVersions:[],//版本
            versionData:[
                {
                    id:1,
                    name:'2.2.0.254'
                },
                {
                    id:2,
                    name:'2.2.0.255'
                },
                {
                    id:3,
                    name:'2.2.0.256'
                },
                {
                    id:4,
                    name:'2.2.0.226'
                },
                {
                    id:5,
                    name:'2.2.0.236'
                },
                {
                    id:6,
                    name:'2.2.0.237'
                },
                {
                    id:7,
                    name:'2.3.0.237'
                },
                {
                    id:8,
                    name:'2.3.0.227'
                },
                {
                    id:9,
                    name:'2.3.0.247'
                },
                {
                    id:10,
                    name:'2.3.0.257'
                },
                {
                    id:11,
                    name:'2.3.1.227'
                },
                {
                    id:12,
                    name:'2.3.0.267'
                },
                {
                    id:13,
                    name:'2.3.0.223'
                },
                {
                    id:14,
                    name:'2.3.0.224'
                },
                {
                    id:15,
                    name:'2.3.0.228'
                },
                {
                    id:16,
                    name:'2.3.0.238'
                }
            ],
		}
	},
	mounted() { //实例挂载之后
		this.drawLine()
	},
	methods: { //方法	
		switchs() {
			this.btn = !this.btn
			if (this.btn) {
				this.btn = true
			} else {
				this.btn = false
			}
		},
		Determine() {
			this.btn = false
		},
		Btn(item, key) {
			this.selected = key;
		},
		getChannelOptions() {//渠道下拉框

		},
		cellClick(row, column, cell, event) {
			if (column.label == "版本号") {
				this.$router.push({
					path: "/analysis/version/versionDetail"
				});
			}
		},
		drawLine() {
			let line = this.$echarts.init(document.getElementById('carData'));
			line.setOption({
				title: {

				},
				tooltip: {
					trigger: 'axis',
					//formatter: "新增车辆 <br/>日期：2018-{b}<br/>{a}",
					formatter: function (params) {
						//console.log(params[2].data,'aa')
						let res = '新增车辆'
							+
							'<br/>' + '日期：2018-' + params[0].name
							+
							'<br/> ' + params[0].seriesId + '：&nbsp;&nbsp' + params[0].data + '%' + '&nbsp;&nbsp&nbsp;&nbsp&nbsp;&nbsp&nbsp;&nbsp' + params[1].seriesId + '：&nbsp;&nbsp' + params[1].data + '%'
							+
							'<br/> ' + params[2].seriesId + '：&nbsp;&nbsp' + params[2].data + '%' + '&nbsp;&nbsp&nbsp;&nbsp&nbsp;&nbsp&nbsp;&nbsp' + params[3].seriesId + '：&nbsp;&nbsp' + params[3].data + '%'
							+
							'<br/> ' + params[4].seriesId + '：&nbsp;&nbsp' + params[4].data + '%' + '&nbsp;&nbsp&nbsp;&nbsp&nbsp;&nbsp&nbsp;&nbsp' + params[5].seriesId + '：&nbsp;&nbsp' + params[5].data + '%'
							+
							'<br/> ' + params[6].seriesId + '：&nbsp;&nbsp' + params[6].data + '%' + '&nbsp;&nbsp&nbsp;&nbsp&nbsp;&nbsp&nbsp;&nbsp' + params[7].seriesId + '：&nbsp;&nbsp' + params[7].data + '%';
						return res;
					},
					backgroundColor: '#FFFFFF',
					borderRadius: 4,
					borderWidth: 1,
					borderColor: '#e5e7f4',
					textStyle: {
						width: 160,
						height: 130,
						fontSize: 14,
						color: '#96969E',
						fontFamily: 'PingFangSC-Regular',
						lineHeight: 20,
					},
					axisPointer: { type: 'none' }

				},
				grid: {
					// x: 70,
					// y: 20,
					// x2: 40,
					y2: 140
				},
				legend: {  //图例组件
					type: 'plain',
					bottom: 40,
					itemWidth: 10,
					itemHeight: 10,
					textStyle: {
						color: '#333',
						fontSize: 12,
					},
					width: 800,
					itemGap: 25,
					itemWidth: 20,
					itemHeight: 10,
				},
				xAxis: {
					type: '',
					//boundaryGap:''
					data: ['02-26', '02-27', '02-28', '03-01', '03-02', '03-03', '03-04'],
					axisLine: {
						lineStyle: {
							opacity: 0,
							type: "dotted"
						}
					},
					axisTick: {
						show: false
					}
				},
				yAxis: {
					type: 'value',
					axisLine: {
						lineStyle: {
							opacity: 0
						}
					},
					axisTick: {
						show: false
					},
					splitLine:{  
							show:true,
							lineStyle:{
								color:'#F1F1F1',
								type:'dashed'
							}
						}
				},

				series: [
					{
						name: '2.2.0.243',
						type: 'line',
						stack: '总量',
						smooth: true,
						data: [20, 32, 11, 34, 30, 20, 10],
					},
					{
						name: '2.1.0.345',
						type: 'line',
						smooth: true,
						stack: '总量',
						data: [20, 32, 10, 34, 10, 23, 21]

					},
					{
						name: '1.4.3.235',
						type: 'line',
						smooth: true,
						stack: '总量',
						data: [10, 32, 11, 34, 10, 30, 10]
					},
					{
						name: '2.2.0.244',
						type: 'line',
						smooth: true,
						stack: '总量',
						data: [20, 13, 1, 14, 0, 30, 21]
					},
					{
						name: '2.1.0.346',
						type: 'line',
						smooth: true,
						stack: '总量',
						data: [10, 32, 11, 34, 9, 30, 20]
					},
					{
						name: '1.4.3.236',
						type: 'line',
						smooth: true,
						stack: '总量',
						data: [10, 32, 32, 34, 10, 30, 10]
					},
					{
						name: '2.2.0.245',
						type: 'line',
						stack: '总量',
						smooth: true,
						data: [20, 32, 8, 34, 30, 20, 10]
					},
					{
						name: '2.1.0.347',
						type: 'line',
						smooth: true,
						stack: '总量',
						data: [20, 32, 6, 34, 10, 23, 21]
					},
					{
						name: '1.4.3.237',
						type: 'line',
						smooth: true,
						stack: '总量',
						data: [10, 32, 12, 34, 10, 30, 10]
					},
					{
						name: '2.2.0.248',
						type: 'line',
						smooth: true,
						stack: '总量',
						data: [20, 13, 1, 14, 0, 30, 21]
					}
				]
			})
		},
		handleSizeChange() {

		},
		handleCurrentChange() {

		},
		timeChange(value) {//点击时间筛选数据
			if (value == 0) {
				this.datePicker = false
			}
			if (value == 1) {
				this.datePicker = false
			}
			if (value == 2) {
				this.datePicker = false
			}
			if (value == 3) {
				this.datePicker = true
			}

		},
		datePick() { },
	},
	watch: { //监听
		'$route'(to, from) { // 对路由变化作出响应...

		},
	},
	created() { //实例创建之后

	}
}