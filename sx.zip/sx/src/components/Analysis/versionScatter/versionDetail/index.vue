<template>
	<div class="versionScatter">
		<div class="all_contain">
			<header class="carVehicleManage">
				<el-breadcrumb separator-class="el-icon-arrow-right">
					<el-breadcrumb-item>统计分析</el-breadcrumb-item>
					<el-breadcrumb-item :to="{ path: '/analysis/version/index' }">版本分布</el-breadcrumb-item>
					<el-breadcrumb-item>切换版本</el-breadcrumb-item>
				</el-breadcrumb>
			</header>
			<div class="carVehicleUse">
				<div class="carVehicleUseTop">
					<div class="carVehicleTitleTab">
                        <div class="radioGroup">
                            <el-radio-group v-model="carFilter" @change='timeChange'>
                                <el-radio-button label="0">昨天</el-radio-button>
                                <el-radio-button label="1">近一周</el-radio-button>
                                <el-radio-button label="2">最近三十天</el-radio-button>
                                <el-radio-button label="3">自定义时间</el-radio-button>
                            </el-radio-group>
                        </div>
                        <div class="block range" v-if="datePicker">
                            <el-date-picker v-model="valueRange" type="daterange" start-placeholder="开始日期"
                                            end-placeholder="结束日期" align="right" range-separator="~" @change="datePick" format="yyyy 年 MM 月 dd 日" value-format="yyyy-MM-dd">
                            </el-date-picker>
                        </div>
					</div>
				</div>
				<div class="themeUseMain">
					<div class="carVersion">
						<div class="selectModel">
							<label class="channel">渠道：</label>
							<el-select clearable v-model="channel" placeholder="请选择" @focus='getChannelOptions'>
								<el-option v-for="item in channelData" :key="item.id" :label="item.name" :value="item.id">
								</el-option>
							</el-select>
						</div>
					</div>
				</div>
			</div>
			<div class="carVehicleUse versionTrend">
				<div class="carTrendTop">
					<p class="carTrendTitle">版本趋势TOP
						<i class="isIcon">?</i>
					</p>
					<div class="carVehicleTitleTab">
						<el-radio-group v-model="carTrendFilter">
							<el-radio-button label="0">新增车辆</el-radio-button>
							<el-radio-button label="活跃车辆">活跃车辆</el-radio-button>
							<el-radio-button label="启动次数">启动次数</el-radio-button>
							<el-radio-button label="升级车辆">升级车辆</el-radio-button>
							<el-radio-button label="累计车辆">累计车辆</el-radio-button>
						</el-radio-group>
					</div>
				</div>
				<div class="carTrendMain">
					<div id="carData" :style="{width: '100%', height: '100%'}"></div>
					<div class="channelChange" @click="switchs">切换版本</div>
					<div class="channelBox" v-show="btn">
						<div class="title">
							<h1>选择版本</h1>
							<span>（最多选择
								<i>10</i>个版本）</span>
						</div>
                        <div class="versionWrap">
                            <div class="search">
                                <el-input placeholder="搜索版本..."></el-input>
                                <i class="el-icon-search icon"></i>
                            </div>
                            <el-checkbox-group  class="checkGroup" v-model="checkVersions" size="mini" :max="maxNum">
                                <el-checkbox-button v-for="item in versionData" :label="item.name" :key="item.id" ></el-checkbox-button>
                            </el-checkbox-group >
                        </div>

						<div class="footer">
							切换版本
							<span class="sBtn" @click="Determine">确定</span>
						</div>
					</div>
				</div>
			</div>
			<div class="carDataDetail preview">
				<div class="carDataTop">
					<p class="carTrendTitle">版本趋势概览</p>
					<div class="carVehicleTitleTab">
						 <el-button type="success" class="downExcel">导出excel</el-button>
					</div>
				</div>
				<div class="carTableMain">
					<div class="carTableModel">
						<el-table ref="multipleTable" :data="tableData3" tooltip-effect="dark" style="width: 100%">
							<el-table-column prop="version" label="版本号">
							</el-table-column>
							<el-table-column prop="name" label="昨日新增车辆">
							</el-table-column>
							<el-table-column prop="address" label="昨日活跃车辆">
							</el-table-column>
							<el-table-column prop="add" label="日期内新增车辆">
							</el-table-column>
							<el-table-column prop="count" label="日期内启动次数">
							</el-table-column>
							<el-table-column prop="total" label="累计车辆">
							</el-table-column>
						</el-table>
					</div>
				</div>
			</div>
			<div class="carDataDetail">
				<div class="carDataTop">
					<p class="carTrendTitle">明细数据</p>
					<div class="carVehicleTitleTab">
						<div class="appDate">
							<template>
								<div class="block">
								    <span class="demonstration">日期：</span>
								    <el-date-picker
								      v-model="valueDate"
								      type="date"
								      placeholder="选择日期">
								    </el-date-picker>
								  </div>
							</template>
						</div>
						<el-button type="success" class="downExcel">导出execel</el-button>
					</div>
				</div>
				<div class="carTableMain">
					<div class="carTableModel">
						<el-table ref="multipleTable" :data="tableData3" tooltip-effect="dark" style="width: 100%">
							<el-table-column prop="version" label="版本号">
							</el-table-column>
							<el-table-column prop="name" label="昨日新增车辆">
							</el-table-column>
							<el-table-column prop="address" label="昨日活跃车辆">
							</el-table-column>
							<el-table-column prop="add" label="日期内新增车辆">
							</el-table-column>
							<el-table-column prop="count" label="日期内启动次数">
							</el-table-column>
							<el-table-column prop="total" label="累计车辆">
							</el-table-column>
						</el-table>
					</div>
					<div class="tableFooter">
						<div class="widgetTabRecord">
							<span>共<span class="spantotal" v-model="totalNum">{{totalNum}}</span>条数据，每页<span class="spansize">{{pageSize}}</span>条</span>
						</div>
						<div class="widgetTabFoot">
							<div class="widgetPage">
								<el-pagination
							      @size-change="handleSizeChange"
							      @current-change="handleCurrentChange"
							      :current-page.sync="currentpage"
							      :page-size=pageSize
							      layout="prev, pager, next, jumper"
							      :total=totalNum>
							    </el-pagination>
							</div>
							<button type="button" class="el-button el-button--primary btnSearch btn" style="border-color:#84A1E5;margin:3px;line-height:3px;background: #84A1E5;">确定</button>		
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</template>
<script src="./index.js">
</script>
<style scoped="scoped" src="./index.less" lang="less">
</style>