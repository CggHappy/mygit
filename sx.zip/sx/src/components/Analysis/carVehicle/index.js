import axios from "@/axios.js";
//import bus from "@/bus.js";
import "./analysis.css";
export default {
	data() {
		return {
			timeFilter:0,//时间筛选
			carFilter:1,//车辆筛选
			carOptions:[{//版本选择下拉框
      		  value: '选项1',
      		  label: '黄金糕'
      		}, {
      		  value: '选项2',
      		  label: '双皮奶'
      		}, {
      		  value: '选项3',
      		  label: '蚵仔煎'
      		}, {
      		  value: '选项4',
      		  label: '龙须面'
      		}, {
      		  value: '选项5',
      		  label: '北京烤鸭'
          	}],
          	
          	carDetailData: [],//表格数据
           	valueRange:"",//自定义时间戳
           	datePicker:false,//点击自定义显示
           	startTime:"",//给后台传时间戳
           	endTime:"",//给后台传时间戳
           	version:"全部",//给后台传版本选择
           	channel:"全部",//给后台传渠道
           	search:"",//搜索
           	currentpage:1,//当前页
           	pageSize:2,//每页条数
           	totalNum:3,//总条数
			footIsShow:false,
			radio:2  
		}
	},	
	mounted() { //实例挂载之后
		this.timeChange(0);
	},
	methods: { //方法	
		getCarOptions(){//版本选择下拉框
			axios.get('/system/advert/theme/selectByType')
				.then((res) => {
					console.log(res)
				})
				.catch(err => {
					console.log(err);
				});
		},
		//折线图
		getChartData(){
			
		},
		drawLine() {
			let data = {
  				params: {
  					startTime: this.$route.query.startTime ? this.$route.query.startTime : '',
  					endTime: this.$route.query.endTime ? this.$route.query.endTime : '',
  					version:this.$route.query.version ? this.$route.query.version : '',
  					type: this.$route.query.type? this.$route.query.type : '',

  				}
  			};
			let line = this.$echarts.init(document.getElementById('carData'));
			line.setOption({
				tooltip: {
					trigger: 'axis',
					formatter: "时间：2017-{b}<br/>新增车辆：{c} ",
					backgroundColor: '#FFFFFF',
					borderRadius: 4,
					borderWidth: 1,
					borderColor: '#e5e7f4',
					textStyle: {
						width: 160,
						height: 130,
						fontSize: 14,
						color: '#96969E',
						fontFamily: 'PingFangSC-Regular',
						lineHeight: 20,
					},
					axisPointer:{
						lineStyle:{
							color:'#F6D3D9',
							type:'dashed'
						},
					}

				},
				grid: {
					// x: 70,
					y: 80,
					// x2: 40,
					y2: 130
				},
				xAxis: {
				        type: 'category',
				        boundaryGap: true,
				        data: ['12-27', '12-28', '12-29', '12-30', '12-31', '1-1', '1-2', '1-3'],
				        axisLine: {
							lineStyle: {
								opacity: 0
							}
						},
						axisTick: {
							show: false
						},
						
				    },
				    yAxis: {
				        type: 'value',
						axisLine: {
							lineStyle: {
								opacity: 0
							}
						},
						axisTick: {
							show: false
						},
						splitLine:{  
							show:true,
							lineStyle:{
								color:'#F1F1F1',
								type:'dashed'
							}
						}
				    },
				    series: [{
				        data: [100, 200, 600, 500, 780, 810, 300,500,100],
				        type: 'line',
				        areaStyle: {normal: {
				            color: {
				                type: 'linear',
				                x: 0,
				                y: 0,
				                x2: 0,
				                y2: 1,
				                colorStops: [{
				                    offset: 0, color: 'rgb(248,218,223)' // 0% 处的颜色
				                }, {
				                    offset: 1, color: '#fff' // 100% 处的颜色
				                }],
				                globalCoord: false // 缺省为 false
				            }
				        }},
				        
				    }]
				
			})
		},
		handleSizeChange(){

		},
		handleCurrentChange(currentpage){
			this.getData(currentpage,this.pageSize)
		},
		saveParam(){//暂存数据
			var queryData = {
				startTime:this.startTime,//时间
				endTime:this.endTime,//时间
				type:this.carFilter,//车趋势选择
				version:this.version//版本选择
			};
			this.$router.push({
				path: this.$route.path,
				query: queryData
			})
		},
		timeChange(value){//点击时间筛选数据
			let timeValue=value;
			const date = new Date();
			this.datePicker=false;
			if(timeValue=="0"){//昨天
				this.startTime=date.getTime() - 3600 * 1000 * 24;
				this.endTime=date.getTime();
			}else if(timeValue=="1"){//近一周
				this.startTime=date.getTime() - 3600 * 1000 * 24 * 7;
				this.endTime=date.getTime();
			}else if(timeValue=="2"){//三十天
				this.startTime=date.getTime() - 3600 * 1000 * 24 * 30;
				this.endTime=date.getTime();
			}else if(timeValue=="3"){//自定义时间
				this.datePicker=true;
				this.datePick();
			}
			
			this.carChange(1);
			this.getData()
		},
		datePick(date){//设置自定义时间传值
			let rangeDate=date;
			console.log(rangeDate);
			if(rangeDate){
				this.startTime=rangeDate[0];
				this.endTime=rangeDate[1];
			}
			
		},
		carChange(carValue){//选择车辆趋势筛选条件
			this.carFilter=carValue;
			this.saveParam();
			this.drawLine();
		},
		getData(pageNum,pageSize){
			let data = {
  				params: {
  					startTime: this.$route.query.startTime ? this.$route.query.startTime : '',
  					endTime: this.$route.query.endTime ? this.$route.query.endTime : '',
  					version:this.$route.query.version ? this.$route.query.version : '',
  					type: this.$route.query.type ? this.$route.query.type : '',
  					pageNum:pageNum,//当前页
  					pageSize:pageSize//每页条数
  				}
  			};
  			axios.get('/system/statistics/carListStatistics', data)
  				.then((res) => {
  					let tableData=res.data.data;
  					if(tableData.list.length>0){
  						this.footIsShow=true
  					}else{
  						this.footIsShow=false;
  					}
	  				for(let i in tableData.list){
						tableData.list[i].carTime=this.get_Timer(new Date(tableData.list[i].carTime));
					}

  					this.carDetailData=tableData.list
  					this.currentpage=tableData.pageNum;
  					this.pageSize=tableData.pageSize;
  					this.totalNum=tableData.total;
  				})
  				.catch(err => {
  					console.log(err);
  				});
		}

	},
	watch: { //监听
		'$route' (to, from) { // 对路由变化作出响应...

		},
	},
	created() { //实例创建之后

	}
}