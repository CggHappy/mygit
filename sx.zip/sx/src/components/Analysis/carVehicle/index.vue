<template>
	<div class="carVehicle">
		<div class="all_contain">
			<header class="carVehicleManage">
				<el-breadcrumb separator-class="el-icon-arrow-right">
					<el-breadcrumb-item>统计分析</el-breadcrumb-item>
					<el-breadcrumb-item>车辆趋势</el-breadcrumb-item>
				</el-breadcrumb>
			</header>
			<div class="carVehicleUse">
				<div class="carVehicleUseTop">
					<div class="carVehicleTitleTab">
						<div class="radioGroup">
							<el-radio-group v-model="timeFilter" @change='timeChange'>
								<el-radio-button label="0">昨天</el-radio-button>
								<el-radio-button label="1">近一周</el-radio-button>
								<el-radio-button label="2">最近三十天</el-radio-button>
								<el-radio-button label="3">自定义时间</el-radio-button>
							</el-radio-group>
						</div>
						<div class="block range" v-if="datePicker">
						    <el-date-picker v-model="valueRange" type="daterange" start-placeholder="开始日期"
						    end-placeholder="结束日期" align="right" range-separator="~" @change="datePick" format="yyyy 年 MM 月 dd 日" value-format="yyyy-MM-dd">
						     </el-date-picker>
						  </div>
					</div>
				</div>
				<div class="themeUseMain">
					<div class="carVersion">
						<div class="selectModel">
							<label class="channel">渠道:</label>
							<el-select clearable v-model="channel" placeholder="请选择" @focus='getCarOptions'>
								<el-option v-for="item in carOptions" :key="item.id" :label="item.classificationName" :value="item.id">
								</el-option>
							</el-select>
						</div>
						<div class="selectModel">
							<label class="channel">版本选择:</label>
							<el-select clearable v-model="version" placeholder="请选择" @focus='getCarOptions'>
								<el-option v-for="item in carOptions" :key="item.id" :label="item.classificationName" :value="item.id">
								</el-option>
							</el-select>
						</div>
					</div>
				</div>
			</div>
			<div class="carVehicleUse carNumTrend">
				<div class="carTrendTop">
					<p class="carTrendTitle">车辆趋势<i class="isIcon">?</i></p>
					<div class="carVehicleTitleTab">
						<el-radio-group v-model="carFilter" @change='carChange'>
							<el-radio-button label="1">新增车辆</el-radio-button>
							<el-radio-button label="2">活跃车辆</el-radio-button>
							<el-radio-button label="3">启动次数</el-radio-button>
							<el-radio-button label="4">平均单次使用时长</el-radio-button>
						</el-radio-group>
					</div>
				</div>
				<div class="carTrendMain">
					<div id="carData" :style="{width: '100%', height: '100%'}"></div>
					<div class="channelChange">添加对比</div>
					<el-radio-group v-model="radio" class="channelDate">
						<el-radio-button label="1">日</el-radio-button>
						<el-radio-button label="2">周</el-radio-button>
						<el-radio-button label="3">月</el-radio-button>
					</el-radio-group>
				</div>
			</div>
			<div class="carDataDetail">
				<div class="carDataTop">
					<p class="carTrendTitle">明细数据</p>
					<div class="carVehicleTitleTab">
						 <el-button type="success" class="downExcel">导出excel</el-button>
					</div>
				</div>
				<div class="carTableMain">
					<div class="carTableModel">
						<el-table ref="multipleTable" :data="carDetailData" tooltip-effect="dark" style="width: 100%">
							<el-table-column prop="carTime" label="日期" min-width="100px">
							</el-table-column>
							<el-table-column prop="carNum" label="新增车辆" width="141px">
							</el-table-column>
							<el-table-column prop="carProp" label="新增车辆占比" width="141px">
							</el-table-column>
							<el-table-column prop="carActive" label="活跃车辆" width="141px">
							</el-table-column>
							<el-table-column prop="carActiveProp" label="活跃车辆占比" width="141px">
							</el-table-column>
							<el-table-column prop="carStart" label="启动次数" width="141px">
							</el-table-column>
							<el-table-column prop="carStartProp" label="启动次数占比" width="141px">
							</el-table-column>
							<el-table-column prop="carAvgTime" label="平均单次使用时长(min)" min-width="187px">
							</el-table-column>
						</el-table>
					</div>
					<div class="tableFooter" v-if="footIsShow">
						<div class="widgetTabRecord">
							<span>共<span class="spantotal" v-model="totalNum">{{totalNum}}</span>条数据，每页<span class="spansize">{{pageSize}}</span>条</span>
						</div>
						<div class="widgetTabFoot">
							<div class="widgetPage">
								<el-pagination
							      @size-change="handleSizeChange"
							      @current-change="handleCurrentChange"
							      :current-page.sync="currentpage"
							      :page-size=pageSize
							      layout="prev, pager, next, jumper"
							      :total=totalNum>
							    </el-pagination>
							</div>
							<button type="button" class="el-button el-button--primary btnSearch btn" style="border-color:#84A1E5;margin:3px;line-height:3px;background: #84A1E5;">确定</button>		
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</template>
<script src="./index.js">
</script>
<style scoped="scoped" src="./index.less" lang="less">
</style>