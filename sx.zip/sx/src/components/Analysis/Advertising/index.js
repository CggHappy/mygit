import axios from "@/axios.js";
import './advertising.css';
export default {
	data() {
		return {
			value: '',
            channelData: [ //渠道数据
                {
                    name:'全部',
                    id:''
                }
            ],
            Advertisement:[//广告数据
                {
                    name:'全部',
                    id:''
                }
            ],
            advPositionData:[//广告位数据
                {
                    name:'全部',
                    id:''
                }
            ],
            channel: '',//渠道
            advert:'',//广告
            advPosition:'',//广告位
			pageSize:10,//每页条数
      		totalNum:10,//总条数
      		tableData3: [
				{
					date:'1月1日23时',
					title:'我是广告标题',
					advertiser:'广告a',
					agent:'代理b',
					numbers:'90',
					EquipmentNumbers:'12',
					BtnNumbers:'232',
					ClickingRate:'20%',
					money:'100000',
				},
				{
					date:'1月1日23时',
					title:'我是广告标题',
					advertiser:'广告a',
					agent:'代理b',
					numbers:'90',
					EquipmentNumbers:'12',
					BtnNumbers:'232',
					ClickingRate:'20%',
					money:'100000',
				},
				{
					date:'1月1日23时',
					title:'我是广告标题',
					advertiser:'广告a',
					agent:'代理b',
					numbers:'90',
					EquipmentNumbers:'12',
					BtnNumbers:'232',
					ClickingRate:'20%',
					money:'100000',
				},
				{
					date:'1月1日23时',
					title:'我是广告标题',
					advertiser:'广告a',
					agent:'代理b',
					numbers:'90',
					EquipmentNumbers:'12',
					BtnNumbers:'232',
					ClickingRate:'20%',
					money:'100000',
				},
				{
					date:'1月1日23时',
					title:'我是广告标题',
					advertiser:'广告a',
					agent:'代理b',
					numbers:'90',
					EquipmentNumbers:'12',
					BtnNumbers:'232',
					ClickingRate:'20%',
					money:'100000',
				},
				{
					date:'1月1日23时',
					title:'我是广告标题',
					advertiser:'广告a',
					agent:'代理b',
					numbers:'90',
					EquipmentNumbers:'12',
					BtnNumbers:'232',
					ClickingRate:'20%',
					money:'100000',
				},
				{
					date:'1月1日23时',
					title:'我是广告标题',
					advertiser:'广告a',
					agent:'代理b',
					numbers:'90',
					EquipmentNumbers:'12',
					BtnNumbers:'232',
					ClickingRate:'20%',
					money:'100000',
				},
				{
					date:'1月1日23时',
					title:'我是广告标题',
					advertiser:'广告a',
					agent:'代理b',
					numbers:'90',
					EquipmentNumbers:'12',
					BtnNumbers:'232',
					ClickingRate:'20%',
					money:'100000',
				},
				{
					date:'1月1日23时',
					title:'我是广告标题',
					advertiser:'广告a',
					agent:'代理b',
					numbers:'90',
					EquipmentNumbers:'12',
					BtnNumbers:'232',
					ClickingRate:'20%',
					money:'100000',
				},
				{
					date:'1月1日23时',
					title:'我是广告标题',
					advertiser:'广告a',
					agent:'代理b',
					numbers:'90',
					EquipmentNumbers:'12',
					BtnNumbers:'232',
					ClickingRate:'20%',
					money:'100000',
				}
			],
			num:[
				{
					id:1,
					name:'展示次数'
				},
				{
					id:2,
					name:'点击次数'
				}
			],
			Channel:false
		}
	},
	mounted() { //实例挂载之后
		this.drawTopLine();
		this.getPosterDate();
	},
	methods: { //方法	
		getPosterDate(){
			let userMsg = JSON.parse(sessionStorage.getItem('userMsg'));
			if(userMsg.userType == 0 ||userMsg.userType == 2){
				this.Channel = true;
			}else{
				this.Channel = false;
			}
		},
		drawTopLine() {
			let topLine = this.$echarts.init(document.getElementById('applyData'));
			var option = {
				grid:{
					y:80
				},
				xAxis: [
					{
						type: "category",
						splitLine: { show: false },
						data: ["10日", "11日","12日","13日","14日","15日","16日","17日","18日","19日","20日","21日"],
						axisTick: {
							show: false
						},
						axisLine: {
							lineStyle: {
								opacity: 0
							}
						},
					}
				],
				yAxis: [
					{	
						// name:'a',
						type: "value",
						max:1000,
						axisTick: {
							show: false
						},
						splitLine:{  
							show:true,
							lineStyle:{
								color:'#F1F1F1',
								type:'dashed'
							}
						},
						axisLine: {
							lineStyle: {
								opacity: 0
							}
						},
						
					},
					// {
					// 	// name:'b',
					// 	//type: "category",
					// 	type:'value',
					// 	max:10,
					// 	//data: ['0', '10', '20', '30', '40', '50']
					// 	//data:[0,10,20,30,40,50]
					// }
				],
				// legend:{
				// 	type:'plain'
				// },
				tooltip: {
					trigger: 'axis',
					formatter: function (params) {
						let res = '时间：' + params[0].data.day
							+
							'<br/>' + '展示次数：' + params[0].data.value
							+
							'<br/>' + '点击次数：' + params[1].data.value;
						return res;
					},
					backgroundColor: '#FFFFFF',
					borderRadius: 4,
					borderWidth: 1,
					borderColor: '#e5e7f4',
					textStyle: {
						width: 169,
						height: 100,
						fontSize: 14,
						color: ' #96969E',
						fontFamily: 'PingFangSC-Medium',
						lineHeight: 22,
					},
					axisPointer:{
						lineStyle:{
							color:'#F6D3D9',
							type:'dashed'
						},
					}
				},

				series: [
					{
						name: "展示次数",
						type: "line",
						data: [
							{ day: '2017-12-10', value: '80' },
							{ day: '2017-12-11', value: '100' },
							{ day: '2017-12-12', value: '170' },
							{ day: '2017-12-13', value: '420' },
							{ day: '2017-12-14', value: '300' },
							{ day: '2017-12-15', value: '700' },
							{ day: '2017-12-16', value: '600' },
							{ day: '2017-12-17', value: '650' },
							{ day: '2017-12-18', value: '680' },
							{ day: '2017-12-15', value: '400' },
							{ day: '2017-12-16', value: '280' },
							{ day: '2017-12-17', value: '250' }
						],
						itemStyle: {
							normal: {
								color: "#FF607C",
								lineStyle: {
									color: "#E68191"
								}
							}
						},
						 areaStyle: {normal: {
				            color: {
				                type: 'linear',
				                x: 0,
				                y: 0,
				                x2: 0,
				                y2: 1,
				                colorStops: [{
				                    offset: 0, color: 'rgb(248,218,223)' // 0% 处的颜色
				                }, {
				                    offset: 1, color: '#fff' // 100% 处的颜色
				                }],
				                globalCoord: false // 缺省为 false
				            }
				        }},
					},
					{
						name: "点击次数",
						type: "line",
						data: [
							{ day: '2017-12-10', value: '100' },
							{ day: '2017-12-11', value: '150' },
							{ day: '2017-12-12', value: '130' },
							{ day: '2017-12-13', value: '500' },
							{ day: '2017-12-14', value: '220' },
							{ day: '2017-12-15', value: '900' },
							{ day: '2017-12-16', value: '750' },
							{ day: '2017-12-17', value: '800' },
							{ day: '2017-12-18', value: '850' },
							{ day: '2017-12-15', value: '530' },
							{ day: '2017-12-16', value: '420' },
							{ day: '2017-12-17', value: '320' },
						],
						itemStyle: {
							normal: {
								color: "#84A1E5",
								lineStyle: {
									color: "#8DA7E5"
								}
							}
						},
						 areaStyle: {normal: {
				            color: {
				                type: 'linear',
				                x: 0,
				                y: 0,
				                x2: 0,
				                y2: 1,
				                colorStops: [{
				                    offset: 0, color: 'rgb(227,234,250)' // 0% 处的颜色
				                }, {
				                    offset: 1, color: '#fff' // 100% 处的颜色
				                }],
				                globalCoord: false // 缺省为 false
				            }
				        }},
					},
				]
			};
			topLine.setOption(option);
		}
	},
	watch: { //监听
		'$route'(to, from) { // 对路由变化作出响应...

		},
	},
	created() { //实例创建之后

	}
}