<template>
	<div class="Advertising">
		<div class="AdvertisingStatistics">
			<el-breadcrumb separator-class="el-icon-arrow-right" class="AdvertisingStatisticsTop">
				<el-breadcrumb-item>广告分析</el-breadcrumb-item>
				<el-breadcrumb-item>按天</el-breadcrumb-item>
			</el-breadcrumb>
		</div>
		<div class="AdvertisingStatisticsContern">
			<div class="AdvertisingStatisticsDate">
				<el-date-picker v-model="value" type="daterange" range-separator="至" start-placeholder="开始日期" end-placeholder="结束日期">
				</el-date-picker>
			</div>
			<div class="AdvertisingStatisticsCon">
				<div class="channel" v-if="Channel">
					<label class="canal">渠道：</label>
					<el-select placeholder="全部" v-model="channel">
						<el-option v-for="item in channelData" :key="item.id" :label="item.name" :value="item.id">
						</el-option>
					</el-select>
				</div>
				<div class="channel2">
					<label class="canal">广告主：</label>
					<el-select placeholder="全部" v-model="advert">
						<el-option v-for="item in Advertisement" :key="item.id" :label="item.name" :value="item.id">
						</el-option>
					</el-select>
				</div>
				<div class="channel3">
					<label class="title">广告主标题：</label>	
					<el-input placeholder="请输入广告主名称"></el-input>
				</div>
				<div class="channel4">
					<label class="canal">广告位：</label>
					<el-select placeholder="全部" v-model="advPosition">
						<el-option v-for="item in advPositionData" :key="item.id" :label="item.name" :value="item.id">
						</el-option>
					</el-select>
				</div>
				<div class="selBtn">
					<el-button type="primary" >查询</el-button>
				</div>
				
					
			</div>
		</div>
		<div class="AdvertisingChart">
			<div class="tit">广告统计-按天
				<el-button type="primary" class="btn">导出excel</el-button>
			</div>
			<div class="trend">
				<div id="applyData" :style="{width: '100%', height: '100%'}"></div>
				 <!-- <el-select v-model="value" class="sel">
					<el-option
					v-for="item in num"
					:key="item.id"
					:label="item.name"
					:value="item.id">
					</el-option>
  				</el-select>  -->
			</div>
		</div>
		<div class="AdvertisingChartTbale">
			<el-table ref="multipleTable" :data="tableData3" tooltip-effect="dark" style="width: 100%">
				<el-table-column prop="date" label="日期">
				</el-table-column>
				<el-table-column prop="title" label="广告标题">
				</el-table-column>
				<el-table-column prop="advertiser" label="广告主">
				</el-table-column>
				<el-table-column prop="agent" label="代理">
				</el-table-column>
				<el-table-column prop="numbers" label="展示次数">
				</el-table-column>
				<el-table-column prop="EquipmentNumbers" label="展示设备数">
				</el-table-column>
				<el-table-column prop="BtnNumbers" label="点击次数">
				</el-table-column>
				<el-table-column prop="ClickingRate" label="点击率">
				</el-table-column>
				<el-table-column prop="money" label="广告费用（元）">
				</el-table-column>
			</el-table>
			<div class="tableFooter">
				<div class="widgetTabRecord">
					<span>共
						<span class="spantotal" v-model="totalNum">{{totalNum}}</span> 条数据，每页
						<span class="spansize">{{pageSize}}</span> 条</span>
				</div>
				<div class="widgetTabFoot">
					<div class="widgetPage">
						<el-pagination    :page-size=pageSize layout="prev, pager, next, jumper" :total=totalNum>
						</el-pagination>
					</div>
					<button type="primary" class="Determine">确定</button>
				</div>
			</div>
		</div>

	</div>
</template>
<script src="./index.js">
</script>
<style scoped="scoped" src="./index.less" lang="less">

</style>