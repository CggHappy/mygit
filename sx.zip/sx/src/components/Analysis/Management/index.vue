<template>
	<div class="Management">
    <div class="all_contain">
      <header class="carVehicleManage">
        <el-breadcrumb separator-class="el-icon-arrow-right">
          <el-breadcrumb-item>统计分析</el-breadcrumb-item>
          <el-breadcrumb-item>事件管理</el-breadcrumb-item>
        </el-breadcrumb>
      </header>

      <div class="carVehicleUse">
        <div class="themeUseMain">
          <div class="carVersion">
            <div class="selectModel">
              <label class="channel">渠道：</label>
              <el-select clearable v-model="channel" placeholder="请选择" >
                <el-option v-for="item in channelData" :key="item.id" :label="item.label" :value="item.id">
                </el-option>
              </el-select>
            </div>
            <div class="selectModel">
              <label class="channel">版本选择：</label>
              <el-select clearable v-model="version" placeholder="请选择">
                <el-option v-for="item in versionData" :key="item.id" :label="item.label" :value="item.id">
                </el-option>
              </el-select>
            </div>
          </div>
        </div>
      </div>

      <div class="carDataDetail preview">
        <div class="carDataTop">
          <p class="carTrendTitle">事件管理</p>
          <div class="carVehicleTitleTab" v-if="isShowOpationBtns">
            <p class="carDataTopRightTxt">配额10/150</p>
            <el-button class="exportBtn" type="primary" @click="operation">{{btnTxt}}</el-button>
            <el-button class="exportBtn"  type="primary"@click="addMessage">添加事件</el-button>
            <el-button class="exportBtn btnColor"  @click="exportAll">批量导入</el-button>
          </div>
        </div>
        <div class="carTableMain">
          <div class="carTableModel">
            <el-table ref="multipleTable" :data="tableData" tooltip-effect="dark" style="width: 100%" @selection-change="handleSelectionChange">
              <el-table-column
                type="selection"
                width="55" v-if="checkBoxsShow">
              </el-table-column>
              <el-table-column prop="themeId" label="事件ID">
                <template slot-scope="scope">
                  <span class="tabcolor">{{scope.row.messageId}}</span>
                </template>
              </el-table-column>
              <el-table-column prop="themeClass" label="事件名称">
                <template slot-scope="scope">
                  <span>{{scope.row.messageName}}</span>
                </template>
              </el-table-column>
              <el-table-column prop="" label="操作">
                <template slot-scope="scope">
                  <el-button size="mini" class='conBtn' type="primary" @click="editRow(scope.$index, scope.row)" >编辑</el-button>
                  <el-button size="mini" type="danger" class='delBtn'@click="deleteRow(scope.$index,scope.row)" >删除</el-button>
                </template>
              </el-table-column>

            </el-table>
             <div class="tabelAllDel" v-if="isShowTbelAllBtn">
               <el-button type="danger" size="mini" class='delBtn'@click="delAll">删除</el-button>
             </div>
          </div>
          <div class="tableFooter" v-if="isShowPagination">
            <div class="widgetTabRecord">
              <span>共<span class="spantotal" v-model="totalNum">{{totalNum}}</span>条数据，每页<span class="spansize">{{pageSize}}</span>条</span>
            </div>
            <div class="widgetTabFoot">
              <div class="widgetPage">
                <el-pagination
                  @size-change="handleSizeChange"
                  @current-change="handleCurrentChange"
                  :current-page.sync="pageNum"
                  :page-size=pageSize
                  layout="prev, pager, next, jumper"
                  :total=totalNum>
                </el-pagination>
              </div>
              <button type="button" class="el-button el-button--primary btnSearch btn" style="border-color:#84A1E5;margin:3px;line-height:3px;background: #84A1E5;">确定</button>
            </div>
          </div>
        </div>
      </div>

      <div>
        <el-dialog title="批量导入" :visible.sync="exportdialogVisible">
          <div class="dialogBodyWrap">
            <div class="dialogTxt">需要导入的数据文件</div>
            <div class="dialogBodyUpload">
              <el-upload
                class="upload"
                action="system/file"
                :before-upload="beforeFileUpload"
                :on-success='sucessFileUpload'
              >
                <el-button size="small" type="primary" class='conBtn'>选择文件</el-button>
                <div slot="tip" class="el-upload__tip uploadTxt"  >未选择任何文件</div>
              </el-upload>
              <div slot="tip" class="el-upload__tip promptTxt">上传文件编码需为UTF-8编码</div>
            </div>
            <a href="javascript:" class="dialogTxt txtColor" @click="uplodModel">下载模板</a>
          </div>
          <div slot="footer" class="dialog-footer">
            <el-button @click="exportdialogVisible=false">取 消</el-button>
            <el-button type="primary" class='conBtn' @click="sureExport">确 定</el-button>
          </div>
        </el-dialog>
      </div>

      <div>
        <el-dialog title="添加事件" :visible.sync="megDialogVisible">
          <el-form  :model="ruleForm" :rules="rules"  ref="ruleForm" class="massageForm">
            <el-form-item label="事件ID" prop="messageId" >
              <el-input v-model="ruleForm.messageId" placeholder="事件ID" class="inputTxt"></el-input>
            </el-form-item>
            <el-form-item label="事件名称" prop="messageName" class="massageFormItem">
              <el-input v-model="ruleForm.messageName" placeholder='最多输入10个字符' class="inputTxt"></el-input>
            </el-form-item>
          </el-form>
          <div slot="footer" class="dialog-footer">
            <el-button @click="megDialogVisible=false">取 消</el-button>
            <el-button type="primary"  class='conBtn' @click="sureMassage">保存</el-button>
          </div>

        </el-dialog>
      </div>

      <div>
        <el-dialog title="编辑事件" :visible.sync="editDialogVisible">
          <el-form  :model="editForm" :rules="rules"  ref="editForm" class="massageForm">
            <el-form-item label="事件ID" prop="messageId" >
              <!--<el-input v-model="editForm.messageId" placeholder="事件ID" class="inputTxt"></el-input>-->
              <span>{{editForm.messageId}}</span>
            </el-form-item>
            <el-form-item label="事件名称" prop="messageName" class="massageFormItem">
              <el-input v-model="editForm.messageName" placeholder='最多输入10个字符' class="inputTxt"></el-input>
            </el-form-item>
          </el-form>
          <div slot="footer" class="dialog-footer">
            <el-button @click="editDialogVisible=false">取 消</el-button>
            <el-button type="primary"class='conBtn' @click="sureEdit">保存</el-button>
          </div>

        </el-dialog>
      </div>
      <el-dialog title="删除事件" :visible.sync="delDialogVisible">
        <p class="delDialogTxt">你确定要删除自定义事件？</p>
        <div slot="footer" class="dialog-footer">
          <el-button @click="delDialogVisible=false">取 消</el-button>
          <el-button type="primary" class='conBtn' @click="sureDelete">确定</el-button>
        </div>
      </el-dialog>
      <div>

      </div>
    </div>
  </div>
</template>
<script src="./index.js">
</script>
<style scoped="scoped" src="./index.less" lang="less">
</style>
