import axios from "@/axios.js";
//import bus from "@/bus.js";
import './manageMent.css'
export default {
	data() {
		return {
      channel:'', //渠道
      version:'', //版本
      channelData:[
        {id:'',label:'全部'}
      ],
      versionData:[
        {id:'',label:'全部'}
      ],
      tableData:[
        {
          messageId:'12345',
          messageName:'互动'
        }
      ],
      exportdialogVisible:false,//批量操作的弹窗
      btnTxt:'批量操作',//批量操作按钮的文字切换
      ruleForm:{
        messageId:'',//事件id
        messageName:'',//事件名称
      },
      rules:{
        messageId: [
          { required: true, message: '请输入事件ID', trigger: 'blur' },
        ],
        messageName:[
          { required: true,
            min: 1,
            max: 15,
            message: '长度在小于10 个字符',
            trigger: 'blur'
          },
        ]
      },
      megDialogVisible:false,//添加事件的弹窗
      editDialogVisible:false,//编辑弹窗
      editForm:{
        messageId:'',
        messageName:''
      },
      delDialogVisible:false,//删除弹窗
      totalNum:1,//列表数据总和
      pageNum:1,//当前页
      pageSize:10,//每页显示数据条数20
      isShowOpationBtns:true,//批量操作三个按钮的显示
      isShowPagination:true,//显示分页
      isShowTbelAllBtn:false,//显示批量操作的删除按钮
      checkBoxsShow:false,//列表的复选框显示


    }


	},
	mounted() { //实例挂载之后
    //this.loadData()
	},
	methods: { //方法
    //加载数据
    loadData(){
      let data = {
        pageNum:this.pageNum,
        pageSize:10
      };
      axios.post('',data)
        .then(res=>{
          console.log(res);
          this.tableData =[];
          this.totalNum = res.data.data.total;
          this.pageSize = res.data.data.pageSize;
         //处理渲染数据
          //相关按钮的隐藏
          if(this.tableData==0){
            this.isShowOpationBtns = !this.isShowOpationBtns;
            this.isShowPagination = !this.isShowPagination;
            this.isShowTbelAllBtn = !this.isShowTbelAllBtn;
          }
        })
        .catch(err=>{
          console.log(err)
        })
    },

    //分页
    indexMethod(index) { //前面索引变化
      return index + 1 + (this.pageNum - 1) * this.pageSize
    },
    toggleSelection(rows) {
      if (rows) {
        rows.forEach(row => {
          this.$refs.multipleTable.toggleRowSelection(row);
        });
      } else {
        this.$refs.multipleTable.clearSelection();
      }
    },
    handleSizeChange(val) {
      //console.log(`每页 ${val} 条`, 999);
    },
    handleCurrentChange(val) {
      console.log(`当前页: ${val}`);
      this.pageNum = val;
      //this.loadData()
    },

    //列表复选框勾选
    handleSelectionChange(val) {
      //console.log(val);
      let arr = [];
      for (let i = 0; i < val.length; i++) {
        arr.push(val[i].id)
      }
      //console.log(arr.join(','))
      //this.xuanstr=arr.join(',');
    },

    //批量删除
    delAll(){
      //获取到勾选的复选框数组
      //删除接口
    },

    //批量操作导入
    exportAll(){
      this.exportdialogVisible = !this.exportdialogVisible;
    },
    cancelExport(){
      this.exportdialogVisible = !this.exportdialogVisible;
    },
    sureExport(){
      this.exportdialogVisible = !this.exportdialogVisible;
    },

  //批量操作
    operation(){
     if(this.btnTxt=='批量操作'){
       this.btnTxt = '完成';
       //显示全选和删除
         this.isShowTbelAllBtn = true;
         this.checkBoxsShow = true;
     }else {
       this.btnTxt = '批量操作';
         this.isShowTbelAllBtn = false;
         this.checkBoxsShow = false;
     }
    },

    //添加事件
    addMessage(){
    this.megDialogVisible = !this.megDialogVisible
    },
    sureMassage(){
      this.megDialogVisible = !this.megDialogVisible
      //保存数据，调接口
      //清空值
    },
    //操作中的删除按钮
    deleteRow(index,row){
      this.delDialogVisible = !this.delDialogVisible
      sessionStorage.setItem('delId',row.id)
    },

    //删除弹窗的确定按钮
    sureDelete(){
      this.delDialogVisible = !this.delDialogVisible
      let data = {
        id:sessionStorage.getItem('delId')
      }
      //删除接口
      //刷新列表
    },

    //操作中的编辑按钮
    editRow(index,row){
      this.editDialogVisible = !this.editDialogVisible;
      //console.log(row);
      this.editForm.messageId = row.messageId;
      this.editForm.messageName = row.messageName;
    },

    //编辑弹窗的保存按钮
    sureEdit(){
     let data = {
       messageId:this.editForm.messageId,
       messageName:this.editForm.messageName
     }
     //保存接口
     //刷新列表
    },

    //下载模板
    uplodModel(){
      axios.get('')
        .then(res=>{
          console.log(res);
          window.location.href = this.imgbaseUrl + res.data
        })
        .catch(err=>{
          console.log(err);
        })
    },

    // 上传前文件校验
    beforeFileUpload(){
      const isLt5M = file.size / 1024 / 1024 < 5;
      if(!isLt5M){
        this.$message.error('上传文件不能超过 5M ')
      }
      return isLt5M;
    },

    //上传成功
    sucessFileUpload(){

    },
	},
	watch: { //监听
		'$route' (to, from) { // 对路由变化作出响应...

		},
	},
	created() { //实例创建之后

	}
}
