<template>
	<div class="widgetUsage">
		<div class="all_contain">
			<header class="carVehicleManage">
				<el-breadcrumb separator-class="el-icon-arrow-right">
					<el-breadcrumb-item class="txtColor">统计分析</el-breadcrumb-item>
					<el-breadcrumb-item :to="{ path: '/analysis/wusage/index' }">Widget使用情况</el-breadcrumb-item>
					<el-breadcrumb-item>详情</el-breadcrumb-item>
				</el-breadcrumb>
			</header>
			<div class="carVehicleUse">
				<div class="carVehicleUseTop">
					<div class="carVehicleTitleTab">
                        <div class="radioGroup">
                            <el-radio-group v-model="timeFilter" @change='timeChange'>
                                <el-radio-button label="0">昨天</el-radio-button>
                                <el-radio-button label="1">近一周</el-radio-button>
                                <el-radio-button label="2">最近三十天</el-radio-button>
                                <el-radio-button label="3">自定义时间</el-radio-button>
                            </el-radio-group>
                        </div>
                        <div class="block range" v-if="datePicker">
                            <el-date-picker v-model="valueRange" type="daterange" start-placeholder="开始日期"
                                            end-placeholder="结束日期" align="right" range-separator="~" @change="datePick" format="yyyy 年 MM 月 dd 日" value-format="yyyy-MM-dd">
                            </el-date-picker>
                        </div>
					</div>
				</div>
				<div class="themeUseMain">
					<div class="carVersion">
						<div class="selectModel">
							<label class="channel">渠道：</label>
							<el-select clearable v-model="channel" placeholder="请选择" @focus='getCarOptions'>
								<el-option v-for="item in channelData" :key="item.id" :label="item.name" :value="item.id">
								</el-option>
							</el-select>
						</div>
						<div class="selectModel">
							<label class="channel">版本选择：</label>
							<el-select clearable v-model="version" placeholder="请选择" @focus='getCarOptions'>
                                <el-option v-for="item in versionData " :key="item.id" :label="item.name"  :value="item.id">
								</el-option>
							</el-select>
						</div>
					</div>
				</div>
			</div>
			<div class="carVehicleUse widgetState">
				<div class="carTrendTop">
					<p class="carTrendTitle">Widget使用情况<i class="isIcon">?</i></p>
					<div class="carVehicleTitleTab">
						<el-radio-group v-model="carFilter">
							<el-radio-button label="0">点击次数</el-radio-button>
							<el-radio-button label="1">累计车辆数</el-radio-button>
						</el-radio-group>
					</div>
				</div>
				<div class="carTrendMain">
					<div id="carData" :style="{width: '100%', height: '100%'}"></div>
				</div>
			</div>
			<div class="carVehicleUse widgetState">
				<div class="carTrendTop">
					<p class="carTrendTitle">音乐widget使用趋势<i class="isIcon" style="left:205px">?</i></p>
                    <p class="carTrendTitle marginRight"><i class="el-icon-close" @click="jumpRouter"></i></p>
				</div>
				<div class="carTrendMain">
					<div id="carData1" :style="{width: '100%', height: '100%'}"></div>
				</div>
			</div>
			<div class="carDataDetail preview">
				<div class="carDataTop">
					<p class="carTrendTitle">音乐播放明细</p>
				</div>
				<div class="carTableMain">
					<div class="carTableModel">
						<el-table ref="multipleTable" :data="carDetailData" tooltip-effect="dark" style="width: 100%">
							<el-table-column prop="applicationName" label="歌曲名">
								<template slot-scope="scope">
									<span>{{scope.row.applicationName}}</span>
								</template>
							</el-table-column>
							<el-table-column prop="startUpNum" label="播放次数">
							</el-table-column>
						</el-table>
                        <!-- <div class="tableFooter" >
                            <div class="widgetTabRecord">
                                <span>共<span class="spantotal">{{totalNum}}</span>条数据，每页<span class="spansize">10</span>条</span>
                            </div>
                            <div class="widgetTabFoot">
                                <div class="widgetPage">
                                    <el-pagination
                                            @size-change="handleSizeChange"
                                            @current-change="handleCurrentChange"
                                            :current-page="pageNum"
                                            :page-size="pageSize"
                                            layout="prev, pager, next, jumper"
                                            :total="totalNum">
                                    </el-pagination>
                                </div>
                                <button type="button" class="el-button el-button--primary btnSearch btn_s"  >确定</button>
                            </div>
                        </div> -->
					</div>
				</div>
			</div>
		</div>
	</div>
</template>
<script src="./index.js">
</script>
<style scoped="scoped" src="./index.less" lang="less">
</style>