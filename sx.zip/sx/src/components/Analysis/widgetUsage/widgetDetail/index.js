import axios from "@/axios.js";
//import bus from "@/bus.js";
import "./widgetUsage.css";
export default {
	data() {
		return {
			timeFilter:0,//时间筛选
			carFilter:1,//车辆筛选
            channelData:[{
                name:'全部',
                id:''
            }],
            versionData:[
                {
                    name:'全部',
                    id:''
                }
            ],
          	
          	carDetailData: [{
      	  	  applicationName: '音乐',
      	  	  startUpNum: '1518',
      	  	  carNum:"30%"
      	  	}, {
      	  	  applicationName: '收音机',
       	  	  startUpNum: '800',
       	  	  carNum:"20%"
      	  	}, {
      	  	  applicationName: '天气',
      	  	  startUpNum: '788',
      	  	  carNum:"20%"
      	  	}, {
      	  	  applicationName: '高德',
      	  	  startUpNum: '800',
      	  	  carNum:"20%"
      	  	},{
      	  	  applicationName: '微信',
      	  	  startUpNum: '800',
      	  	  carNum:"20%"
      	  	}],//表格数据
           	valueRange:"",//自定义时间戳
           	datePicker:false,//点击自定义显示
           	startTime:"",//给后台传时间戳
           	endTime:"",//给后台传时间戳
           	version:"",//给后台传版本选择
           	channel:"",//给后台传渠道
           	search:"",//搜索
           	currentpage:1,//当前页
           	pageSize:2,//每页条数
           	totalNum:5,//总条数
           	footIsShow:false
		}
	},	
	mounted() { //实例挂载之后
		this.timeChange(0);
	},
	methods: { //方法
        jumpRouter(){
            this.$router.push({
                path: "/analysis/wusage/index"
            });
        },
		getCarOptions(){//版本选择下拉框
			/*axios.get('/advert/theme/selectByType')
				.then((res) => {
					console.log(res)
				})
				.catch(err => {
					console.log(err);
				});*/
		},
		//折线图
		getChartData(){
			
		},
		drawLine() {
			let data = {
  				params: {
  					startTime: this.$route.query.startTime ? this.$route.query.startTime : '',
  					endTime: this.$route.query.endTime ? this.$route.query.endTime : '',
  					version:this.$route.query.version ? this.$route.query.version : '',
  					channelId: this.$route.query.channelId? this.$route.query.channelId : '',

  				}
  			};
			let line = this.$echarts.init(document.getElementById('carData'));
			let line1 = this.$echarts.init(document.getElementById('carData1'));
			line.setOption({
				xAxis: {
				        type: 'category',
				        boundaryGap: true,
				        data: ['12-27', '12-28', '12-29', '12-30', '12-31', '01-01', '01-02', '01-03'],
				        axisLine: {
							lineStyle: {
								opacity: 0,
								type: "dotted"
							}
						},
                    axisTick: {
                        show: false
                    },
						
				    },
				    yAxis: {
				        type: 'value',
				        axisTick: {
							show: false
						},
						axisLine: {
							lineStyle: {
								opacity: 0,
								
							}
						},

				    },
                tooltip: {
                    trigger: 'axis',
                    formatter: "2017-{b}<br/>点击次数：{c} ",
                    backgroundColor: '#FFFFFF',
                    borderRadius: 4,
                    borderWidth: 1,
                    borderColor: '#e5e7f4',
                    textStyle: {
                        width: 160,
                        height: 130,
                        fontSize: 14,
                        color: '#96969E',
                        fontFamily: 'PingFangSC-Regular',
                        lineHeight: 20,
					},
					axisPointer: { type: 'none' }

                },
                axisPointer:{
                    lineStyle:{
                        type:'dashed'
                    }
                },
				    series: [{
				        data: [100, 200, 600, 500, 780, 810, 300,500,100],
				        type: 'line',
				        areaStyle: {normal: {
				            color: {
				                type: 'linear',
				                x: 0,
				                y: 0,
				                x2: 0,
				                y2: 1,
				                colorStops: [{
				                    offset: 0, color: 'rgb(248,218,223)' // 0% 处的颜色
				                }, {
				                    offset: 1, color: '#fff' // 100% 处的颜色
				                }],
				                globalCoord: false // 缺省为 false
				            }
				        }},
				        
				    }]
				
			})

			line1.setOption({
				xAxis: {
				        type: 'category',
				        boundaryGap: true,
				        data:['12-27', '12-28', '12-29', '12-30', '12-31', '01-01', '01-02', '01-03'],
				        axisLine: {
							lineStyle: {
								opacity: 0,
								type: "dotted"
							}
						},
                    axisTick: {
                        show: false
                    },
				},
				    yAxis: {
				        type: 'value',
				        axisTick: {
							show: false
						},
						axisLine: {
							lineStyle: {
								opacity: 0,
								
							}
						},
				    },
                    tooltip: {
                    trigger: 'axis',
                    formatter: "2017-{b}<br/>点击次数：{c} ",
                    backgroundColor: '#FFFFFF',
                    borderRadius: 4,
                    borderWidth: 1,
                    borderColor: '#e5e7f4',
                    textStyle: {
                        width: 160,
                        height: 130,
                        fontSize: 14,
                        color: '#96969E',
                        fontFamily: 'PingFangSC-Regular',
                        lineHeight: 20,
					},
					axisPointer: { type: 'none' }

                },
                axisPointer:{
                    lineStyle:{
                        type:'dashed'
                    }
                },
				    series: [{
				        data: [100, 200, 600, 500, 780, 810, 300,500,100],
				        type: 'line',
				        areaStyle: {normal: {
				            color: {
				                type: 'linear',
				                x: 0,
				                y: 0,
				                x2: 0,
				                y2: 1,
				                colorStops: [{
				                    offset: 0, color: 'rgb(248,218,223)' // 0% 处的颜色
				                }, {
				                    offset: 1, color: '#fff' // 100% 处的颜色
				                }],
				                globalCoord: false // 缺省为 false
				            }
				        }},
				        
				    }]
				
			})

			/*axios.get('/system/statistics/findWisdgetStatic',data)
				.then((res) => {console.log(res.data.data)
				// 填入数据
				   line.setOption({
				       xAxis: {
				           data: res.data.data.timeList
				       },
				       series: [{
				           // 根据名字对应到相应的系列
           					
       			            name:'新增车辆',
       			            type:'line',
       			            areaStyle: {normal: {
                                color: {
                                    type: 'linear',
                                    x: 0,
                                    y: 0,
                                    x2: 0,
                                    y2: 1,
                                    colorStops: [{
                                        offset: 0, color: 'rgb(248,218,223)' // 0% 处的颜色
                                    }, {
                                        offset: 1, color: '#fff' // 100% 处的颜色
                                    }],
                                    globalCoord: false // 缺省为 false
                                }
                            }},
                           lineStyle:{
                           	color:"rgb(235,154,167)"
                           },
       			            data:res.data.data.carList
       			        
				       }]
				   });
					
				})
				.catch(err => {
					console.log(err);
				});*/
		},
		handleSizeChange(){

		},
		handleCurrentChange(currentpage){
			//this.getData(currentpage,this.pageSize)
		},
		saveParam(){//暂存数据
			var queryData = {
				startTime:this.startTime,//时间
				endTime:this.endTime,//时间
				channelId:this.carFilter,//车趋势选择
				version:this.version//版本选择
			};
			this.$router.push({
				path: this.$route.path,
				query: queryData
			})
		},
		timeChange(value){//点击时间筛选数据
			let timeValue=value;
			const date = new Date();
			this.datePicker=false;
			if(timeValue=="0"){//昨天
				/*this.startTime=date.getTime() - 3600 * 1000 * 24;
				this.endTime=date.getTime();*/
				this.startTime=date.getTime() - 3600 * 1000 * 24 * 30;
				this.endTime=date.getTime()+3600 * 1000 * 24 * 30;
			}else if(timeValue=="1"){//近一周
				this.startTime=date.getTime() - 3600 * 1000 * 24 * 7;
				this.endTime=date.getTime();
			}else if(timeValue=="2"){//三十天
				this.startTime=date.getTime() - 3600 * 1000 * 24 * 30;
				this.endTime=date.getTime();
			}else if(timeValue=="3"){//自定义时间
				this.datePicker=true;
				this.datePick();
			}
			
			this.carChange(1);
			//this.getData()
		},
		datePick(date){//设置自定义时间传值
			let rangeDate=date;
			console.log(rangeDate);
			if(rangeDate){
				this.startTime=rangeDate[0];
				this.endTime=rangeDate[1];
			}
			
		},
		carChange(carValue){//选择车辆趋势筛选条件
			this.carFilter=carValue;
			this.saveParam();
			this.drawLine();
		},
		getData(pageNum,pageSize){
			let data = {
  				params: {
  					startTime: this.$route.query.startTime ? this.$route.query.startTime : '',
  					endTime: this.$route.query.endTime ? this.$route.query.endTime : '',
  					version:this.$route.query.version ? this.$route.query.version : '',
  					channelId: 1,
  					pageNum:pageNum,//当前页
  					pageSize:pageSize//每页条数
  				}
  			};
  			axios.get('/system/statistics/findOverViewStatic', data)
  				.then((res) => {
  					this.carDetailData=res.data.data.list;
  				})
  				.catch(err => {
  					console.log(err);
  				});
		}

	},
	watch: { //监听
		'$route' (to, from) { // 对路由变化作出响应...

		},
	},
	created() { //实例创建之后

	}
}