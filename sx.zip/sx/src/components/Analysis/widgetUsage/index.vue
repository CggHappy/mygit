<template>
	<div class="widgetUsage">
		<div class="all_contain">
			<header class="carVehicleManage">
				<el-breadcrumb separator-class="el-icon-arrow-right">
					<el-breadcrumb-item>统计分析</el-breadcrumb-item>
					<el-breadcrumb-item >Widget使用情况</el-breadcrumb-item>
				</el-breadcrumb>
			</header>
			<div class="carVehicleUse">
				<div class="carVehicleUseTop">
					<div class="carVehicleTitleTab">
                        <div class="radioGroup">
                            <el-radio-group v-model="timeFilter" @change='timeChange'>
                                <el-radio-button label="0">昨天</el-radio-button>
                                <el-radio-button label="1">近一周</el-radio-button>
                                <el-radio-button label="2">最近三十天</el-radio-button>
                                <el-radio-button label="3">自定义时间</el-radio-button>
                            </el-radio-group>
                        </div>
                        <div class="block range" v-if="datePicker">
                            <el-date-picker v-model="valueRange" type="daterange" start-placeholder="开始日期"
                                            end-placeholder="结束日期" align="right" range-separator="~" @change="datePick" format="yyyy 年 MM 月 dd 日" value-format="yyyy-MM-dd">
                            </el-date-picker>
                        </div>
					</div>
				</div>
				<div class="themeUseMain">
					<div class="carVersion">
						<div class="selectModel">
							<label class="channel">渠道：</label>
							<el-select clearable v-model="channel" placeholder="请选择" @focus='getCarOptions'>
								<el-option v-for="item in channelData" :key="item.id" :label="item.name" :value="item.id">
								</el-option>
							</el-select>
						</div>
						<div class="selectModel">
							<label class="channel">版本选择：</label>
							<el-select clearable v-model="version" placeholder="请选择" @focus='getCarOptions'>
                                <el-option v-for="item in versionData " :key="item.id" :label="item.name"  :value="item.id">
								</el-option>
							</el-select>
						</div>
					</div>
				</div>
			</div>
			<div class="carVehicleUse widgetState">
				<div class="carTrendTop">
					<p class="carTrendTitle">Widget使用情况<i class="isIcon">?</i></p>
					<div class="carVehicleTitleTab">
						<el-radio-group v-model="carFilter">
							<el-radio-button label="0">点击次数</el-radio-button>
							<el-radio-button label="1">累计车辆数</el-radio-button>
						</el-radio-group>
					</div>
				</div>
				<div class="carTrendMain">
					<div id="carData" :style="{width: '100%', height: '100%'}"></div>
				</div>
			</div>
			<div class="carDataDetail preview">
				<div class="carDataTop">
					<p class="carTrendTitle">Widget使用概览</p>
					<div class="carVehicleTitleTab">
						 <el-button type="success" class="downExcel">导出excel</el-button>
					</div>
				</div>
				<div class="carTableMain">
					<div class="carTableModel">
						<el-table ref="multipleTable" :data="carDetailData" tooltip-effect="dark" style="width: 100%" @cell-click="cellClick">
							<el-table-column prop="applicationName" label="应用">
								<template slot-scope="scope">
									<span class="tabcolor">{{scope.row.applicationName}}</span>
								</template>
							</el-table-column>
							<el-table-column prop="startUpNum" label="日期内点击次数">
							</el-table-column>
							<el-table-column prop="carNum" label="累计车辆数">
							</el-table-column>
						</el-table>
					</div>
				</div>
			</div>
		</div>
	</div>
</template>
<script src="./index.js">
</script>
<style scoped="scoped" src="./index.less" lang="less">
</style>