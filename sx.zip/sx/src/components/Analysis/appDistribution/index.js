import axios from "@/axios.js";
//import bus from "@/bus.js";
import "./appDistribution.css";
export default {
	data() {
		return {
			carFilter: 0,
			version: "",//版本选择下拉
			channel: "全部",//渠道下拉
			channelData: [{
				name: '全部',
				id: ''
			}],
			versionData: [
				{
					name: '全部',
					id: ''
				}
			],
			currentpage: 1,//当前页
			pageSize: 10,//每页条数
			totalNum: 5,//总条数
			tableData3: [{
				name: '音乐',
				total: '1518',
				totalPer: "30%"
			}, {
				name: '收音机',
				total: '800',
				totalPer: "20%"
			}, {
				name: '天气',
				total: '788',
				totalPer: "20%"
			}, {
				name: '高德',
				total: '800',
				totalPer: "20%"
			}, {
				name: '微信',
				total: '800',
				totalPer: "20%"
			}],//表格数据
			value1: "",//日期
			datePicker: false,//点击自定义显示
			valueRange: "",//自定义时间戳
		}
	},
	mounted() { //实例挂载之后
		this.drawTopLine();

	},
	methods: { //方法
		datePick() { },
		getChannelOptions() {//渠道下拉框

		},
		getVersionOptions() {//版本选择下拉框

		},
		cellClick(row, column, cell, event) {
			if (column.label == "应用") {
				this.$router.push({
					path: "/analysis/apparea/appareaDetail"
				});
			}
		},
		drawTopLine() {
			let topLine = this.$echarts.init(document.getElementById('applyData'));
			let seriesData = [
				{
					name: '图吧导航',
					value: '200',
					percent: '12'
				},
				{
					name: '音乐',
					value: '100',
					percent: '10'
				},
				{
					name: '喜马拉雅FM',
					value: '200',
					percent: '12'
				},
				{
					name: '高德地图',
					value: '200',
					percent: '12'
				},
				{
					name: '音乐',
					value: '200',
					percent: '32'
				},
				{
					name: 'QQ音乐',
					value: '500',
					percent: '23'
				},
				{
					name: '蜻蜓电台',
					value: '500',
					percent: '23'
				},
				{
					name: '喜马拉雅',
					value: '500',
					percent: '23'
				},
				{
					name: '酷狗',
					value: '500',
					percent: '23'
				},
				{
					name: '酷我',
					value: '200',
					percent: '12'
				},
			]
			let yAxisData = ['图吧导航', '音乐', '喜马拉雅FM', '高德地图', '音乐', 'QQ音乐', '蜻蜓电台', '喜马拉雅', '酷狗', '酷我']

			topLine.setOption({
				title: {
					text: '启动次数',
					left: 'center',
					top: '9px',
					textStyle: {
						fontFamily: 'PingFangSC-Semibold',
						fontSize: 18,
						color: '#28324A',
					}
				},
				xAxis: {
					//show:false,
					type: 'value',
					boundaryGap: [0, 0.1, 0.2, 0.3, 0.4],
					splitLine: {
						show: true,
						lineStyle: {
							color: '#E9E9E9',
							type: 'dashed'
						}
					},
					nameTextStyle: {
						fontFamily: 'PingFangSC-Medium',
						fontSize: 14,
						color: '#96969E',
					},
					axisTick: {
						show: false
					},
					axisPointer: {
						lineStyle: {
							color: '#E9E9E9',
							type: 'dashed'
						}
					},
					axisLine: {
						lineStyle: {
							opacity: 1,
							type:'dashed',
							color:'#E9E9E9',
						}
					},
					 axisLabel: {
                            show: true,
                            textStyle: {
                                color: '#7B7B7B'
                            }
                        }
				},
				yAxis: {
					type: 'category',
					data: yAxisData,
					splitLine: {
						show: false,
					},
					axisLine: {
						lineStyle: {
							opacity: 0
						}
					},
					nameTextStyle: {
						fontFamily: 'ArialMT',
						fontSize: 12,
						color: '#96969E',
						textAline: 'center',

					},
					axisTick: {
						show: false
					}
				},
				tooltip: {
					trigger: 'axis',
					axisPointer: {   //阴影指示器
						type: 'shadow'
					},
					formatter: function (params, ticket, callback) {
						//console.log(params[0]);
						let res = '应用：' + params[0].name
							+
							'<br/>' + '启动次数：' + params[0].data.value + '<br/>' + '启动次数占比：' + params[0].data.percent + '%';
						return res;
					},
					backgroundColor: '#FFFFFF',
					textStyle: {
						width: 169,
						height: 100,
						// opacity: 0.6,
						fontSize: 14,
						color: ' #96969E',
						fontFamily: 'PingFangSC-Medium',
						lineHeight: 20,
					}
				},
				series: [
					{
						type: 'bar',
						data: seriesData,
						itemStyle: {
							normal: {
								color: '#E68292',
							},
							emphasis: {
								color: '#FF5570',
							}
						},
						barWidth: 17,
					},
				]
			})//图表
		},
		handleSizeChange() {

		},
		handleCurrentChange() {

		},
		timeChange(value) {//点击时间筛选数据
			if (value == 0) {
				this.datePicker = false
			}
			if (value == 1) {
				this.datePicker = false
			}
			if (value == 2) {
				this.datePicker = false
			}
			if (value == 3) {
				this.datePicker = true
			}

		},
	},
	watch: { //监听
		'$route'(to, from) { // 对路由变化作出响应...

		},
	},
	created() { //实例创建之后

	}
}