import axios from "@/axios.js";
//import bus from "@/bus.js";
import "./appDistribution.css";
import 'echarts/map/js/china.js'
export default {
	data() {
		return {
			carFilter: 0,
			version: "",//版本选择下拉
			channel: "",//渠道下拉
			channelData: [{
				name: '全部',
				id: ''
			}],
			versionData: [
				{
					name: '全部',
					id: ''
				}
			],
			currentpage: 1,//当前页
			pageSize: 10,//每页条数
			totalNum: 5,//总条数
			tableData3: [{
				name: '音乐',
				total: '1518',
				totalPer: "30%"
			}, {
				name: '收音机',
				total: '800',
				totalPer: "20%"
			}, {
				name: '天气',
				total: '788',
				totalPer: "20%"
			}, {
				name: '高德',
				total: '800',
				totalPer: "20%"
			}, {
				name: '微信',
				total: '800',
				totalPer: "20%"
			}],//表格数据
			value1: "",//日期
			datePicker: false,//点击自定义显示
			valueRange: "",//自定义时间戳
			progressData: [
				{ id: 1, name: "安徽", value: 120, percent: 15.79 },
				{ id: 2, name: "青海", value: 120, percent: 15.79 },
				{ id: 3, name: "山西", value: 120, percent: 12.53 },
				{ id: 4, name: "江苏", value: 120, percent: 11.26 },
				{ id: 5, name: "宁夏", value: 120, percent: 8.26 },
				{ id: 6, name: "福建", value: 120, percent: 7.26 },
				{ id: 7, name: "河南", value: 120, percent: 6.26 },
				{ id: 8, name: "河北", value: 120, percent: 5.26 },
				{ id: 9, name: "天津", value: 120, percent: 5.26 },
			],//progress数据
		}
	},
	mounted() { //实例挂载之后
		this.drawTopLine();
		this.drawMusic();
	},
	methods: { //方法
		jumpRouter() {
			this.$router.push({
				path: "/analysis/apparea/index"
			});
		},
		datePick() { },
		timeChange(value) {//点击时间筛选数据
			if (value == 0) {
				this.datePicker = false
			}
			if (value == 1) {
				this.datePicker = false
			}
			if (value == 2) {
				this.datePicker = false
			}
			if (value == 3) {
				this.datePicker = true
			}

		},
		getChannelOptions() {//渠道下拉框

		},
		getVersionOptions() {//版本选择下拉框

		},
		drawTopLine() {
			let topLine = this.$echarts.init(document.getElementById('applyData'));
			let seriesData = [
				{
					name: '图吧导航',
					value: '200',
					percent: '12'
				},
				{
					name: '音乐',
					value: '100',
					percent: '10'
				},
				{
					name: '喜马拉雅FM',
					value: '200',
					percent: '12'
				},
				{
					name: '高德地图',
					value: '200',
					percent: '12'
				},
				{
					name: '音乐',
					value: '200',
					percent: '32'
				},
				{
					name: 'QQ音乐',
					value: '500',
					percent: '23'
				},
				{
					name: '蜻蜓电台',
					value: '500',
					percent: '23'
				},
				{
					name: '喜马拉雅',
					value: '500',
					percent: '23'
				},
				{
					name: '酷狗',
					value: '500',
					percent: '23'
				},
				{
					name: '酷我',
					value: '200',
					percent: '12'
				},
			]
			let yAxisData = ['图吧导航', '音乐', '喜马拉雅FM', '高德地图', '音乐', 'QQ音乐', '蜻蜓电台', '喜马拉雅', '酷狗', '酷我']

			topLine.setOption({
				title: {
					text: '启动次数',
					left: 'center',
					top: '9px',
					textStyle: {
						fontFamily: 'PingFangSC-Semibold',
						fontSize: 18,
						color: '#28324A',
					},
				},
				xAxis: {
					//show:false,
					type: 'value',
					boundaryGap: [0, 0.1, 0.2, 0.3, 0.4],
					splitLine: {
						show: true,
						lineStyle: {
							color: '#E9E9E9',
							type: 'dashed'
						}
					},
					nameTextStyle: {
						fontFamily: 'PingFangSC-Medium',
						fontSize: 14,
						color: '#96969E',
					},
					axisTick: {
						show: false
					},
					axisPointer: {
						lineStyle: {
							color: '#E9E9E9',
							type: 'dashed'
						}
					},
					axisLine: {
						lineStyle: {
							opacity: 1,
							type:'dashed',
							color:'#E9E9E9',
						}
					},
					 axisLabel: {
                            show: true,
                            textStyle: {
                                color: '#7B7B7B'
                            }
                        }
				},
				yAxis: {
					type: 'category',
					data: yAxisData,
					splitLine: {
						show: false,
					},
					axisLine: {
						lineStyle: {
							opacity: 0
						}
					},
					nameTextStyle: {
						fontFamily: 'ArialMT',
						fontSize: 12,
						color: '#96969E',
						textAline: 'center',

					},
					axisTick: {
						show: false
					}
				},
				tooltip: {
					trigger: 'axis',
					axisPointer: {   //阴影指示器
						type: 'shadow'
					},
					formatter: function (params, ticket, callback) {
						//console.log(params[0]);
						let res = '应用：' + params[0].name
							+
							'<br/>' + '启动次数：' + params[0].data.value + '<br/>' + '启动次数占比：' + params[0].data.percent + '%';
						return res;
					},
					backgroundColor: '#FFFFFF',
					textStyle: {
						width: 169,
						height: 100,
						// opacity: 0.6,
						fontSize: 14,
						color: ' #96969E',
						fontFamily: 'PingFangSC-Medium',
						lineHeight: 20,
					}
				},
				series: [
					{
						type: 'bar',
						data: seriesData,
						itemStyle: {
							normal: {
								color: '#E68292',
							},
							emphasis: {
								color: '#FF5570',
							}
						},
						barWidth: 17,
					},
				]
			})//图表
		},
		drawMusic() {
			let geoCoordMap = [
				{ name: "新疆", cp: [84.9023, 41.748] },
				{ name: "内蒙古", cp: [117.5977, 44.3408] },
				{ name: "青海", cp: [96.2402, 35.4199] },
				{ name: "四川", cp: [102.9199, 30.1904] },
				{ name: "黑龙江", cp: [128.1445, 48.5156] },
				{ name: "甘肃", cp: [95.7129, 40.166] },
				{ name: "云南", cp: [101.8652, 25.1807] },
				{ name: "广西", cp: [108.2813, 23.6426] },
				{ name: "湖南", cp: [111.5332, 27.3779] },
				{ name: "陕西", cp: [109.5996, 35.6396] },
				{ name: "广东", cp: [113.4668, 22.8076] },
				{ name: "吉林", cp: [126.4746, 43.5938] },
				{ name: "河北", cp: [115.4004, 37.9688] },
				{ name: "湖北", cp: [112.2363, 31.1572] },
				{ name: "贵州", cp: [106.6113, 26.9385] },
				{ name: "山东", cp: [118.7402, 36.4307] },
				{ name: "江西", cp: [116.0156, 27.29] },
				{ name: "河南", cp: [113.4668, 33.8818] },
				{ name: "辽宁", cp: [122.3438, 41.0889] },
				{ name: "山西", cp: [112.4121, 37.6611] },
				{ name: "安徽", cp: [117.2461, 32.0361] },
				{ name: "福建", cp: [118.3008, 25.9277] },
				{ name: "浙江", cp: [120.498, 29.0918] },
				{ name: "江苏", cp: [120.0586, 32.915] },
				{ name: "重庆", cp: [107.7539, 30.1904] },
				{ name: "宁夏", cp: [105.9961, 37.3096] },
				{ name: "海南", cp: [109.9512, 19.2041] },
				{ name: "台湾", cp: [121.0254, 23.5986] },
				{ name: "北京", cp: [116.4551, 40.2539] },
				{ name: "天津", cp: [117.4219, 39.4189] },
				{ name: "上海", cp: [121.4648, 31.2891] },
				{ name: "香港", cp: [114.2578, 22.3242] },
				{ name: "澳门", cp: [113.5547, 22.1484] }
			];
			let data = [
				{ name: "新疆", value: 120, percent: 12 },
				{ name: "内蒙古", value: 130, percent: 13 },
				{ name: "青海", value: 240, percent: 24 },
				{ name: "四川", value: 225, percent: 22.5 },
				{ name: "黑龙江", value: 330, percent: 33 },
				{ name: "甘肃", value: 200, percent: 20 },
				{ name: "云南", value: 340, percent: 34 },
				{ name: "广西", value: 220, percent: 22 },
				{ name: "湖南", value: 124, percent: 12.4 },
				{ name: "陕西", value: 450, percent: 45 },
				{ name: "广东", value: 232, percent: 23.2 },
				{ name: "吉林", value: 133, percent: 13.3 },
				{ name: "河北", value: 443, percent: 44.3 },
				{ name: "湖北", value: 421, percent: 42.1 },
				{ name: "贵州", value: 330, percent: 33 },
				{ name: "山东", value: 290, percent: 29 },
				{ name: "江西", value: 330, percent: 33 },
				{ name: "河南", value: 340, percent: 34 },
				{ name: "辽宁", value: 445, percent: 44.5 },
				{ name: "山西", value: 223, percent: 22.3 },
				{ name: "安徽", value: 124, percent: 12.4 },
				{ name: "福建", value: 231, percent: 23.1 },
				{ name: "浙江", value: 434, percent: 43.4 },
				{ name: "江苏", value: 327, percent: 32.7 },
				{ name: "重庆", value: 260, percent: 26 },
				{ name: "宁夏", value: 200, percent: 20 },
				{ name: "海南", value: 320, percent: 32 },
				{ name: "台湾", value: 240, percent: 24 },
				{ name: "北京", value: 248, percent: 24.8 },
				{ name: "天津", value: 330, percent: 33 },
				{ name: "上海", value: 235, percent: 23.5 },
				{ name: "香港", value: 339, percent: 33.9 },
				{ name: "澳门", value: 330, percent: 33 },
				{ name: "西藏", value: 130, percent: 13 },
			];
			let applyData1 = this.$echarts.init(document.getElementById('applyData1'));
			applyData1.setOption({
				geo: {
					type: 'map',
					map: 'china',

				},
				visualMap: {
					min: 0,
					max: 500,
					text: ['高', '低'],
					calculable: true
				},
				tooltip: {
					formatter: function (params, ticket, callback) {
						let res = '地区：' + params.data.name
							+
							'<br/>' + '启动次数：' + params.data.value + '<br/>' + '启动次数占比：' + params.data.percent + '%';
						return res;
					},
					backgroundColor: '#FFFFFF',
					textStyle: {
						width: 169,
						height: 150,
						// opacity: 0.6,
						fontSize: 14,
						color: ' #96969E',
						fontFamily: 'PingFangSC-Medium',
						lineHeight: 20,
					}
				},
				series: [
					{
						name: '',
						type: 'map',
						mapType: 'china',
						label: {
							normal: {
								show: true,//显示省份标签
								textStyle: { color: "black" }//省份标签字体颜色
							},
							emphasis: {//对应的鼠标悬浮效果
								show: true,
								textStyle: { color: "#800080" }
							}
						},
						data: data,
					}
				],
			})

		},
		handleSizeChange() {

		},
		handleCurrentChange() {

		},

		randomData() {
			return Math.round(Math.random() * 2500);
		},

		/**
		 * 根据值获取线性渐变颜色
		 * @param  {String} start 起始颜色
		 * @param  {String} end   结束颜色
		 * @param  {Number} max   最多分成多少分
		 * @param  {Number} val   渐变取值
		 * @return {String}       颜色
		 */
		getGradientColor(start, end, max, val) {
			var rgb = /#((?:[0-9]|[a-fA-F]){2})((?:[0-9]|[a-fA-F]){2})((?:[0-9]|[a-fA-F]){2})/;
			var sM = start.match(rgb);
			var eM = end.match(rgb);
			var err = '';
			max = max || 1
			val = val || 0
			if (sM === null) {
				err = 'start';
			}
			if (eM === null) {
				err = 'end';
			}
			if (err.length > 0) {
				throw new Error('Invalid ' + err + ' color format, required hex color');
			}
			var sR = parseInt(sM[1], 16),
				sG = parseInt(sM[2], 16),
				sB = parseInt(sM[3], 16);
			var eR = parseInt(eM[1], 16),
				eG = parseInt(eM[2], 16),
				eB = parseInt(eM[3], 16);
			var p = val / max;
			var gR = Math.round(sR + (eR - sR) * p).toString(16),
				gG = Math.round(sG + (eG - sG) * p).toString(16),
				gB = Math.round(sB + (eB - sB) * p).toString(16);
			return '#' + gR + gG + gB;
		},


	},
	watch: { //监听
		'$route'(to, from) { // 对路由变化作出响应...

		},
	},
	created() { //实例创建之后

	}
}