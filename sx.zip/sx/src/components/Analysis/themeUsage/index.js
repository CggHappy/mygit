import axios from "@/axios.js";
//import bus from "@/bus.js";
import './themeUsage.css'
export default {
	data() {
		return {
      channel:'',
      channelData:[
          {
              name:'全部',
              id:''
          }
      ], //渠道
      version:'',
      versionData:[
          {
              name:'全部',
              id:''
          }
      ], //版本
      timeFilter:0,// 默认选中   label值
      lineFilter:1,
      currentpage:1,//当前页
      pageSize:10,//每页条数
      totalNum:1,//总条数
      tableData:[
        {
          themeId:'33444',
          themeClass:'会员专属',
          themeName:'长草颜',
           count:'90',
          time:'89.6',
          totalCar:'900'

        }
      ],//表格数据

      datePicker:false,//点击自定义显示
      valueRange:"",//自定义时间戳
		}
	},
	mounted() { //实例挂载之后
    this.drawTopLine();

	},
	methods: { //方法
    drawTopLine(){
      let themeLineData = this.$echarts.init(document.getElementById('themeLineData'));

      let seriesData = [
        {
          name:'主题1',
          value:'2000',
          percent:'12'
        },
        {
          name:'主题2',
          value:'3000',
          percent:'30'
        },
        {
          name:'经典',
          value:'1000',
          percent:'10'
        },
        {
          name:'扁平风格',
          value:'2060',
          percent:'12'
        },
        {
          name:'蓝色星球',
          value:'3000',
          percent:'12'
        },
      ]
      let yAxisData = ['主题1','主题2','经典','扁平风格','蓝色星球']
      //let yAxisData = this.yAxisData;

      themeLineData.setOption({
        title:{

        },
        xAxis: {
          //show:false,
          type: 'value',
          boundaryGap: [0, 1,2,3,4],
          splitLine:{
            show:true,
            lineStyle: {
							color: '#E9E9E9',
							type: 'dashed'
						}
          },
          nameTextStyle:{
            fontFamily: 'PingFangSC-Medium',
            fontSize: 14,
            color: '#96969E',
          },
            axisTick: {
                show: false
            },
              axisPointer: {
						lineStyle: {
							color: '#E9E9E9',
							type: 'dashed'
						}
          },
          axisLine: {
						lineStyle: {
							opacity: 1,
							type:'dashed',
							color:'#E9E9E9',
						}
					},
					 axisLabel: {
                            show: true,
                            textStyle: {
                                color: '#7B7B7B'
                            }
                        }
        },
        yAxis: {
          type: 'category',
          data: yAxisData,
          splitLine:{
            show:false,
          },
          axisLine: {
						lineStyle: {
							opacity: 0
						}
					},
          nameTextStyle:{
            fontFamily: 'ArialMT',
            fontSize: 12,
            color: '#96969E',
            textAline: 'center',

          },
            axisTick: {
                show: false
            },
        },
        tooltip:{
          trigger: 'axis',
          axisPointer: {   //阴影指示器
            type: 'shadow'
          },
          formatter: function(params, ticket, callback) {
            //console.log(params[0]);
            let res = '主题：' + params[0].name
              +
              '<br/>' + '使用次数：' + params[0].data.value ;
            return res;
          },
          backgroundColor: '#FFFFFF',
          textStyle: {
            width: 169,
            height: 100,
            // opacity: 0.6,
            fontSize: 14,
            color: ' #96969E',
            fontFamily: 'PingFangSC-Medium',
            lineHeight: 20,
          }
        },

        series: [
          {
            type:'bar',
            data:seriesData,
            itemStyle: {
							normal: {
								color: '#E68292',
							},
							emphasis: {
								color: '#FF5570',
							}
						},
            barWidth:20,
          },
        ]
      })
      // axios.get('/system')
      //   .then(res=>{
      //     topLine.setOption({
      //       yAxisData:{
      //         data:res.data.data
      //       },
      //       series:[
      //         {
      //           type:'bar',
      //           data:res.data.list,
      //           itemStyle:{
      //             normal:{
      //               color:'pink',
      //             }
      //           },
      //           barWidth:10,
      //         },
      //       ]
      //     })
      //   })
    },

    handleSizeChange(){

    },
    handleCurrentChange(){

    },
    timeChange(value){//点击时间筛选数据
            if(value==0){
                this.datePicker = false
            }
            if(value==1){
                this.datePicker = false
            }
            if(value==2){
                this.datePicker = false
            }
            if(value==3){
                this.datePicker = true
            }

        },
    datePick(){},

	},
	watch: { //监听
		'$route' (to, from) { // 对路由变化作出响应...

		},
	},
	created() { //实例创建之后

	}
}
