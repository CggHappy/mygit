<template>
	<div class="themeUsage">
    <div class="all_contain">
      <header class="carVehicleManage">
        <el-breadcrumb separator-class="el-icon-arrow-right">
          <el-breadcrumb-item>统计分析</el-breadcrumb-item>
          <el-breadcrumb-item>主题使用统计</el-breadcrumb-item>
        </el-breadcrumb>
      </header>

      <div class="carVehicleUse">
        <div class="carVehicleUseTop">
          <div class="carVehicleTitleTab">
              <div class="radioGroup">
                  <el-radio-group v-model="timeFilter" @change='timeChange'>
                      <el-radio-button label="0">昨天</el-radio-button>
                      <el-radio-button label="1">近一周</el-radio-button>
                      <el-radio-button label="2">最近三十天</el-radio-button>
                      <el-radio-button label="3">自定义时间</el-radio-button>
                  </el-radio-group>
              </div>
              <div class="block range" v-if="datePicker">
                  <el-date-picker v-model="valueRange" type="daterange" start-placeholder="开始日期"
                                  end-placeholder="结束日期" align="right" range-separator="~" @change="datePick" format="yyyy 年 MM 月 dd 日" value-format="yyyy-MM-dd">
                  </el-date-picker>
              </div>
          </div>
        </div>
        <div class="themeUseMain">
          <div class="carVersion">
            <div class="selectModel">
              <label class="channel">渠道：</label>
              <el-select clearable v-model="channel" placeholder="请选择" >
                <el-option v-for="item in channelData" :key="item.id" :label="item.name" :value="item.id">
                </el-option>
              </el-select>
            </div>
            <div class="selectModel">
              <label class="channel">版本选择：</label>
              <el-select clearable v-model="version" placeholder="请选择">
                <el-option v-for="item in versionData" :key="item.id" :label="item.name" :value="item.id">
                </el-option>
              </el-select>
            </div>
          </div>
        </div>
      </div>

      <div class="carVehicleUse appApply">
        <div class="carTrendTop">
          <p class="carTrendTitle">主题使用统计TOP5 <i class="isIcon">?</i></p>
          <div class="carVehicleTitleTab">
            <el-radio-group v-model="lineFilter" >
              <el-radio-button label="1">使用次数</el-radio-button>
              <el-radio-button label="2">平均使用时长</el-radio-button>
              <el-radio-button label="3">累计车辆</el-radio-button>
            </el-radio-group>
          </div>
        </div>

        <div class="carTrendMain">
          <div id="themeLineData" :style="{width: '100%', height: '100%'}"></div>
        </div>
      </div>

      <div class="carDataDetail preview">
        <div class="carDataTop">
          <p class="carTrendTitle">主题使用统计</p>
          <div class="carVehicleTitleTab">
            <el-button class="exportBtn">导出excel</el-button>
          </div>
        </div>
        <div class="carTableMain">
          <div class="carTableModel">
            <el-table ref="multipleTable" :data="tableData" tooltip-effect="dark" style="width: 100%">
              <el-table-column prop="themeId" label="主题ID">
              </el-table-column>
              <el-table-column prop="themeClass" label="主题分类">
              </el-table-column>
              <el-table-column prop="themeName" label="主题名称">
              </el-table-column>
              <el-table-column prop="count" label="日期内使用次数">
              </el-table-column>
              <el-table-column prop="time" label="平均单次使用时长(h)">
              </el-table-column>
              <el-table-column prop="totalCar" label="累计车辆">
              </el-table-column>
            </el-table>
          </div>
          <div class="tableFooter">
            <div class="widgetTabRecord">
              <span>共<span class="spantotal" v-model="totalNum">{{totalNum}}</span>条数据，每页<span class="spansize">{{pageSize}}</span>条</span>
            </div>
            <div class="widgetTabFoot">
              <div class="widgetPage">
                <el-pagination
                  @size-change="handleSizeChange"
                  @current-change="handleCurrentChange"
                  :current-page.sync="currentpage"
                  :page-size=pageSize
                  layout="prev, pager, next, jumper"
                  :total=totalNum>
                </el-pagination>
              </div>
              <button type="button" class="el-button el-button--primary btnSearch btn_s">确定</button>
            </div>
          </div>
        </div>
      </div>


    </div>
  </div>
</template>
<script src="./index.js">
</script>
<style scoped="scoped" src="./index.less" lang="less">
</style>
