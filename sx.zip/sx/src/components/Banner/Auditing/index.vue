<template>
	<div class="Auditing">广告审核</div>
</template>
<script src="./index.js">
</script>
<style scoped="scoped" src="./index.less" lang="less">
</style>