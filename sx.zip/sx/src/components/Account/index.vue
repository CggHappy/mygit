<template>
	<div class="account">
    <div class="all_contain">
      <div v-if="addBtn">
        <div class="channelTop">
          <p class="channelTopTitle">账户授权</p>
        </div>
        <div class="addTip" >
          <div class="tipMain">
            <p class="tipTitle">请添用户后，再对用户权限进行管理</p>
            <p class="addBtn">
              <el-button type="primary" icon="el-icon-plus" @click="addChannel">添加</el-button>
            </p>
          </div>
        </div>
      </div>

      <div class="channelData"  v-if="!addBtn">
        <div class="channelTop">
          <p class="channelTopTitle">账号授权</p>
          <div class="channelTopBtn">
              <p class="topbtn">
                <el-button type="primary" icon="el-icon-plus" @click="addChannel" v-if="addFlag">添加</el-button>
                <button type="button" v-if="deleBtnIS" class="el-button el-button--primary btnSearch btnBox" style="background:#84A1E5" @click="accountEdit">编辑</button>
              </p>
              <div class="saveBox" v-if="saveCancel">
                <el-button type="button" class="el-button el-button--primary btnSearch btnBox" style="background:#84A1E5" @click="accountSave" :loading="loadingB">保存</el-button>
                <el-button @click="cannelAccount">取消</el-button>
              </div>
          </div>
        </div>
        <div class="channelTab" v-loading='pageLoad'>
          <div class="channeTable">
            <el-table :data="accountTabData" style="width: 100%" ref="multipleTable" @cell-click="cellClick">


              <el-table-column label="账号" @cell-mouse-enter="cellHover">
                <template slot-scope="scope">
                  <!--<p class="channelImg"><img :src="scope.row.img"/></p>-->
                  <p class="channelName" >{{scope.row.userName}}</p>
                </template>
              </el-table-column>

              <el-table-column v-if="themeShow" prop="" label="主题管理">
                <template slot-scope="scope">
                  <el-dropdown :hide-on-click="false" trigger="click" @command="handleCommand">
                    <el-button class="selectAuth">
                      -<i class="el-icon-caret-bottom el-icon--right"></i>
                    </el-button>
                    <el-dropdown-menu slot="dropdown">
                      <div v-for="item in scope.row.themeManage.list" :key="item.id" class="dropdownAuth">
                        <el-dropdown-item :command="item" :disabled="btnsDisabled" style="display: flex;justify-content: space-between">
                          <span >{{ item.label }}</span>
                          <span style=" color: #8492a6; font-size: 13px">
                            <i :class="item.checked?'el-icon-check':'el-icon-close'"  style="color:#67c23a" ></i>
                          </span>
                        </el-dropdown-item>
                      </div>
                    </el-dropdown-menu>
                  </el-dropdown>
                </template>
              </el-table-column>
              <el-table-column v-if="applicationShow" prop="" label="应用管理">
                <template slot-scope="scope">
                  <el-dropdown :hide-on-click="false" trigger="click" @command="handleCommand">
                    <el-button class="selectAuth">
                      -<i class="el-icon-caret-bottom el-icon--right"></i>
                    </el-button>
                    <el-dropdown-menu slot="dropdown">
                      <div v-for="item in scope.row.applicationManage.list" :key="item.id" class="dropdownAuth">
                        <el-dropdown-item :command="item" :disabled="btnsDisabled" style="display: flex;justify-content: space-between">
                          <span >{{ item.label }}</span>
                          <span style=" color: #8492a6; font-size: 13px">
                            <i :class="item.checked?'el-icon-check':'el-icon-close'"  style="color:#67c23a"></i>
                          </span>
                        </el-dropdown-item>
                      </div>
                    </el-dropdown-menu>
                  </el-dropdown>
                </template>
              </el-table-column>
              <el-table-column v-if="widgetShow" prop="" label="widget管理">
                    <template slot-scope="scope">
                        <el-dropdown :hide-on-click="false" trigger="click" @command="handleCommand">
                            <el-button class="selectAuth">
                                -<i class="el-icon-caret-bottom el-icon--right"></i>
                            </el-button>
                            <el-dropdown-menu slot="dropdown">
                                <div v-for="item in scope.row.widgetManage.list" :key="item.id" class="dropdownAuth">
                                    <el-dropdown-item :command="item" :disabled="btnsDisabled" style="display: flex;justify-content: space-between">
                                        <span>{{ item.label }}</span>
                                        <span style=" color: #8492a6; font-size: 13px">
                            <i :class="item.checked?'el-icon-check':'el-icon-close'"  style="color:#67c23a" ></i>
                          </span>
                                    </el-dropdown-item>
                                </div>
                            </el-dropdown-menu>
                        </el-dropdown>
                    </template>
                </el-table-column>
              <el-table-column v-if="channelshow" prop="" label="渠道管理">
                <template slot-scope="scope">
                  <el-dropdown :hide-on-click="false" trigger="click" @command="handleCommand">
                    <el-button class="selectAuth">
                       -<i class="el-icon-caret-bottom el-icon--right"></i>
                    </el-button>
                    <el-dropdown-menu slot="dropdown">
                      <div v-for="item in scope.row.channelManage.list" :key="item.id" class="dropdownAuth">
                        <el-dropdown-item :command="item" :disabled="btnsDisabled" style="display: flex;justify-content: space-between">
                          <span >{{ item.label }}</span>
                          <span style=" color: #8492a6; font-size: 13px">
                            <i :class="item.checked?'el-icon-check':'el-icon-close'"  style="color:#67c23a" ></i>
                          </span>
                        </el-dropdown-item>
                      </div>
                    </el-dropdown-menu>
                  </el-dropdown>
                </template>

              </el-table-column>
              <el-table-column v-if="accountShow" prop="" label="账号授权">
                    <template slot-scope="scope">
                        <el-dropdown :hide-on-click="false" trigger="click" @command="handleCommand">
                            <el-button class="selectAuth">
                                -<i class="el-icon-caret-bottom el-icon--right"></i>
                            </el-button>
                            <el-dropdown-menu slot="dropdown">
                                <div v-for="item in scope.row.accountMange.list" :key="item.id" class="dropdownAuth">
                                    <el-dropdown-item :command="item" :disabled="btnsDisabled" style="display: flex;justify-content: space-between">
                                        <span >{{ item.label }}</span>
                                        <span style=" color: #8492a6; font-size: 13px">
                            <i :class="item.checked?'el-icon-check':'el-icon-close'"  style="color:#67c23a" ></i>
                          </span>
                                    </el-dropdown-item>
                                </div>
                            </el-dropdown-menu>
                        </el-dropdown>
                    </template>

                </el-table-column>
              <el-table-column v-if="statisticalShow" prop="" label="统计分析">
                    <template slot-scope="scope">
                        <el-dropdown :hide-on-click="false" trigger="click"  @command="handleCommand">
                            <el-button class="selectAuth">
                                -<i class="el-icon-caret-bottom el-icon--right"></i>
                            </el-button>
                            <el-dropdown-menu slot="dropdown">
                                <div v-for="item in scope.row.statisticalManage.list" :key="item.id" class="dropdownAuth">
                                    <el-dropdown-item :command="item"   :disabled="btnsDisabled" style="display: flex;justify-content: space-between" >
                                        <span >{{ item.label }}</span>
                                        <span style=" color: #8492a6; font-size: 13px">
                            <i :class="item.checked?'el-icon-check':'el-icon-close'"  style="color:#67c23a" ></i>
                          </span>
                                    </el-dropdown-item>
                                </div>
                            </el-dropdown-menu>
                        </el-dropdown>
                    </template>
                </el-table-column>
              <el-table-column v-if="operationLogShow" prop="" label="运维日志">
                <template slot-scope="scope">
                  <el-dropdown :hide-on-click="false" trigger="click" @command="handleCommand">
                    <el-button class="selectAuth">
                      -<i class="el-icon-caret-bottom el-icon--right"></i>
                    </el-button>
                    <el-dropdown-menu slot="dropdown">
                      <div v-for="item in scope.row.operationLog.list" :key="item.id" class="dropdownAuth">
                        <el-dropdown-item :command="item" :disabled="btnsDisabled" style="display: flex;justify-content: space-between">
                          <span >{{ item.label }}</span>
                          <span style=" color: #8492a6; font-size: 13px">
                            <i :class="item.checked?'el-icon-check':'el-icon-close'"  style="color:#67c23a" ></i>
                          </span>
                        </el-dropdown-item>
                      </div>
                    </el-dropdown-menu>
                  </el-dropdown>
                </template>

              </el-table-column>
              <el-table-column prop="" label="操作" v-if="operate">
                <template slot-scope="scope">
                  <el-button size="mini" class='greenBox' @click="getMore(scope.$index, scope.row)" v-if="editFlag">更多</el-button>
                  <el-button size="mini" type="danger"  @click="deleteRow(scope.$index, scope.row)" v-if="deleteFlag" :disabled="btnsDisabled">删除</el-button>
                </template>
              </el-table-column>
            </el-table>

            <div class="tableFooter" v-if="isShowPagination">
              <div class="widgetTabRecord">
                <span>共<span class="spantotal">{{totalNum}}</span>条数据，每页<span class="spansize">10</span>条</span>
              </div>
              <div class="widgetTabFoot">
                <div class="widgetPage">
                  <el-pagination
                    @size-change="handleSizeChange"
                    @current-change="handleCurrentChange"
                    :current-page="pageNum"
                    :page-size="pageSize"
                    layout="prev, pager, next, jumper"
                    :total="totalNum">
                  </el-pagination>
                </div>
                <button type="button" class="el-button el-button--primary btnSearch btn_s"  >确定</button>
              </div>
            </div>

            <div class="bg" :style="{top:top+'px'}" v-if="boxIsshow">
              保存后删除即生效,<span @click="canccelDel" class="resizeDelete">撤销删除</span>
            </div>
          </div>
        </div>
      </div>
    </div>
	</div>
</template>
<script src="./index.js">
</script>
<style scoped="scoped" src="./index.less" lang="less">
</style>
