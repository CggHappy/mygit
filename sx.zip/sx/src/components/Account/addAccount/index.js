import axios from "@/axios.js";
//import bus from "@/bus.js";
import "./addAccount.css";

export default {
    data() {
        var validateUser = (rule, value, callback) => {
            let valid = false;
            if (value == this.editUserName) {
                callback();
            }
            if (this.editFlag && this.listPermissions.length == 0) {
                valid = true;
                this.editFlag = false;
            } else {
                for (let i = 0; i < this.listPermissions.length; i++) {
                    if (this.listPermissions[i] == value) {
                        valid = true;
                        break
                    }
                }
            }
            if (valid) {
                callback()
            } else {
                callback(new Error('请选择正确的授权账号'))
            }
        };
        return {
            ruleForm: {
                userName: '', //账号
                channelName: '', //渠道名称
                Remarks: '', //备注
                listPermissions: [] ,//权限列表
            },
            rules: {
                userName: [
                    { required: true, message: '账号不能为空', trigger: 'change' }, {
                        validator: validateUser,
                        trigger: 'change'
                    }
                ],
                Remarks: [
                    { required: true, message: '备注不能为空', trigger: 'blur' },
                    {
                        pattern: /^(?!_)(?!.*?_$)[a-zA-Z0-9_\u4e00-\u9fa5]+$/,
                        message: '只能输入中文、英文、下划线、数字',
                        trigger: 'blur'
                    },
                    {
                        min: 1,
                        max: 100,
                        message: '长度小于100个字符',
                        trigger: 'blur'
                    },
                ],
                channelName: [{ required: true, message: '请选择渠道', trigger: 'change' }],
            },
            trench: [], //渠道列表
            jurisdictionList: [], //权限列表
            titleContainer: "", //判断显示编辑或新增
            listPermissions: [],
            searchData: [],
            userId: '',
            loadingB: false,
            editDisabeld:true,//如果为编辑页，授权账号和下拉框不可编辑
            id:'',//渠道id
            editFlag: false,
            editUserName:'',
        }
    },
    mounted() { //实例挂载之后
        this.routeIs();
        this.loadData(); //获取权限列表的数据
        this.isEdit();
    },
    methods: { //方法
        //获取权限列表的数据
        loadData() {
            axios.get('auth/permissions/findPermissionsByUser')
                .then(res => {
                    this.jurisdictionList = res.data.data;
                })
                .catch(err => {
                    console.log('获取列表失败')
                })
        },
         isEdit(){
            let edit=this.$route.path;
            if(edit.indexOf("editaccount")>0){
                this.editDisabeld=true
            }else{
                this.editDisabeld=false
            }
        },

        //获取渠道
        getChannelData() {
            axios.post('auth/accountNumber/selectAccountList', {
                    id: this.userId
                })
                .then(res => {
                    this.trench = res.data.data.list;
                    //console.log(res)
                    for(let i = 0; i<this.trench.length; i++){
                        if(res.data.data.select == this.trench[i].name){
                            this.ruleForm.channelName = this.trench[i].id
                            this.id = this.trench[i].id
                        }
                    }
                })
                .catch(err => {
                    console.log('失败')
                })
        },
        //下拉渠道选中
        changeSelect(value){
            //console.log(value)
            this.id = value
        },
        //编辑和添加状态切换
        routeIs() { //判断编辑或新增
            let path = this.$route.path;
            if (path.indexOf("editaccount") > 1) {
                this.titleContainer = "编辑成员授权";
                //读取信息,显示
                let data = {
                    id: sessionStorage.getItem('id'),
                };
                axios.post('auth/accountNumber/selectById', { id: sessionStorage.getItem('id') })
                    .then(res => {
                        this.editFlag = true;
                        this.editUserName = res.data.data.userName;
                        this.id = res.data.data.channelId;
                        this.ruleForm.userName = res.data.data.userName;
                        this.ruleForm.channelName = res.data.data.channelName;
                        this.ruleForm.Remarks = res.data.data.remarks;
                        this.userId = res.data.data.id;
                        for (let itemList of res.data.data.listPermissions) {
                            for (let item of itemList.listPermissions) {
                                if (item.chooseType == 1) {
                                    this.ruleForm.listPermissions.push(item.id)
                                }

                            }
                        }
                    })
                    .catch(err => {
                        console.log('读取信息失败')
                    })
            } else if (path.indexOf("addaccount")) {
                this.titleContainer = "添加成员授权";
                this.getChannelData(); //获取渠道
            }
        },

        //保存按钮
        submitForm(formName) {
            this.$refs[formName].validate((valid) => {
                if (valid) {
                    if(this.ruleForm.listPermissions.length==0){
                        this.$message.error('权限未勾选');
                        return
                    }
                    this.loadingB = true;
                    let type = '';
                    if(this.$route.path.indexOf("addaccount") > 1){
                        type = '1';
                    }
                    let str = {
                        user: {
                            id: this.userId,
                            channelId: this.id,
                            remarks: this.ruleForm.Remarks,

                        },
                        permissions: this.ruleForm.listPermissions
                    };
                    let data = {
                        type:type,
                        str: JSON.stringify(str)
                    };
                    axios.post('auth/accountNumber/saveAccount', data)
                        .then(res => {
                            this.$message.success('保存信息成功');
                            this.resetForm(formName);
                            this.loadingB = false;
                        })
                        .catch(err => {
                            console.log('保存信息失败')
                        })
                } else {
                    console.log('error submit!!');
                    return false;
                }

            });
        },

        //取消按钮
        resetForm(formName) {
            this.$refs[formName].resetFields();
            this.$router.push({
                path: "/account/index"
            })
        },

        //搜索下拉
        querySearch(queryString, callback) {
            let searchData = this.searchData;
            let results = queryString ? searchData.filter(this.createFilter(queryString)) : searchData;
            let data = {
                params:{
                    type:1,
                    userName:this.ruleForm.userName
                }
            };
            axios.get('auth/accountNumber/findUserByLike',data)
                .then(res => {
                  if(this.searchData.length == 0){
                    for (let i = 0; i < res.data.data.length; i++) {
                      let obj = {
                        value: res.data.data[i].userName,
                        id: res.data.data[i].id
                      };
                      this.searchData.push(obj)
                    }
                  }
                    let perArray = [];
                    for (let item of res.data.data) {
                        perArray.push(item.userName);
                    }
                    this.listPermissions = [...new Set(perArray)];
                    if (this.searchData.length == 0) {
                        this.searchData = [{ value: '暂无数据' }];
                    }
                    callback(results)
                })
                .catch(err => {
                    console.log('获取搜索列表失败')
                })


        },
        createFilter(queryString) {
            return (restaurant) => {
               // return (restaurant.value.toLowerCase().indexOf(queryString.toLowerCase()) === 0);
              if (restaurant.str) return false;
              return (restaurant.value.indexOf(queryString) >= 0);
            };
        },

        handleSelect(item) {
            this.userId = item.id;
            //console.log(item)
            //this.getChannelData();
        },
    },
    watch: { //监听
        '$route' (to, from) { // 对路由变化作出响应...

        },
    },
}
