<template>
	<div class="addAccount">
		<div class="all_contain">
			<div class="manChannelTop">
				<el-breadcrumb separator-class="el-icon-arrow-right">
					<el-breadcrumb-item :to="{ path: '/account/index'}">账号授权</el-breadcrumb-item>
					<el-breadcrumb-item v-model="titleContainer">{{titleContainer}}</el-breadcrumb-item>
				</el-breadcrumb>
			</div>
			<el-form label-position="top" :model="ruleForm" :rules="rules" ref="ruleForm" label-width="100px" class="demo-ruleForm">
				<div class="manChannelMain">
					<el-form-item class='half50' label="选择授权账号" prop="userName" >
            <el-autocomplete class="inline-input" :disabled=editDisabeld v-model="ruleForm.userName" :fetch-suggestions="querySearch" placeholder="请输入账号"
              @select="handleSelect" style="width: 75%"
            ></el-autocomplete>
					</el-form-item>
					<el-form-item class='half50' label="" style="margin-top:47px" prop="channelId">
            <el-select v-model="ruleForm.channelName" placeholder="" :disabled=editDisabeld @change = 'changeSelect'>
              <el-option
                v-for="item in trench"
                :key="item.id"
                :label="item.name"
                :value="item.id">
              </el-option>
            </el-select>
					</el-form-item>
					<el-form-item  style="width:36%" label="备注" prop="Remarks"  >
						<el-input v-model="ruleForm.Remarks" placeholder="备注名称"></el-input>
					</el-form-item>
					<el-form-item class='is-required' label="权限设置" prop="themStyle">
						<div v-for="(jur,index) in jurisdictionList" :key="index" class="authory">
							<div class="authoryModel">
								<div class="authoryTop">{{jur.name}}</div>
								<div class="authoryCity">
									<el-checkbox-group v-model="ruleForm.listPermissions">
									   <el-checkbox v-for="item in jur.listPermissions" :label="item.id" :key="item.id" >{{item.name}}</el-checkbox>
									</el-checkbox-group>
								</div>
							</div>
						</div>
					</el-form-item>

				</div>
        <el-form-item>
          <div class="footBtn">
            <el-button @click="resetForm('ruleForm')">取消</el-button>
            <el-button type="primary" @click="submitForm('ruleForm')" :loading="loadingB">保存</el-button>
          </div>
        </el-form-item>
			</el-form>
		</div>
	</div>
</template>
<script src="./index.js">
</script>
<style scoped="scoped" src="./index.less" lang="less">
</style>
