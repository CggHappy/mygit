import axios from "@/axios.js";
//import bus from "@/bus.js";
import './account.css'
export default {
    data() {
        return {
            accountTabData: [],
            addBtn: false, //添加页面是否出来
            dataBtn: true, //数据页面是否显示
            channelMain: "-",
            top: 48,
            boxIsshow: false, //删除遮罩层显示状态
            btnsDisabled: true, //按钮的禁用状态
            isShowPagination: true, //是否显示分页
            pageNum: 1, //当前页
            pageSize: 10, //每页显示数据
            totalNum: 0, // 数据总条数
            isDisabled: true, //下拉菜单禁用
            statisticalManage: null, //统计管理
            widgetManage: null, //widget管理
            themeManage: null, //主题管理
            applicationManage: null, //应用管理
            accountMange: null, //账号授权
            channelManage: null, //渠道管理
            operationLog:null,//运维日志
            accountTabDataTemp: null, //临时的列表数据
            powerData: {}, //6个权限列的数据
            changeData: [],
            changeId: [],
            statisticalShow: false, //统计显示
            widgetShow: false, //widget显示
            themeShow: false, //主题显示
            applicationShow: false, //应用显示
            accountShow: false, //账号授权显示
            channelshow: false, //渠道显示
            operationLogShow:false,//运维日志显示
            loadingB: false,
            pageLoad: true,
            accountLimit:"",//账号
            addFlag:false,//添加成员
            editFlag:false,//更多按钮是否显示
            deleteFlag:false,//删除成员权限  编辑
            searchFlag:false,//查询成员
            deleBtnIS: false, //编辑按钮是否显示
            operate:true,
            saveCancel:false,//保存和取消是否显示
        }
    },
    mounted() { //实例挂载之后
        this.getUser();
        this.loadData();

    },
    methods: { //方法
        // 分页
       getUser(){
            let userMsg=JSON.parse(sessionStorage.getItem('userMsg'));
            let limit=userMsg.listPermissions;
            for(let i in limit){
                if(limit[i].name=="账号授权"){
                    this.accountLimit=limit[i].listPermissions;
                }
            }

            for(let i in this.accountLimit){
                switch(this.accountLimit[i].introducs){
                    case "添加成员":
                      this.addFlag=true;
                      break;
                    case "编辑成员"://更多
                      this.editFlag=true;
                      break;
                    case "删除成员":
                      this.deleteFlag=true;
                      break;
                    case "查询成员":
                      this.searchFlag=true;
                      break;
                    case "编辑成员权限"://编辑
                      this.deleBtnIS=true;
                      break;
                }
            };

            if(this.editFlag==false && this.deleteFlag==false){
                console.log(this.operate)
                this.operate=false;
            }else{
                this.operate=true;
            }
       },

        handleSizeChange(val) {
            //this.pageSize = val;
            //this.pageNum=1;
            // this.loadData(1, val);

        },
        handleCurrentChange(val) {
            this.pageNum = val;
            this.loadData()
        },

        cellClick(row, column, cell, event){
        },
        //加载列表数据
        loadData() {
            this.pageLoad = true;
            axios.get('auth/accountNumber/accountList', {
                    params: {
                        'pageNum': this.pageNum,
                        'pageSize': '10'
                    }
                })
                .then(res => {
                    this.pageLoad = false;
                    this.accountTabData = [];
                    this.totalNum = res.data.data.total;
                    this.pageSize = res.data.data.pageSize;
                    let userList = res.data.data.list; //用户列表
                    let powerData = []; //每个用户的权限列表
                    let userItme = {}; //每个用户
                    let manageArray = [];
                    
                    
                    for (let j = 0; j < userList.length; j++) {
                        userItme = {
                            id: userList[j].id,
                            userName: userList[j].userName,
                        };
                        //获取到权限列表
                        powerData = userList[j].listPermissions;
                        for (let i = 0; i < powerData.length; i++) {

                            if (powerData[i].name == '统计分析') {
                                this.statisticalManage = {
                                    id: powerData[i].id,
                                    list: this.setTableItem(powerData[i].listPermissions, userList[j].id)
                                }
                            }
                            if (powerData[i].name == 'widget管理') {
                                this.widgetManage = {
                                    id: powerData[i].id,
                                    list: this.setTableItem(powerData[i].listPermissions, userList[j].id)
                                }
                            }
                            if (powerData[i].name == '主题管理') {
                                this.themeManage = {
                                    id: powerData[i].id,
                                    list: this.setTableItem(powerData[i].listPermissions, userList[j].id)
                                }
                            }
                            if (powerData[i].name == '应用管理') {
                                this.applicationManage = {
                                    id: powerData[i].id,
                                    list: this.setTableItem(powerData[i].listPermissions, userList[j].id)
                                }
                            }
                            if (powerData[i].name == '渠道管理') {
                                this.channelManage = {
                                    id: powerData[i].id,
                                    list: this.setTableItem(powerData[i].listPermissions, userList[j].id)
                                }
                            }
                            if (powerData[i].name == '账号授权') {
                                this.accountMange = {
                                    id: powerData[i].id,
                                    list: this.setTableItem(powerData[i].listPermissions, userList[j].id)
                                }
                            }
                          if (powerData[i].name == '运维日志') {
                            this.operationLog = {
                              id: powerData[i].id,
                              list: this.setTableItem(powerData[i].listPermissions, userList[j].id)
                            }
                          }
                        }

                        userItme.statisticalManage = this.statisticalManage;
                        userItme.widgetManage = this.widgetManage;
                        userItme.themeManage = this.themeManage;
                        userItme.applicationManage = this.applicationManage;
                        userItme.accountMange = this.accountMange;
                        userItme.channelManage = this.channelManage;
                        userItme.operationLog = this.operationLog;
                        this.accountTabData.push(userItme)
                    };
                    this.isShow(this.addBtn, this.dataBtn);
                    for (let ites of powerData) {
                        manageArray.push(ites.name)
                    };
                    for (var i = 0; i < manageArray.length; i++) {
                        if (manageArray[i] === '统计分析') {
                            this.statisticalShow = true;
                        }
                        if (manageArray[i] === 'widget管理') {
                            this.widgetShow = true;
                        }
                        if (manageArray[i] === '主题管理') {
                            this.themeShow = true;
                        }
                        if (manageArray[i] === '应用管理') {
                            this.applicationShow = true;
                        }
                        if (manageArray[i] === '渠道管理') {
                            this.channelshow = true;
                        }
                        if (manageArray[i] === '账号授权') {
                            this.accountShow = true;
                        }
                        if (manageArray[i] === '运维日志') {
                            this.operationLogShow = true;
                        }

                    }
                })
                .catch(err => {
                    console.log(err)
                })
        },


        //列表数据封装
        setTableItem(arr, userId) {
            let itemArr = [];
            for (var i = 0; i < arr.length; i++) {
                let item = {};
                if (arr[i].chooseType == '1') {
                    item.checked = true;
                } else {
                    item.checked = false;
                }
                item.userId = userId;
                item.id = arr[i].id;
                item.label = arr[i].name;

                itemArr.push(item);
            }
            return itemArr;

        },
        changeitem(item) {
            item.checked = !item.checked;
        },

        //改变下拉框中对勾装填
        handleCommand(command) {
            let item = command;
            if (this.deleBtnIS) {
                item.checked = item.checked;
            } else {
                item.checked = !item.checked;
            }
        },

        //单个用户数据封装后台格式
        user(userItem) {
            let users = {
                user: {
                    id: userItem.id,
                    userName: userItem.userName,
                },
                permissions: []
            }

            if (userItem.statisticalManage) {
                users.permissions.push(this.selecTrueData(userItem.statisticalManage));
            };
            if (userItem.widgetManage) {
                users.permissions.push(this.selecTrueData(userItem.widgetManage));
            }
            if (userItem.themeManage) {
                users.permissions.push(this.selecTrueData(userItem.themeManage));
            }
            if (userItem.applicationManage) {
                users.permissions.push(this.selecTrueData(userItem.applicationManage));
            }
            if (userItem.accountMange) {
                users.permissions.push(this.selecTrueData(userItem.accountMange));
            }
            if (userItem.channelManage) {
                users.permissions.push(this.selecTrueData(userItem.channelManage));
            }
            if (userItem.operationLog) {
                users.permissions.push(this.selecTrueData(userItem.operationLog));
            }
            let arraysss = users.permissions
            for (var i = 0; i < arraysss.length; i++) {
                if (arraysss[i] == "" || typeof(arraysss[i]) == "undefined") {
                    arraysss.splice(i, 1);
                    i = i - 1;
                }
            }
            if (arraysss.join(',').split(",") == '') {
                users.permissions = []
            } else {
                users.permissions = arraysss.join(',').split(",")
            }
            return users;
        },

        // 筛选ture的结果，返回id集合
        selecTrueData(powerObj) {
            let idList = [];
            for (let i = 0; i < powerObj.list.length; i++) {
                if (powerObj.list[i].checked == true) {
                    idList.push(powerObj.list[i].id)
                }
            };
            return idList.join();
        },

        isShow(addBtn, dataBtn) {
            if (this.accountTabData.length == 0) {
                this.addBtn = true;
                this.dataBtn = false;
            } else {
                this.addBtn = false;
                this.dataBtn = true;
            }
        },

        //点击添加
        addChannel() {
            this.$router.push({
                path: "/account/addaccount"
            })
        },

        //点击取消按钮
        cannelAccount() {
            this.deleBtnIS = !this.deleBtnIS;
            this.btnsDisabled = !this.btnsDisabled;
            this.isShowEdit();
            //重新加载数据
            if(this.boxIsshow==true){
                this.boxIsshow=false;
            }else{
                this.boxIsshow=false;
            }
            this.loadData();
        },

        //点击编辑
        accountEdit() {
            this.deleBtnIS = !this.deleBtnIS;//编辑
            this.saveCancel=!this.saveCancel;
            this.isShowEdit();
            this.btnsDisabled = !this.btnsDisabled;

        },
        isShowEdit(){
            if(this.deleBtnIS==true){
                this.saveCancel=false
            }else{
                this.saveCancel=true
            }
        },
        selectChange() {},

        cellHover(row, column, cell, event) {},


        //点击更多时跳转
        getMore(index, row) {
            this.$router.push({
                path: "/account/editaccount"
            })
            sessionStorage.setItem('id', row.id)
        },

        //删除按钮
        deleteRow(index, row) {
            this.top = 48 + (96 * index);
            this.boxIsshow = !this.boxIsshow;
            sessionStorage.setItem('delId', row.id);
        },

        //撤销删除
        canccelDel() {
            this.boxIsshow = !this.boxIsshow;
        },

        //保存按钮
        accountSave() {
            //删除弹层出现状态，点击保存为删除该条数据
            //弹层为出现状态，点击保存为保存数据

            this.deleBtnIS = !this.deleBtnIS;
            this.isShowEdit();
            this.btnsDisabled = !this.btnsDisabled;

            this.loadingB = true;
            if (this.boxIsshow == true) {
                let data = {
                    id: sessionStorage.getItem('delId'),
                };
                //删除接口
                axios.post('auth/accountNumber/deleteById', data)
                    .then(res => {
                        if(res.data.data=="2"){
                            this.$message.success("此账号为渠道管理员，不可删除");
                        }else{
                            this.$message.success('删除数据成功')
                        }
                        
                        this.boxIsshow = false;
                        this.loadData();
                        this.loadingB = false
                    })
                    .catch(err => {
                        this.$message.error('删除数据失败')
                    })
            } else {
                //保存接口
                let data = [];
                for (let i = 0; i < this.accountTabData.length; i++) {
                    let item = this.user(this.accountTabData[i]);
                    data.push(item);
                }
                let str = JSON.stringify(data);
                console.log(data)
                let dataAll = {
                    str: str
                }
                axios.post('auth/accountNumber/updateAccount', dataAll)
                    .then(res => {
                        this.$message.success('保存数据成功')
                        this.loadData();
                        this.loadingB = false
                    })
                    .catch(err => {
                        console.log('保存数据失败');
                    })
            }
        },
        abc() {
            this.$refs.aa.mouseenter;
        }
    },

    watch: { //监听
        '$route' (to, from) { // 对路由变化作出响应...

        },
    },
    created() { //实例创建之后
    }
}
