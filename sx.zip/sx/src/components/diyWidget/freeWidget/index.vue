<template>
	<div class="freeWidget">
		<div class="all_contain">						
			<header class="widgetManage">
				<el-breadcrumb separator-class="el-icon-arrow-right">
					<el-breadcrumb-item :to="{path: '/diywidget/index' }">布局控件管理</el-breadcrumb-item>
					<el-breadcrumb-item>{{freeTitle}}</el-breadcrumb-item>
				</el-breadcrumb>
			</header>
			<div class="widgetCustom">
				<el-form :model="ruleForm" :rules="rules" ref="ruleForm" label-width="100px" class="demo-ruleForm">
				  <el-form-item label="名称" prop="newName">
				    <el-input v-model="ruleForm.newName" clearable></el-input>
				  </el-form-item>
          <el-form-item label="使用渠道" v-if="addBtnIS && isAdd && add">
            <div class="channelSelect">
                <template>
                  <el-checkbox-group v-model="checkList" @change="changeChecked">
                    <el-checkbox v-for="(item,index) in channelSelect" :label="item.name" :value="item.name" :key="item.name"></el-checkbox>
                  </el-checkbox-group>
                </template>
            </div>
            <div class="tip">不勾选，默认全部使用</div>
            </el-form-item>
  				  <el-form-item label="Widget分类" prop="widgetCategory">
  				    <el-select placeholder="请选择" v-model="ruleForm.widgetCategory"  @focus="widgetCategory" clearable>
  				      <el-option v-for="(item,index) in categorySelect" :label="item.typeName" :value="item.typeName" :key="item.index"></el-option>
  				    </el-select>
  				    <el-button type="primary" @click="addstyle" style="background:#84A1E5;border-color:#84A1E5" v-if="addBtnIS && isAdd && add">添加分类</el-button>
  				    <el-dialog
  				      title="添加Widget分类"
  				      :visible.sync="dialogVisible"
  				      width="45%">
  				      	<div class="addCategoryTitle">
  				      		<el-button @click="addCategory">增加</el-button><span class="nameTitle">分类名称最多4个字符</span>
  				      	</div>
  				     	<div class="addCategory">
  				     		<div class="categoryModel" v-for="(item,index) in category" :key=index>
  			     				<input class="customCategory" v-model='item.msg' maxlength=4 clearable/><span class="remove" @click="removeCategory(index)">-</span>
  			     			</div>
  				     	</div>
  				      <span slot="footer" class="dialog-footer">
  				        <el-button @click="dialogVisible = false">取 消</el-button>
  				        <el-button type="primary" @click="categorySure">确 定</el-button>
  				      </span>
  				    </el-dialog>
  				  </el-form-item>
  				  <el-form-item label="适用" prop="version">
  				    <el-select placeholder="请选择尺寸" v-model="ruleForm.version" @focus="availableVersion" clearable>
  				      <el-option v-for="(item,index) in sizeWidget" :label="item.attributeValue" :value="item.attributeValue" :key="item.index"></el-option>
              </el-select>
  				    <span>以上版本</span>
  				  </el-form-item>
  				  <el-form-item label="Widget封面" prop="img">
  				   	<div class="widgetBgImg">
                <el-upload
                  class="avatar-uploader widgetUpload"
                  action="http://api.launcher.pactera-sln.club:8185/system/fileUpload"
                  :show-file-list="false"
                  :auto-upload="true"
                  :headers=uploadToken
                  :on-success="handleAvatarSuccessF"
                  :before-upload="beforeAvatarUpload">
                  <img v-if="fengmian" :src="fengmian" class="avatar">
                  <i v-else class="el-icon-plus avatar-uploader-icon"></i>
                </el-upload>
              </div>
  				  </el-form-item>
            <el-form-item label="描述"  prop="description">
              <el-input v-model="ruleForm.description"  type="textarea" resize="none"  clearable></el-input>
            </el-form-item>   				  
				</el-form>
			</div>
      <div class="newWidget">
        <div class="widgetTop">
          <div class="widgetLeft">
              <div class="imgBox">
                  <img :src='imgbaseUrl+img[widegetData.backgroud]' class="widgetImg"/>
              </div>
          </div>
          <div class="widgetRight">
            <div class="nature">
              <div class="" v-for="(item,index) in widegetData.setting" >
                    <div class="property" v-if="item.type=='ImageSet'">
                       <div class="title">
                         {{item.label}}：
                       </div>
                       <div class="propertyMain">
                         <ul class="propertyUl">
                           <li class="typeMain" v-if="item.default.hasOwnProperty('alignType')">
                               <p class="typeName">对齐：</p>
                               <div class="typeBox">
                                 <p class="type typeAlign" v-if="item.default.alignType">
                                   <template>
                                     <el-select v-model="item.default.alignType" placeholder="请选择" @focus="uploadClick(item,index)">
                                       <el-option
                                         v-for="(ele,index) in alignType"
                                         :key="ele.value"
                                         :label="ele.label"
                                         :value="ele.value">
                                       </el-option>
                                     </el-select>
                                   </template>
                                 </p>
                               </div>
                           </li>
                           <li class="typeMain" v-if="item.default.hasOwnProperty('scaleType')">
                              <p class="typeName">缩放 ：</p>
                              <div class="typeBox">
                                <p class="type">
                                    <template>
                                      <el-select v-model="item.default.scaleType" placeholder="请选择" @focus="uploadClick(item,index)">
                                        <el-option
                                          v-for="(item,index) in scaleType"
                                          :key="item.value"
                                          :label="item.label"
                                          :value="item.ident">
                                        </el-option>
                                      </el-select>
                                    </template>
                                </p>
                              </div>
                           </li>
                           <li class="typeMain" style="margin:22px 0 5px 0" v-if="item.default.hasOwnProperty('color')">
                               <p class="typeName">颜色：</p>
                               <p class="type">
                                  <span>{{item.default.color}}</span><input type="color" v-model="item.default.color"/>
                               </p>
                           </li>
                            <li class="typeMain" style="height:150px;" v-if="item.default.hasOwnProperty('nine-path') || item.default.hasOwnProperty('image')">
                               <p class="typeName">图片上传：</p>
                               <p class="type typeImg">
                               
                                <el-upload  v-if="item.default.hasOwnProperty('nine-path')"
                                  class="avatar-uploader"
                                  action="http://api.launcher.pactera-sln.club:8185/system/fileUpload"
                                  :show-file-list="false"
                                  :auto-upload="true"
                                  :headers=uploadToken
                                  :on-success="handleAvatarSuccess"
                                  :before-upload="beforeAvatarUpload">
                                  <img v-if="item.default['nine-path']" :src="item.backupSrc?item.backupSrc:imgbaseUrl+img[item.default['nine-path']]" class="avatar" @click="uploadClick(item,index)">
                                  <i v-else class="el-icon-plus avatar-uploader-icon"></i>
                                </el-upload>
                                <el-upload  v-if="item.default.hasOwnProperty('image')"
                                  class="avatar-uploader"
                                  action="http://api.launcher.pactera-sln.club:8185/system/fileUpload"
                                  :show-file-list="false"
                                  :headers=uploadToken
                                  :auto-upload="true"
                                  :on-success="handleAvatarSuccess"
                                  :before-upload="beforeAvatarUpload">
                                  <img v-if="item.default['image']" :src="item.backupSrc?item.backupSrc:imgbaseUrl+img[item.default['image']]" class="avatar" @click="uploadClick(item,index)">
                                  <i v-else class="el-icon-plus avatar-uploader-icon"></i>
                                </el-upload>
                              </p>
                              
                           </li>
                         </ul>
                       </div>
                    </div>
                    <div class="property"  v-if="item.type=='TextSet'">
                       <div class="title">
                         {{item.label}}：
                       </div>
                       <div class="propertyMain">
                         <ul class="propertyUl">
                           <li class="typeMain" v-if="item.default.hasOwnProperty('def_text')">
                               <p class="typeName">内容：</p>
                               <p class="type"><input type="text" v-model="item.default.def_text" class="inputSelf"/></p>
                           </li>
                           <li class="typeMain" v-if="item.default.hasOwnProperty('size')">
                               <p class="typeName">大小：</p>
                               <p class="type"><input type="text" v-model="item.default.size" class="inputSelf"/></p>
                           </li>
                           <li class="typeMain" v-if="item.default.hasOwnProperty('color')">
                               <p class="typeName">颜色：</p>
                               <p class="type">
                                  <span>{{item.default.color}}</span><input type="color" v-model="item.default.color"/>
                               </p>
                           </li>
                           <li class="typeMain" v-if="item.default.hasOwnProperty('font_style')">
                               <p class="typeName">风格：</p>
                               <p class="type">
                                 <template>
                                   <el-checkbox v-model="item.default.font_style" v-for="(ele,index) in fontStyle" :label="ele" :value="ele" :key="ele.index">{{ele}}</el-checkbox>
                                 </template>
                               </p>
                           </li>
                           <li class="typeMain" v-if="item.default.hasOwnProperty('line_spacing')">
                               <p class="typeName">行间距：</p>
                               <p class="type"><input type="text" v-model="item.default.line_spacing" class="inputSelf"/></p>
                           </li>
                           <div class="typeMain flex" v-if="item.default.hasOwnProperty('background')">
                              <p class="">背景</p>
                              <div class="backgroundMain">
                                  <li class="typeMain" v-if="item.default.background.hasOwnProperty('color')">
                                     <p class="typeName">颜色：</p>
                                     <p class="type" style="margin-top:-2px;">
                                        <span>{{item.default.background.color}}</span><input type="color" v-model="item.default.background.color" class="inputSelf"/>
                                     </p>
                                 </li>
                                 <li class="typeMain" style="height:45px" v-if="item.default.background.hasOwnProperty('alignType')">
                                    <p class="typeName">对齐：</p>
                                    <div class="typeBox">
                                   <p class="type typeAlign">
                                     <template>
                                     <el-select v-model="item.default.background.alignType" placeholder="请选择" @focus="uploadClick(item,index)">
                                       <el-option
                                       v-for="(ele,index) in alignType"
                                       :key="ele.value"
                                       :label="ele.label"
                                       :value="ele.value">
                                       </el-option>
                                     </el-select>
                                     </template>
                                   </p>
                                    </div>
                                 </li>
                                 <li class="typeMain" style="height:45px" v-if="item.default.background.hasOwnProperty('scaleType')">
                                    <p class="typeName">缩放 ：</p>
                                    <div class="typeBox">
                                      <p class="type">
                                          <template>
                                            <el-select v-model="item.default.background.scaleType" placeholder="请选择" @focus="uploadClick(item,index)">
                                              <el-option
                                                v-for="(ele,index) in scaleType"
                                                :key="ele.value"
                                                :label="ele.label"
                                                :value="ele.ident">
                                              </el-option>
                                            </el-select>
                                          </template>
                                      </p>
                                    </div>
                                 </li>
                                 <li class="typeMain" style="height:150px;" v-if="item.default.background.hasOwnProperty('nine-path') || item.default.background.hasOwnProperty('image'
                                 )">
                                      <p class="typeName">图片上传：</p>
                                      <p class="type typeImg">
                                      
                                       <el-upload  v-if="item.default.background['nine-path']"
                                         class="avatar-uploader"
                                         action="http://api.launcher.pactera-sln.club:8185/system/fileUpload"
                                         :show-file-list="false"
                                         :auto-upload="true"
                                         :headers=uploadToken
                                         :on-success="handleAvatarSuccessText"
                                         :before-upload="beforeAvatarUpload">
                                         <img v-if="item.default.background['nine-path']" :src="item.backupSrc?item.backupSrc:imgbaseUrl+img[item.default.background['nine-path']]" class="avatar" @click="uploadClick(item,index)">
                                         <i v-else class="el-icon-plus avatar-uploader-icon"></i>
                                       </el-upload>
                                       <el-upload  v-if="item.default.background['image']"
                                         class="avatar-uploader"
                                         action="http://api.launcher.pactera-sln.club:8185/system/fileUpload"
                                         :show-file-list="false"
                                         :headers=uploadToken
                                         :auto-upload="true"
                                         :on-success="handleAvatarSuccessText"
                                         :before-upload="beforeAvatarUpload">
                                         <img v-if="item.default.background['image']" :src="item.backupSrc?item.backupSrc:imgbaseUrl+img[item.default.background['image']]" class="avatar" @click="uploadClick(item,index)">
                                         <i v-else class="el-icon-plus avatar-uploader-icon"></i>
                                       </el-upload>
                                     </p>
                                     
                                  </li>
                              </div>
                           </div>
                         </ul>
                       </div>
                   </div>
                   <div class="property" v-if="item.type=='singleSelect'">
                        <div class="title">
                          {{item.label}}：
                        </div>
                        <div class="propertyMain">
                          <ul class="propertyUl">
                            <li class="typeMain">
                                <template>
                                  <el-radio v-model="item.default" v-for="(ele,index) in item.values" :label="ele.value" :value="ele.value" :key="ele.index">{{ele.lable}}</el-radio>
                                </template>
                            </li>
                          </ul>
                        </div>
                    </div>
                  <div class="property" v-if="item.type=='multiSelect'">
                       <div class="title">
                         {{item.label}}：
                       </div>
                       <div class="propertyMain">
                         <ul class="propertyUl">
                           <li class="typeMain" style="height:auto">
                               <template>
                                  <el-checkbox-group v-model="item.default">
                                   <el-checkbox v-for="(item,index) in item.values" :label="item.value" :value="item.value" :key="item.index">{{item.label}}</el-checkbox>
                                  </el-checkbox-group>
                               </template>
                           </li>
                         </ul>
                       </div>
                   </div>
                   <div class="property" v-if="item.type=='color'">
                        <div class="title">
                          {{item.label}}：  <span>{{item.default.color}}</span><input type="color" v-model="item.default.color"/>
                        </div>
                        
                    </div>
                    <div class="property" v-if="item.type=='number'">
                         <div class="title">
                           {{item.label}}： <el-input style="display:inline-block"></el-input>
                         </div>
                    </div>
                    <div class="property" v-if="item.type=='text'">
                         <div class="title">
                           {{item.label}}： <el-input style="display:inline-block" v-model='item.default'></el-input>
                         </div>
                    </div>
              </div>
            </div>
          </div>
        </div>
        <div class="widgetBottom">
            <el-button @click="remove">取消</el-button>
            <el-button type="primary" @click="saveData(ruleForm)" v-model='disabled'>保存</el-button>
        </div>
      </div>
		</div>
	</div>
</template>
<script src="./index.js">
</script>
<style scoped="scoped" src="./index.less" lang="less">
</style>