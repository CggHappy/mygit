import axios from "@/axios.js";
//import bus from "@/bus.js";
import "./freeWidget.css";
export default {
	data() {
		var validateUser = (rule, value, callback) => {
            let reg=/^[a-zA-Z0-9_\u4e00-\u9fa5]{1,20}$/;
            if(!reg.test(value)){
                callback(new Error('请输入1-20位中文、字母、数字和下划线的名称'));
            }
        };
		return {
			widegetData:[],
			currentindex:-1,
			imgarr:[{
				imgurledit:''
				
			}],
			freeWidgetCategory:[],
	       	dialogVisible:false,
	       	category:[],
	       	ruleForm: {
              newName: '',
              widgetCategory: '',//widget分类
              version: '',//适用的版本
              description:"",//描述
              img:"",//封面图片
            },
            rules: {
                 newName: [
                 { required: true, message: '请输入widget名称', trigger: 'blur' },
                 { validator: validateUser, trigger: 'blur' }
               ],
               widgetCategory: [
                 { required: true, message: '请选择widget分类', trigger: 'change' }
               ],
               version: [
                 { required: true, message: '请选择适用的版本', trigger: 'change' }
               ],
                description: [
                 {  max: 100, message: '描述不能超过100个字符', trigger: 'blur' }
               ],
               img: [
                 {  required: true, trigger: 'blur' }
               ],
            },
            imageUrl: '',
            freeTitle:"",//页面进来显示的标题
            sizeWidget: "",
           //value: '',
           checkList:[],//渠道下拉框
           checkListId:[],//渠道下拉框给后台传值
           radio: '1',//单选默认的选项
           src:"",//widget路径
           options:[],
           img:"",//5个图片
           checkedList:"",
           categorySelect:"",
           channelSelect:"",//渠道选项,
           editorImg:"",//右侧编辑器图片路径
           fontStyle:["italic","bold","underline","deleteline"],
           mapImg:"",
           backupSrc:"",
           item:"",
           fengmian:"",
           mapBgImg:"",
           flex:"",
           alignType:[
           	{
           		"label":"左上",
           		"value":"LT"
           	},
           	{
           		"label":"左下",
           		"value":"LB"
           	},
           	{
           		"label":"右上",
           		"value":"RT"
           	},
           	{
           		"label":"右下",
           		"value":"RB"
           	},
           	{
           		"label":"顶部居中",
           		"value":"THC"
           	},
           	{
           		"label":"底部居中",
           		"value":"BHC"
           	},
           	{
           		"label":"左侧居中",
           		"value":"LVC"
           	},
           	{
           		"label":"右侧居中",
           		"value":"RVC"
           	},
           	{
           		"label":"居中",
           		"value":"CENTER"
           	}
           ],
		
           scaleType:[
           	{
           		"label":"拉伸填充",
           		"value":"FIT_XY",
           		"ident":"1"
           	},
           	{
           		"label":"原图居中",
           		"value":"CENTER",
           		"ident":"5"
           	},
           	{
           		"label":"剪切居中",
           		"value":"CENTER_CROP",
           		"ident":"6"
           	},
           	{
           		"label":"缩小居中",
           		"value":"CENTER_INSIDE",
           		"ident":"7"
           	},
           	{
           		"label":"左上",
           		"value":"FIT_START",
           		"ident":"2"
           	},
           	{
           		"label":"居中",
           		"value":"FIT_CENTER",
           		"ident":"3"
           	},
           	{
           		"label":"右下",
           		"value":"FIT_END",
           		"ident":"4"
           	}
           ],
           disabled:false,//保存按钮
           alignTypeCheck:"",//对齐默认回显
           scaleTypeCheck:"",//填充默认回显
           addBtnIS:false,//渠道不显示添加分类
           uploadToken:"",
           isAdd:true,
           add:true,
		}
	},	
	mounted() { //实例挂载之后
		this.category=[];
		this.channel();
		this.getMenudata();
	},
	methods: { //方法
		channel(){//渠道
			axios.get('/system/channel/findAll')
				.then((res) => {
					this.channelSelect=res.data.data;
					let channelItem=JSON.parse(sessionStorage.getItem("channels"));
					for(let i in channelItem){
						for(let j in this.channelSelect){
							if(channelItem[i].channelId==this.channelSelect[j].id){
								this.checkList.push(this.channelSelect[j].name);
								this.checkListId=this.channelSelect[j].id
							}
						}
					}
				})
				.catch(err => {
					console.log(err);
				});
		},
		changeChecked(value){//选中复选框,转化为ID发给后台
			let arr = value;
			let value1 = [...new Set(arr)];
			let checkedArr=[];//id
			let checkedLabel=[];
			this.checkList="";
			for(let i in this.channelSelect){
				for(let j in value1){
					if(this.channelSelect[i].name==value1[j]){
						checkedLabel.push(value1[j]);
						checkedArr.push(this.channelSelect[i].id)
					}
				}
				
			}
			this.checkListId=checkedArr.join(",");
			this.checkList=checkedLabel;
		},
		getMenudata(){//页面渲染数据
			let widegetData=JSON.parse(sessionStorage.getItem('menuData'));
			let img=JSON.parse(sessionStorage.getItem("img"));
			let userMsg=JSON.parse(sessionStorage.getItem('userMsg'));
			let isqudao=userMsg.userType;
			let id=userMsg.id;
			let creator=JSON.parse(sessionStorage.getItem('creator'));
			this.addBtnIS=(isqudao==0) || (isqudao==2)?true:false;
			if(this.$route.path.indexOf('editwidget')>0){
				this.add=true;
				this.isAdd=true;
			}
			if(!this.addBtnIS){//渠道
				this.checkListId=userMsg.channelId;
			}else{//管理员
				this.add=true;
				if(creator.channelUserName!="管理员"){
					this.isAdd=false;
				}else{
					this.isAdd=true;
				}
			}
			for(let i in widegetData[0].setting){
				widegetData[0].setting[i].backupSrc="";
				widegetData[0].setting[i].editorImg="";
			}
			this.widegetData=widegetData[0];
			this.img=img;
			let token=sessionStorage.getItem('Token');
			this.uploadToken={
				Authorization:token
			};
			let path=this.$route.path;
			if(sessionStorage.getItem("newtitle")=="创建"){
				this.freeTitle="创建变体widget";
			}else{
				this.freeTitle="编辑变体widget";
				
			}
			this.fengmian=this.imgbaseUrl+this.img[this.widegetData.backgroud];

			//上面回显
			this.ruleForm.newName=this.widegetData.name;
			this.ruleForm.widgetCategory=this.widegetData.category;
			this.ruleForm.version=this.widegetData.version;
			this.ruleForm.description=this.widegetData.description;
			this.fengmian=this.imgbaseUrl+this.img[this.widegetData.backgroud]

			for(let i in this.widegetData.setting){
				if(this.widegetData.setting[i].type=="ImageSet"){
					if(this.widegetData.setting[i].default['image']){
						this.widegetData.setting[i].flex=this.widegetData.setting[i].default['image'];
					}else{
						this.widegetData.setting[i].flex=this.widegetData.setting[i].default['nine-path'];
					}
				}
			}

			
		},
		addstyle(){//添加分类
			this.dialogVisible=true;
			this.category=[];
		},
		addCategory(){//添加分类			
			this.category.push({
             msg:''
			});
		},
		removeCategory(index){//添加分类弹出框删除数据
			this.category.splice(index,1)
		},
		categorySure(){//点击确定时保存数据
			this.dialogVisible = false;
			let arr=[];
			for(let i=0;i<this.category.length;i++){
				arr.push(this.category[i].msg)
			};
			let res = [];
			arr.forEach(function(item) { //数组去重
				res.includes(item) ? '' : res.push(item);
			});
			let data = {
				typeName:res.join(",")
			};
			axios.post('/system/insertWidgetType', data)
				.then((res) => {
					this.$message({
						type: 'success',
						message: res.data.data
					});
					this.widgetCategory();
				})
				.catch(err => {
					console.log(err);
				});
		},
		widgetCategory(){//widget下拉框数据
			axios.get('/system/findWidgetCategory')
				.then((res) => {
					this.categorySelect=res.data.data.list
				})
				.catch(err => {
					console.log(err);
				});
		},
		availableVersion(){//尺寸下拉框数据
			axios.get('/system/findWidgetVersion')
				.then((res) => {
					this.sizeWidget=res.data.data
				})
				.catch(err => {
					console.log(err);
				});
		},
		handleAvatarSuccessF(res,file){//上传封面图片
			this.fengmian = URL.createObjectURL(file.raw);
			let picnameDot =  new Date().getTime()+file.name.slice(file.name.lastIndexOf('.') - 2, file.name.length);
			let picnameImg = new Date().getTime() + file.name.slice(file.name.lastIndexOf('.'), file.name.length);
			delete this.img[this.widegetData.backgroud];
			this.isNineImg("backgroud",file,res)
		},
		getimgurl(res,url){//给数据里暂存字段，方便取	
				
			this.widegetData.setting[this.currentindex].editorImg=res;
            this.widegetData.setting[this.currentindex].backupSrc=url;
		},
		uploadClick(item,index){
			this.currentindex=index;
		},
		handleAvatarSuccess(res, file) {//上传编辑器中的图片
			this.getimgurl(res,URL.createObjectURL(file.raw));
			let picnameDot =  new Date().getTime()+file.name.slice(file.name.lastIndexOf('.') - 2, file.name.length);
			let picnameImg = new Date().getTime() + file.name.slice(file.name.lastIndexOf('.'), file.name.length);
			delete this.img[this.widegetData.setting[this.currentindex].flex];
			if(this.widegetData.setting[this.currentindex].default['nine-path']){
				this.isNineImg("nine-path",file,res)
			}else{
				this.isNineImg("image",file,res)
			}
			
	    },
	    handleAvatarSuccessText(res,file){//上传编辑器中文字类型中的图片
	    	this.getimgurl(res,URL.createObjectURL(file.raw));
			let picnameDot =  new Date().getTime()+file.name.slice(file.name.lastIndexOf('.') - 2, file.name.length);
			let picnameImg = new Date().getTime() + file.name.slice(file.name.lastIndexOf('.'), file.name.length);
			delete this.img[this.widegetData.setting[this.currentindex].flex];
			if(this.widegetData.setting[this.currentindex].default.background){
				if(this.widegetData.setting[this.currentindex].default.background['nine-path']){
					this.isNineImg("nine-pathText",file,res)
				}else{
					this.isNineImg("imageText",file,res)
				}
			}
			
			
	    },
	    isNineImg(value,file,res){//给widgetData修改图片
	     	let picnameDot =  new Date().getTime()+file.name.slice(file.name.lastIndexOf('.') - 2, file.name.length);
			let picnameImg = new Date().getTime() + file.name.slice(file.name.lastIndexOf('.'), file.name.length);
	     	if(value=="nine-path"){//点九图
 		     	if(picnameDot.indexOf(".9")>0){
 						this.widegetData.setting[this.currentindex].default['nine-path']=picnameDot;
 						this.img[picnameDot]=res;
 					}else{
 						this.widegetData.setting[this.currentindex].default['nine-path']=picnameImg;
 						this.img[picnameImg]=res;
 					}
	     	}else if(value=="image"){//image类型
	     		if(picnameDot.indexOf(".9")>0){
	     			this.widegetData.setting[this.currentindex].default['image']=picnameDot;
	     			this.img[picnameDot]=res;
	     		}else{
	     			this.widegetData.setting[this.currentindex].default['image']=picnameImg;
	     			this.img[picnameImg]=res;
	     		}
	     	}
	     	if(value=="backgroud"){//封面图
	     		if(picnameDot.indexOf(".9")>0){
	     			this.widegetData.backgroud=picnameDot;
	     			this.img[this.widegetData.backgroud]=res;
	     		}else{
	     			this.widegetData.backgroud=picnameImg;
	     			this.img[this.widegetData.backgroud]=res;
	     		}
	     	}
	     	if(value=="nine-pathText"){
 		     	if(picnameDot.indexOf(".9")>0){
 						this.widegetData.setting[this.currentindex].default.background['nine-path']=picnameDot;
 						this.img[picnameDot]=res;
 					}else{
 						this.widegetData.setting[this.currentindex].default.background['nine-path']=picnameImg;
 						this.img[picnameImg]=res;
 					}
	     	}
	     	if(value=="imageText"){
	     		if(picnameDot.indexOf(".9")>0){
	     			this.widegetData.setting[this.currentindex].default.background['image']=picnameDot;
	     			this.img[picnameDot]=res;
	     		}else{
	     			this.widegetData.setting[this.currentindex].default.background['image']=picnameImg;
	     			this.img[picnameImg]=res;
	     		}
	     	}
	     	
	    },
      	beforeAvatarUpload(file,value) {
      	  	const isJPG = file.type === 'image/jpeg';
			const isPNG = file.type === 'image/png';
			if(!isJPG && !isPNG) {
				this.$message.error('上传封面图片只能是 JPG、PNG 格式!');
			}
			return isJPG || isPNG;
      	},
      	deleteFile(){
      		this.deleteBtn=true;
      	},
      	saveData(formName){//点击保存按钮传数据
      		this.disabled=true;
      		if(this.fengmian.length==0){
      			this.$message({
      	          message: '必须上传封面图片',
      	          type: 'error'
      	        });
      		}else{
      			let newtitle=sessionStorage.getItem("newtitle");

      			for(let i in this.categorySelect){
      				if(this.ruleForm.widgetCategory==this.categorySelect[i].typeName){
      					this.widegetData.category=this.categorySelect[i].id;
      				}
      			}
      			for(let i in this.sizeWidget){
      				if(this.ruleForm.version==this.sizeWidget[i].attributeValue){
      					this.widegetData.version=this.sizeWidget[i].attributeKeyIndex;
      				}
      			}
      			this.widegetData.name=this.ruleForm.newName;//名称内容
      			this.widegetData.description=this.ruleForm.description;
      			
      			
      			for(let i in this.widegetData.setting){
      				delete this.widegetData.setting[i].flex;
      				delete this.widegetData.setting[i].editorImg;
      				delete this.widegetData.setting[i].backupSrc;
      			};
      			let propertyData=[];
      			propertyData.push(this.widegetData);
      			let data={
      				params:{
      					widgetjson:JSON.stringify(propertyData),
      					channels:this.checkListId,
      					filepath:JSON.stringify(this.img),
      				}
      			};
      			if(newtitle=="创建"){//创建副本或创建变体
      				axios.get('/system/saveWidget',data)
      				.then((res) => {
						this.ajaxSuccess(res)
      				})
      				.catch(err => {
      					this.ajaxError(err)
      				});
      			}

      			if(newtitle=="编辑"){//编辑
      				axios.get('/system/updateWidget',data)
      				.then((res) => {
      					this.ajaxSuccess(res)
      				})
      				.catch(err => {
      			        this.ajaxError(err)
      				});
      			}
      		}
      		
      	},
      	type(type,backgroundType,value){
      		for(let j in type){
				if(backgroundType){
					if(type[j].label==backgroundType){
						backgroundType=type[j].value;
					}
				}
			}
      	},
      	remove(){//不保存数据
      		this.disabled=false;
			sessionStorage.removeItem("img")
			sessionStorage.removeItem("menuData")
	    	this.$router.push({
				path: "/diywidget/index"
			});
      	},
      	ajaxSuccess(res){
			this.$message({
	          message: res.data.message,
	          type: 'success'
	        });
			this.disabled=false;
			sessionStorage.removeItem("img")
			sessionStorage.removeItem("menuData")
	    	this.$router.push({
				path: "/diywidget/index"
			});
      	},
      	ajaxError(res){
			this.$message({
	          message: res.data.message,
	          type: 'error'
	        });
	        this.disabled=false;
      	}
	},
	watch: { //监听
		'$route' (to, from) { // 对路由变化作出响应...

		},
	},
	created() { //实例创建之后
		this.getMenudata()
		this.widgetCategory();
		this.channel();
		this.availableVersion();
	},
	components:{
		
	}
}