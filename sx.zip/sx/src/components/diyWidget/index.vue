<template>
	<div class="widget_Manage">
		<div class="all_contain">
			<div class="widgetManage">
				<p class="widgetManageTitle">Widget自定义><span class="widgetControl">控件管理</span></p>
				<p class="widgetBtn">
					<button type="button" class="el-button el-button--primary btnSearch btnBox greenBox" @click="dialogUpload=true" v-if="isUpload && isManage">上传基础Widget</button>
					<button type="button" class="el-button el-button--primary btnSearch btnBox" @click="addCustom" v-if='newFlag'>添加自定义控件</button>
				</p>
				<el-dialog title="上传基础Widget" :visible.sync="dialogUpload">
				  <el-form v-if="dialogUpload">
				    <el-upload
				      class="upload-demo"
				      ref="upload"
				      action="http://api.launcher.pactera-sln.club:8185/system/uploadBaseWidget"
				      :headers=uploadToken
				      :on-remove="handleRemove"
				      :before-remove="beforeRemove"
				      :auto-upload="false"
				      :on-success="upLoadSuccess"
				      :on-error="upLoadFailed"
				      :before-upload="beforeAvatarUpload">
				      <el-button slot="trigger" size="small" type="primary">选取文件</el-button>
				    </el-upload>
				  </el-form>
				  <div slot="footer" class="dialog-footer">
				  	<el-button type="primary"  @click="upLoadPakageRemove">取消</el-button>
				    <el-button type="primary"  @click="upLoadPakage">确 定</el-button>
				  </div>
				</el-dialog>
			</div>

			<div class="diyWidgetTable">
				<div class="widgetTableTop">
					<div class="selectModel">
						<label class="channel"></label>
						<el-select v-model="defaultSize" placeholder="请选择尺寸"  @focus='getwidgetSize'  clearable>
							<el-option v-for="(item,index) in widgetSize" :key=index :value=item>
								
							</el-option>
						</el-select>
					</div>
					<div class="selectModel">
						<label class="channel"></label>
						<el-select v-model="category" placeholder="请选择分类" @focus='getWidgetCategory' clearable>
							<el-option v-for="item in widgetCategory" :value="item.id" :label="item.typeName" :key="item.index">
							</el-option>
						</el-select>
					</div>
					<div class="selectModel">
						<label class="channel"></label>
						<el-select v-model="version" placeholder="请选择版本" @focus='getWidgetVersion' clearable>
							<el-option v-for="item in widgetVersion" :value="item.attributeKeyIndex" :label="item.attributeValue" :key="item.index">
							</el-option>
						</el-select>
					</div>
					<div class="selectModel">
						<label class="channel"></label>
						<el-input placeholder="Widget搜索" v-model="keyWord" clearable>
						</el-input>
					</div>
					<button type="button" class="el-button el-button--primary btnSearch" @click="saveQuery">搜索</button>
				</div>
				
				<div class="widgetTableMain">
					<div class="widgetTableModel">
						<el-table ref="multipleTable" element-loading-text="数据加载中..." v-loading="loading" :data="tableData" tooltip-effect="dark" style="width: 100%" @cell-mouse-enter="enterCell">							
							<el-table-column label="ID" type="index" :index="indexMethod"  width="45">
							</el-table-column>
							<el-table-column prop="name" label="名称" show-overflow-tooltip  width="100">
								<template slot-scope="scope">
									<span :title="cellName">{{scope.row.name}}</span>
								</template>
							</el-table-column>
							<el-table-column prop="typeName" label="分类" show-overflow-tooltip  width="80">				
							</el-table-column>
							<el-table-column prop="defaultSize" label="默认尺寸" show-overflow-tooltip  width="90">
							</el-table-column>
							<el-table-column prop="type" label="类型" show-overflow-tooltip  width="90">
							</el-table-column>
							<el-table-column prop="versionName" label="最低支持版本" show-overflow-tooltip  width="110">
							</el-table-column>
							<el-table-column label="描述" show-overflow-tooltip  width="100">
								<template slot-scope="scope">
									<span :title="cellTitle">{{scope.row.description}}</span>
								</template>
							</el-table-column>
							<el-table-column label="使用渠道" v-if="isManage"  show-overflow-tooltip width="100">
								<template slot-scope="scope">
									<span :title="channelTitle">{{scope.row.channelName}}</span>
								</template>
							</el-table-column>
							<el-table-column label="创建渠道" v-if="isManage" show-overflow-tooltip  width="90">
							  <template slot-scope="scope">
								<span :title="channelUserTitle">{{scope.row.channelUserName}}</span>
								</template>
							</el-table-column>
							<el-table-column label="操作">
								<template slot-scope="scope">
									<div class="btnDiv">
										<el-popover trigger="hover" placement="left" @show="show(scope.$index, scope.row)" style="margin-right:0">
										  <p class="imgBox" style="width:100px;height:100px"><img class="img" :src="imgbaseUrl+src" style="width:100%;height:100%"/></p>
										  <div slot="reference" class="name-wrapper">
										    <el-button type="primary" v-popover:popover size="mini" v-if="previewFlag">预览</el-button>
										  </div>
										</el-popover>
										<el-button class="downloadDiv" size="mini" type="primary" @click="downLoad(scope.$index, scope.row)" v-if="scope.row.type=='基础' && downFlag && isManage" >下载</el-button>
										<el-button size="mini" type="primary" @click="folks(scope.$index, scope.row)" v-if="scope.row.type=='基础' && replaceFlag && isManage && btnLimit" style="margin-left:0">替换</el-button>
										<el-dialog
										  title="替换提示"
										  :visible.sync="replaceTip"
										  width="30%"
										  :before-close="handleClose">
										  <span>{{message}}</span>
										  <span slot="footer" class="dialog-footer">
										    <el-button @click="replaceTip = false">取 消</el-button>
										    <el-button type="primary" @click="replaceSure(scope.$index, scope.row)">确定</el-button>
										  </span>
										</el-dialog>
										<el-dialog title="替换基础Widget" :visible.sync="dialogFormVisible">
										  	<el-form v-if="dialogFormVisible">
										  	  <el-upload
										  	    class="upload-demo"
										  	    ref="upload1"
										  	    action="http://api.launcher.pactera-sln.club:8185/system/replaceBaseWidget"
										  	    :on-remove="handleRemove"
										  	    :headers=uploadToken
										  	    :before-remove="beforeRemove"
										  	    :auto-upload="false"
										  	    :on-success="folksSuccess"
										  	    :on-error="folksFailed"
										  	    :data="{
										  	    	widgetId:replaceId
										  	    }"
										  	    :before-upload="beforeAvatarUpload">
										  	    <el-button slot="trigger" size="small" type="primary">选取文件</el-button>
										  	  </el-upload>
										  	</el-form>
										  <div slot="footer" class="dialog-footer">
										    <el-button type="primary"  @click="folksSure">确 定</el-button>
										  </div>
										</el-dialog>
										<el-button size="mini" type="primary" @click="neweditData(scope.$index, scope.row)" v-if="createFlag && scope.row.type=='组合'">创建副本</el-button>
										<el-button size="mini" type="primary" @click="neweditData(scope.$index, scope.row)" v-if="createFlag && (scope.row.type=='基础' || scope.row.type=='基础变体')">创建变体</el-button>
										<el-button size="mini" type="primary" style="margin-left:0px!important" @click="editData(scope.$index, scope.row)" v-if="(scope.row.type=='基础变体'|| scope.row.type=='组合') && editFlag  && scope.row.isShow">编辑</el-button>
										<el-button size="mini" type="danger" style="margin-left:0px" @click="deleteClick(scope.$index, scope.row)" v-if="deleteFlag && scope.row.basic && scope.row.isShow">删除</el-button>
										<el-dialog
										  title="删除提示"
										  :visible.sync="dialogVisible"
										  width="30%"
										  :before-close="handleClose">
										  <span>{{message}}</span>
										  <span slot="footer" class="dialog-footer">
										    <el-button @click="dialogVisible = false">取 消</el-button>
										    <el-button type="primary" @click="deleteRow(scope.$index, scope.row)">确定</el-button>
										  </span>
										</el-dialog>
									</div>
									
								</template>
							</el-table-column>
						</el-table>
						</el-table>

					</div>
					
					<div class="widgetTableFooter" v-if="seen">
						<div class="widgetTabRecord">
							<span>共<span class="spantotal" v-model="totalNum">{{totalNum}}</span>条数据，每页<span class="spansize">{{pageSize}}</span>条</span>
						</div>
						<div class="widgetTabFoot">
							<div class="widgetPage">
								<el-pagination
							      @size-change="handleSizeChange"
							      @current-change="handleCurrentChange"
							      :current-page.sync="pageNum"
							      :page-size=pageSize
							      layout="prev, pager, next, jumper"
							      :total=totalNum>
							    </el-pagination>
							</div>
							<button type="button" class="el-button el-button--primary btnSearch btn" style="border-color:#84A1E5;margin:3px;line-height:3px;background: #84A1E5;">确定</button>		
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</template>
<script src="./index.js">
</script>
<style scoped="scoped" src="./index.less" lang="less">
</style>