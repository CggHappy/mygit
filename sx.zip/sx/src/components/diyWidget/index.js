import axios from "@/axios.js";
import "./diyWidget.css";
//import bus from "@/bus.js";
export default {
	data() {
		return {
			tableData: [], //控件管理表格数据
			widgetSize: "", //下拉框尺寸
			widgetCategory: "", //下拉框分类
			widgetVersion: "", //下拉框分类
			defaultSize: '', //默认尺寸
			version: '', //版本
			category: '', //分类
			keyWord: "", //关键词
			pageSize: 2, //每页显示条数
			pageNum: 1, //当前页
			totalNum: 100, //总条数
			dialogVisible: false,
			currentpage: 1,
			message: "",
			rowid: "",
			form: "",
			dialogFormVisible: false, //弹出框是否显示
			seen: false, //分页是否展示,
			src: "", //预览图片路径，
			downLoadIs: false, //只有基础，下载才展示
			hrefUrl: "", //下载路径
			folksId: "", //替换时的ID
			file: "", //保存文件
			dialogUpload: false,
			listBtnIS: true, //判断0基础,1变体,2组合,按钮显示规则
			btntitle: "", //0基础，1变体 创建变体，2组合,创建副本
			replaceTip: false, //替换提示弹出框是否显示
			str: "", //显示被占用的主题名
			isqudao: "", //判断是不是渠道
			creator: "", //判断创建者
			cellTitle: "", //title
			cellName: "", //名称title
			limit: "", //权限包
			widgetLimit: "", //属于widget的权限
			flag: false, //大权限
			isUpload: false, //上传widget是否显示
			searchFlag: false, //查询widget是否显示
			previewFlag: false, //预览图片是否显示
			createFlag: false, //创建副本是否显示
			downFlag: false, //下载功能是否显示
			replaceFlag: false, //替换功能是否显示
			newFlag: false, //新建副本是否显示
			editFlag: false, //widget编辑是否显示
			deleteFlag: false, //删除功能
			uploadToken: "", //token
			loading: true,
			id: "", //删除的ID
			isManage: false, //渠道不能看创建渠道和上传
			channelTitle: "", //使用渠道title
			channelUserTitle: "", //创建渠道title
			btnLimit: true,
			replaceId:""
		}
	},
	mounted() { //实例挂载之后

		this.getUsermsg();
	},
	methods: { //方法
		indexMethod(index) { //前面索引变化
			return index + 1 + (this.pageNum - 1) * this.pageSize
		},
		handleSizeChange(val) { //修改每页几条
			this.getTabledata(1, val)
		},
		handleCurrentChange(val) { //点击某一页时
			this.getTabledata(val, this.pageSize)
		},
		enterCell(row, column, cell, event) { //鼠标滑过
			if(column.label == "描述") {
				this.cellTitle = row.description;
			} else if(column.label == "名称") {
				this.cellName = row.name;
			} else if(column.label == "使用渠道") {
				this.channelTitle = row.channelName;
			} else if(column.label == "创建渠道") {
				this.channelUserTitle = row.channelUserName;
			}
		},
		getUsermsg() { //获取用户
			let userMsg = JSON.parse(sessionStorage.getItem('userMsg'));
			this.isqudao = userMsg.userType;
			this.isManage = (this.isqudao == 0) || (this.isqudao == 2) ? true : false;
			this.creator = userMsg.id;
			this.limit = userMsg.listPermissions;
			let token = sessionStorage.getItem('Token');
			this.uploadToken = {
				Authorization: token
			};
			for(let i in this.limit) { //获取widget权限
				if(this.limit[i].introducs == "widget管理") {
					this.widgetLimit = this.limit[i].listPermissions;
				}
			}

			for(let i in this.widgetLimit) {
				switch(this.widgetLimit[i].introducs) {
					case "widget列表":
						this.searchFlag = true;
						break;
					case "预览widget":
						this.previewFlag = true;
						break;
					case "删除widget":
						this.deleteFlag = true;
						break;
					case "创建副本widget":
						this.createFlag = true;
						break;
					case "下载widget":
						this.downFlag = true;
						break;
					case "替换widget":
						this.replaceFlag = true;
						break;
					case "新建widget":
						this.newFlag = true;
						break;
					case "上传基础widget":
						this.isUpload = true;
						break;
					case "widget编辑":
						this.editFlag = true;
						break;
				}
			}
			this.getTabledata(1, 10);
		},
		getTabledata(page, size) { //获取表单数据
			this.loading = true;
			let data = {
				params: {
					category: this.$route.query.category ? this.$route.query.category : '',
					title: this.$route.query.themeName ? this.$route.query.themeName : '',
					keyWord: this.$route.query.keyWord ? this.$route.query.keyWord : '',
					version: this.$route.query.version ? this.$route.query.version : '',
					defaultSize: this.$route.query.defaultSize ? this.$route.query.defaultSize : '',
					pageSize: size,
					pageNum: page,
					type: (this.isqudao == 0) || (this.isqudao == 2) ? 0 : 1 //管理员
				}
			};
			axios.get('/system/findWidgetsList', data)
				.then((res) => {
					let listData = res.data.data.list;
					let userMsg = JSON.parse(sessionStorage.getItem('userMsg'));
					this.tableData = listData;
					this.totalNum = res.data.data.total;
					this.pageSize = res.data.data.pageSize;
					/* this.id=res.data.data.list.length>0?res.data.data.list[0].id:"";*/
					this.seen = this.tableData.length > 0 ? true : false;

					for(let i in listData) {
						if(listData[i].type == '0') {
							listData[i].type = "基础";
						} else if(listData[i].type == '1') {
							listData[i].type = "基础变体";
						} else if(listData[i].type == '2') {
							listData[i].type = "组合";
						}

						listData[i].isShow = "";
						listData[i].basic = "";
						if(this.isManage == false) { //为false,代表渠道
							listData[i].basic = listData[i].type == '基础' ? false : true;
							if(this.creator == listData[i].creator) {
								listData[i].isShow = true
							} else {
								listData[i].isShow = false
							}
						} else {
							listData[i].isShow = true;
							listData[i].basic = true;
						}
					}

					this.loading = false

				})
				.catch(err => {
					console.log(err);
				});
		},
		saveQuery() { //搜索
			var queryData = {
				defaultSize: this.defaultSize,
				version: this.version,
				category: this.category,
				keyWord: this.keyWord

			};
			this.$router.push({
				path: this.$route.path,
				query: queryData
			})
			this.getTabledata(1, 10);
		},
		show(index, row) { //预览
			let id = row.id;
			let data = {
				params: {
					widgetId: id
				}
			}
			axios.get('/system/widgetpreview', data)
				.then((res) => {
					this.src = res.data.data
				})
				.catch(err => {
					console.log(err);
				});

		},
		handleClose(done) { //点击删除
			this.$confirm('确认关闭？')
				.then(_ => {
					done(function() {})

				})
				.catch(_ => {});

		},
		downLoad(index, row) { //点击下载
			let id = row.id;
			let data = {
				params: {
					widgetId: id
				}
			};
			axios.get('/system/dowloadwidgetFile', data)
				.then((res) => {
					this.hrefUrl = res.data
					window.location.href = this.imgbaseUrl + this.hrefUrl;
				})
				.catch(err => {
					console.log(err);
				});
		},
		public(row, str) { //创建副本或者编辑时调用的接口
			let data = {
				params: {
					widgetId: row.id
				}
			};
			sessionStorage.removeItem("img")
			sessionStorage.removeItem("menuData")
			sessionStorage.removeItem("creator")
			axios.get('/system/findWidgetById', data)
				.then((res) => {
					sessionStorage.setItem('menuData', res.data.data);
					axios.get('/system/getImgPathBywidthId', data)
						.then((res) => {
							sessionStorage.setItem('img', JSON.stringify(res.data));
							sessionStorage.setItem('creator', JSON.stringify(row));

							if(row.type == "组合") {
								if(str == "编辑") {
									axios.get('/system/getWidgetChannels', data)
										.then((res) => {
											sessionStorage.setItem('channels', JSON.stringify(res.data.data));
										})
										.catch(err => {
											console.log(err);
										});
									this.$router.push({
										path: "/diywidget/editfwidget"
									});

								} else if(str == "创建副本") {
									this.$router.push({
										path: "/diywidget/createfwidget"
									});

								}
							} else {
								axios.get('/system/getWidgetChannels', data)
									.then((res) => {
										sessionStorage.setItem('channels', JSON.stringify(res.data.data));
										this.$router.push({
											path: "/diywidget/editwidget"
										});
									})
									.catch(err => {
										console.log(err);
									});
							}
						})
						.catch(err => {
							console.log(err);
						});
				})
				.catch(err => {
					console.log(err);
				});

		},
		neweditData(index, row) { //点击创建副本
			sessionStorage.setItem('newtitle', "创建");
			if(row.type == "组合") {
				this.public(row, "创建副本")
			}
			this.public(row)
		},
		editData(index, row, str) { //点击编辑
			sessionStorage.setItem('newtitle', "编辑");
			this.public(row, "编辑")
		},
		deleteClick(index, row) { //点击删除按钮
			this.dialogVisible = true;
			this.tip(row, "删除");
			this.id = row.id;
		},
		deleteRow(index, row) { //点击弹出框的确定按钮删除数据
			this.dialogVisible = false;
			this.deletegetTable(this.id)

		},
		deletegetTable(rowid) { //删除时调接口
			let data = {
				params: {
					id: rowid
				}
			};
			axios.get('/system/deleteWidgetById', data)
				.then((res) => {
					this.$message({
						message: res.data.message,
						type: 'success'
					});
					this.getTabledata(1, 10)
				})
				.catch(err => {
					console.log(err);
				});
		},
		addCustom() { //添加自定义控件
			this.$router.push({
				path: "/diywidget/addwidget"
			})
		},
		getwidgetSize() { //获取尺寸下拉框
			axios.get('/system/findWidgetDefaultSize')
				.then((res) => {
					this.widgetSize = res.data.data.list
				})
				.catch(err => {
					console.log(err);
				});
		},
		getWidgetCategory() { //获取分类下拉框
			axios.get('/system/findWidgetCategory')
				.then((res) => {
					this.widgetCategory = res.data.data.list

				})
				.catch(err => {
					console.log(err);
				});
		},
		getWidgetVersion() { //获取版本寸下拉框
			axios.get('/system/findWidgetVersion')
				.then((res) => {
					this.widgetVersion = res.data.data

				})
				.catch(err => {
					console.log(err);
				});
		},
		upLoadPakageRemove() {
			this.dialogUpload = false;
		},
		upLoadPakage() { //点击确定手动上传文件
			this.dialogUpload = false;
			this.$refs.upload.submit();

			this.getTabledata(1, 10)
		},
		handleRemove(file, fileList) { //删除图片
		},
		beforeRemove(file, fileList) { //删除之前
			return this.$confirm(`确定移除 ${ file.name }？`);
		},
		upLoadSuccess(response, file, fileList) { //上传成功
			if(response.data == "文件解析异常") {
				this.$message({
					message: "文件解析异常",
					type: 'error'
				});
			} else {
				this.$message({
					message: "文件上传成功，保存记录成功",
					type: 'success'
				});
			}

			this.dialogUpload = false;
			this.getTabledata(1, 10)
		},
		upLoadFailed(response, file, fileList) { //上传失败
			this.$message({
				message: '上传失败',
				type: 'error'
			});
		},
		beforeAvatarUpload(file) { // 上传前文件校验
			let testname = file.name.substring(file.name.lastIndexOf('.'));
			const isJPG = testname === '.zip';
			const isPNG = testname === '.rar';
			if(!isJPG && !isPNG) {
				this.$message.error('上传基础widget只能是 zip、rar 格式!');
			}
			return isJPG || isPNG;
		},
		tip(row, str) { //替换和删除时提示内容
			let data = {
				params: {
					widgetId: row.id
				}
			};
			axios.get('/system/findWidgetUseNum', data)
				.then((res) => {
					if(str == "删除") {
						if(this.isManage) { //true 管理员
							if(row.channelUserName != "管理员") { //渠道
								this.deleteManage("删除", res.data.message, row.channelUserName);
							} else { //管理员
								this.deletetitle("删除", res.data.message)
							}
						} else { //渠道
							if(row.channelUserName != "管理员") { //渠道
								if(res.data.message.length > 0) {
									this.message = '该widget正在被' + res.data.message + '调用，' + str + '后可能造成此主题无法使用，确认要' + str + '吗'
									//this.deleteManage("删除",res.data.data,row.channelUserName)
								} else {
									this.message = '该widget暂未被主题使用，点击确定，' + str + '该 widget'
								}
							}
						}
					} else { //替换
						this.deletetitle("替换", res.data.message)
					}
				})
				.catch(err => {
					console.log(err);
				});
		},
		deletetitle(title, titleMain) { //无渠道使用提示
			if(titleMain.length > 0) {
				this.message = '该widget正在被' + titleMain + '调用，' + title + '后可能造成此主题无法使用，确认要' + title + '吗'
			} else {
				this.message = '该widget暂未被主题使用，点击确定，' + title + '该 widget'
			}
		},
		deleteManage(title, titleMain, channelName) {
			if(titleMain.length > 0) {
				this.message = '该widget为' + channelName + '自有widget，正在被' + titleMain + '调用，' + title + '后可能造成此主题无法使用，确认要' + title + '吗'
			} else {
				this.message = '该widget为' + channelName + '自有widget，暂未被主题使用，点击确定，' + title + '该 widget'
			}
		},
		folks(index, row) { //替换
			this.replaceTip = true;
			this.replaceId=row.id;
			this.tip(row, "替换")
		},
		replaceSure() { //点击替换确定时，替换弹框出现
			this.replaceTip = false;
			this.dialogFormVisible = true;
		},
		folksFailed(response, file, fileList) {
			this.$message({
				message: response.message,
				type: 'error'
			});
		},
		folksSuccess(response, file, fileList) {
			if(response.message == "文件解析异常") {
				this.$message({
					message: "文件解析异常",
					type: 'error'
				});
			} else {
				this.$message({
					message: response.message,
					type: 'success'
				});
				this.getTabledata(1, 10);
			}

			
		},
		folksSure() { //点击确定替换成功
			this.dialogFormVisible = false;
			this.$refs.upload1.submit();
		}
	},
	watch: { //监听
		'$route' (to, from) { // 对路由变化作出响应...

		},
	},
	created() { //实例创建之后
	}
}