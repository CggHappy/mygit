<template>
	<div class="operationLog">
		<div class="operationJournal">运维日志</div>
		<div class="operationJournalCon">
			<div class="operationJournalConTop">
				<el-select placeholder="渠道" class="zu" v-model="channelId" @change='getOperatingAccount'>
					<el-option v-for="item in channel" :key="item.id" :label="item.name" :value="item.id">
					</el-option>
				</el-select>
				<el-select placeholder="操作账号" v-model="userName" @change='loadData(1)'>
					<el-option v-for="item in operatingaccount" :key="item.id" :label="item.name" :value="item.userName">
					</el-option>
				</el-select>
			</div>
			<div class="carTableModel" v-loading="loading" element-loading-text="拼命加载中">
				<el-table ref="multipleTable" :data="tableData" tooltip-effect="dark" style="width: 100%">
					<el-table-column prop="createDate" label="时间">
					</el-table-column>
					<el-table-column prop="userName" label="账号">
					</el-table-column>
					<el-table-column prop="ip" label="IP">
					</el-table-column>
					<el-table-column prop="methodName" label="操作内容">
					</el-table-column>
				</el-table>
			</div>
			<div class="tableFooter">
				<div class="widgetTabRecord">
					<span>共
						<span class="spantotal" v-model="totalNum">{{totalNum}}</span> 条数据，每页
						<span class="spansize">{{pageSize}}</span> 条</span>
				</div>
				<div class="widgetTabFoot">
					<div class="widgetPage">
						<el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange" :current-page.sync="currentpage" :page-size=pageSize layout="prev, pager, next, jumper" :total=totalNum>
						</el-pagination>
					</div>
					<button type="button" class="el-button el-button--primary btnSearch btn" style="border-color:#84A1E5;margin:3px;line-height:3px;background: #84A1E5;">确定</button>
				</div>
			</div>

		</div>
	</div>
</template>
<script src="./index.js">
</script>
<style scoped="scoped" src="./index.less" lang="less">

</style>