import axios from "@/axios.js";
import "./operationLog.css";
export default {
	data() {
		return {
			currentpage: 1,//当前页
			pageSize: 0,//每页条数
			totalNum: 0,//总条数
			tableData: [],
			channel: [],
			operatingaccount: [],
			channelId: '',
			userName: '',
			loading: true
		}
	},
	mounted() { //实例挂载之后
		this.getChannel()
		this.loadData()
	},
	methods: { //方法	
		//加载列表数据
		loadData(page, size) {
			this.loading = true
			let data = {
				params: {
					channelId: this.channelId,
					userName: this.userName,
					page: page,
					pageSize: size
				}

			}
			axios.get('logs/findStoreBrowseLogs', data)
				.then(res => {
					this.loading = false;
					this.tableData = res.data.content;
					this.totalNum = res.data.totalElements;
					this.pageSize = res.data.size;
					for (var i = 0; i < this.tableData.length; i++) {
						this.tableData[i].createDate = this.get_Timer(new Date(this.tableData[i].createDate), 1)
					}
				})
				.catch(err => {
					console.log(err)
				})
		},

		//渠道
		getChannel() {
			axios.post('auth/channel/findChannelAll')
				.then((res) => {
					this.channel = res.data.data;
					this.loadData();
				})
				.catch(err => {
					console.log(err);
				});
		},

		//操作账号
		getOperatingAccount() {
			let data = {
				channelId: this.channelId
			}
			axios.post('auth/channel/findUserByChannelId', data)
				.then((res) => {
					this.userName = ''
					this.operatingaccount = res.data.data;
					this.loadData(1)
				})
				.catch(err => {
					console.log(err);
				});
		},

		handleSizeChange(val) {
			
		},

		handleCurrentChange(val) {
			this.pageNum = val;
			this.loadData(val, this.pageSize)
		},
	},
	watch: { //监听
		'$route'(to, from) { // 对路由变化作出响应...

		},
	},
	created() { //实例创建之后

	}
}