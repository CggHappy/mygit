import Vue from 'vue';
import Vuex from 'vuex';
Vue.use(Vuex);

//state  ：存储数据、数据 初始化
const state = {	
	isexpried:0, //用户是否过期
	expriedmsg:'请重新登陆！', //全局失败弹出信息
	showScroll:false,
	widgetValid:false,
	widgetClick:0,
	themeClick:0,
	themeValid:false,
	themeType:0,
	saveflag:false,
	
}
export default new Vuex.Store({
	state,
})