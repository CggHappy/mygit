<template>
  <div id="app" element-loading-text="数据保存中..." v-loading="loading"> 
    <router-view/>
  </div>
</template>

<script>
import store from './vuex/store.js'
export default {
  name: 'App',
  computed:{
  	isexpried(){
  		return store.state.isexpried
  	},
  	loading(){
  		return store.state.saveflag;
  	}
  },
  watch:{
  	isexpried(){
  		this.$message({
          message: store.state.expriedmsg,
          type: 'warning'
        });
  	}
  }
}
</script>

<style>
	html,body{
		width: 100%;
		height: 100%;
	}
#app {
  font-family: 'MicrosoftYaHei', Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  /*text-align: center;*/
  color: #2c3e50; 
  height: 100%;
  width: 100%;
}
</style>
