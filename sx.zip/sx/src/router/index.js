import Vue from 'vue'
import Router from 'vue-router'
import Login from '@/components/Login/index.vue' //引入登录页
import indexPage from '@/components/indexPage/index.vue' //引入主页
Vue.use(Router)

export default new Router({
	//	linkActiveClass: 'activeClass',
	routes: [{
			path: '/',
			name: 'Login',
			component: Login
		},
		{
			path: '/index',
			component: indexPage,
			redirect:'/',
			name: '主页',
			children: [{
					path: 'situation',
					name: '整体概况',
					component: resolve => require(['@/components/Overallsituation/index.vue'], resolve)
				},

				{
					path: 'operatlog',
					name: '运维日志',
					component: resolve => require(['@/components/operationLog/index.vue'], resolve)
				},
			]
		},
		{
			path: '/account',
			component: indexPage,
			redirect:'/',
			name: '账号主页',
			children: [{
					path: 'index',
					name: '账号管理',
					component: resolve => require(['@/components/Account/index.vue'], resolve)
				},
				{
					path: 'addaccount',
					name: '添加账号',
					meta: '/account/index',
					component: resolve => require(['@/components/Account/addAccount/index.vue'], resolve)
				},
				{
					path: 'editaccount',
					name: '编辑账号',
					meta: '/account/index',
					component: resolve => require(['@/components/Account/addAccount/index.vue'], resolve)
				},
			]
		},
		{
			path: '/channel',
			component: indexPage,
			redirect:'/',
			name: '渠道主页',
			children: [{
					path: 'index',
					name: '渠道管理',
					component: resolve => require(['@/components/Channel/index.vue'], resolve)
				},
				{
					path: 'addchannel',
					name: '添加渠道',
					meta: '/channel/index',
					component: resolve => require(['@/components/Channel/manChannel/index.vue'], resolve)
				},
				{
					path: 'editchannel',
					name: '编辑渠道',
					meta: '/channel/index',
					component: resolve => require(['@/components/Channel/manChannel/index.vue'], resolve)
				},
			]
		},
		{
			path: '/diywidget',
			component: indexPage,
			redirect:'/',
			name: '自定义控件主页',
			children: [{
					path: 'index',
					name: '控件管理',
					component: resolve => require(['@/components/diyWidget/index.vue'], resolve)
				},
				{
					path: 'addwidget',
					name: '添加自定义控件',
					meta: '/diywidget/index',
					component: resolve => require(['@/components/addwidget/freeWidget/index.vue'], resolve)
				},
				{
					path: 'editfwidget',
					name: '编辑自定义控件',
					meta: '/diywidget/index',
					component: resolve => require(['@/components/addwidget/freeWidget/index.vue'], resolve)
				},
				{
					path: 'createfwidget',
					name: '创建变体',
					meta: '/diywidget/index',
					component: resolve => require(['@/components/addwidget/freeWidget/index.vue'], resolve)
				},
				{
					path: 'editwidget',
					name: '编辑基础widget',
					meta: '/diywidget/index',
					component: resolve => require(['@/components/diyWidget/freeWidget/index.vue'], resolve)
				},
				{
					path: 'upload',
					name: '上传预留',
					meta: '/diywidget/index',
					component: resolve => require(['@/components/appMge/addApp/index.vue'], resolve)
				},
			]
		},
		{
			path: '/appmange',
			component: indexPage,
			redirect:'/',
			name: '应用主页',
			children: [{
					path: 'index',
					name: '应用',
					component: resolve => require(['@/components/appMge/index.vue'], resolve)
				},
				{
					path: 'editposter',
					name: '编辑海报详情',
					meta: '/appmange/index',
					component: resolve => require(['@/components/appMge/editPoster/index.vue'], resolve)
				},
				{
					path: 'addapp',
					name: '添加应用',
					meta: '/appmange/index',
					component: resolve => require(['@/components/appMge/addApp/index.vue'], resolve)
				},
				{
					path: 'editapp',
					name: '编辑应用',
					meta: '/appmange/index',
					component: resolve => require(['@/components/appMge/addApp/index.vue'], resolve)
				},
			]
		},
		{
			path: '/theme',
			component: indexPage,
			redirect:'/',
			name: '主题主页',
			children: [{
					path: 'index',
					name: '主题',
					component: resolve => require(['@/components/Theme/index.vue'], resolve)
				},
				{
					path: 'addtheme',
					name: '添加主题',
					meta: '/theme/index',
					component: resolve => require(['@/components/Theme/operateTm/index.vue'], resolve)
				},
				{
					path: 'edittheme',
					name: '编辑主题',
					meta: '/theme/index',
					component: resolve => require(['@/components/Theme/operateTm/index.vue'], resolve)
				},
				{
					path: 'creattheme',
					name: '创建主题副本',
					meta: '/theme/index',
					component: resolve => require(['@/components/Theme/operateTm/index.vue'], resolve)
				},
			]
		},
		{
			path: '/banner',
			component: indexPage,
			redirect:'/',
			name: '广告主页',
			children: [{
					path: 'manage',
					name: '广告管理',
					component: resolve => require(['@/components/Banner/Manage/index.vue'], resolve)
				},
				{
					path: 'auditing',
					name: '广告审核',
					component: resolve => require(['@/components/Banner/Auditing/index.vue'], resolve)
				},
				{
					path: 'advertiser',
					name: '广告主管理',
					component: resolve => require(['@/components/Banner/AdvertiserMan/index.vue'], resolve)
				},
				{
					path: 'order',
					name: '订单管理',
					component: resolve => require(['@/components/Banner/Order/index.vue'], resolve)
				},
			]
		},
		{
			path: '/analysis',
			component: indexPage,
			redirect:'/',
			name: '分析主页',
			children: [{
					path: 'carVehicle',
					name: '车辆趋势',
					component: resolve => require(['@/components/Analysis/carVehicle/index.vue'], resolve)
				},
				{
					path: 'themeusage',
					name: '主题使用情况',
					component: resolve => require(['@/components/Analysis/themeUsage/index.vue'], resolve)
				},
				{
					path: 'management',
					name: '事件管理',
					component: resolve => require(['@/components/Analysis/Management/index.vue'], resolve)
				},
				{
					path: 'advertising',
					name: '广告统计',
					component: resolve => require(['@/components/Analysis/Advertising/index.vue'], resolve)
				},
			]
		},
        {
            path: '/analysis/apparea',
            name: '应用分布页',
            redirect:'/',
            component: indexPage,
            children:[
                {
                    path:'index',
                    name:'应用分布',
                    meta: '/analysis/apparea/index',
                    component: resolve => require(['@/components/Analysis/appDistribution/index.vue'], resolve),
                },
                {
                    path:'appareaDetail',
                    name:'应用详情',
                    meta: '/analysis/apparea/index',
                    component: resolve => require(['@/components/Analysis/appDistribution/appDetail/index.vue'], resolve),
                }
            ],


        },
        {
            path: '/analysis/version',
            name: '版本',
            redirect:'/',
            component: indexPage,
            children:[
                {
                    path:'index',
                    name:'版本分布',
                    meta: '/analysis/version/index',
                    component: resolve => require(['@/components/Analysis/versionScatter/index.vue'], resolve)
                },
                {
                    path:'versionDetail',
                    name:'版本分布详情',
                    meta: '/analysis/version/index',
                    component: resolve => require(['@/components/Analysis/versionScatter/versionDetail/index.vue'], resolve),
                }
            ],


        },
        {
            path: '/analysis/wusage',
            name: 'widget',
            redirect:'/',
            component: indexPage,
            children:[
                {
                    path:'index',
                    name:'widget使用情况',
                    meta: '/analysis/wusage/index',
                    component: resolve => require(['@/components/Analysis/widgetUsage/index.vue'], resolve)
                },
                {
                    path:'wusDetail',
                    name:'widget详情',
                    meta: '/analysis/wusage/index',
                    component: resolve => require(['@/components/Analysis/widgetUsage/widgetDetail/index.vue'], resolve)
                }
            ],


        },
        {
            path: '/analysis/customevents',
            name: '自定义',
            redirect:'/',
            component: indexPage,
            children:[
                {
                    path:'index',
                    name:'自定义事件',
                    meta: '/analysis/customevents/index',
                    component: resolve => require(['@/components/Analysis/customEvents/index.vue'], resolve)
                },
                {
                    path:'eventsDetail',
                    name:'详情',
                    meta: '/analysis/customevents/index',
                    component: resolve => require(['@/components/Analysis/customEvents/detail/index.vue'], resolve)
                },
                {
                    path:'eventsTrend',
                    name:'参数值趋势',
                    meta: '/analysis/customevents/index',
                    component: resolve => require(['@/components/Analysis/customEvents/trend/index.vue'], resolve)
                }
            ],


        },


	]
})